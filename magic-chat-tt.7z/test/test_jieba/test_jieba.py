import os

os.chdir("../../")

import jieba
from jieba import posseg
from biz.index import jieba_manager

jieba_manager.load_dict()

text = "库存09规约表数量"
print("===========jieba.cut==========")
result = jieba.cut(text)
print(" ".join(result))
print("===========jieba.posseg.cut==========")
result = jieba.posseg.cut(text)
print(" ".join([f"{w.word}[{w.flag}]" for w in result]))
yzs = [w.word for w in posseg.cut(text) if w.flag in ['yz']]
print(yzs)

from typing import Any

from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferWindowMemory
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.prompts import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    MessagesPlaceholder,
    HumanMessagePromptTemplate,
)

from framework.chain.i_chain_api import ChainABC
from framework.llm.llm_manager import LLMManager
from transport.websocket import send_msg
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)


class StreamingChatChain(ChainABC):
    def __init__(self, websocket, configs):
        self.websocket = websocket
        self.configs = configs
        self.chat_callback_handler = StreamingCallbackHandler(self.websocket)
        self.chain = None

    @classmethod
    async def create(cls, websocket, configs):
        instance = cls(websocket, configs)

        prompt = ChatPromptTemplate.from_messages(
            [
                SystemMessagePromptTemplate.from_template(configs['system_prompt']),
                MessagesPlaceholder(variable_name="history"),
                HumanMessagePromptTemplate.from_template("{input}"),
            ]
        )
        streaming_llm = await LLMManager.create_streaming_llm_async(configs)
        memory = ConversationBufferWindowMemory(k=configs['memory_k'], return_messages=True)
        instance.chain = ConversationChain(
            memory=memory, llm=streaming_llm, verbose=configs['langchain_verbose'], prompt=prompt
        )

        return instance

    async def call(self, info, message):
        input_message = self.configs["user_prompt"].format(info=info, message=message)
        try:
            return (
                await self.chain.apredict(
                    input=input_message, callbacks=[self.chat_callback_handler]
                ),
                input_message,
            )
        except Exception as e:
            logger.error(f"StreamingChatChain call error: {e}")
            return "", message

    async def call_simple(self, message):
        try:
            return (
                await self.chain.apredict(input=message, callbacks=[self.chat_callback_handler]),
                message,
            )
        except Exception as e:
            logger.error("StreamingChatChain call_simple error: %s", e, exc_info=True)
            return "", message


class StreamingCallbackHandler(BaseCallbackHandler):

    def __init__(self, websocket):
        self.g_websocket = websocket
        self.g_token_buffer_str = ''

    async def on_llm_new_token(self, token: str, **kwargs: Any) -> Any:
        self.g_token_buffer_str += token
        await send_msg(self.g_websocket, "bot", token, "stream")

    async def on_llm_end(self, output: str, **kwargs: Any) -> Any:
        logger.info(f"llm_end, {output}")
        self.g_token_buffer_str = ''

    async def on_llm_error(self, output: str, **kwargs: Any) -> Any:
        logger.error(f"llm_error, {output}")
        self.g_token_buffer_str = ''

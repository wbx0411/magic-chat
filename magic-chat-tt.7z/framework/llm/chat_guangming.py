import json
from typing import Any, Dict, List, Optional, Iterator, AsyncIterator

import httpx
from langchain_core.callbacks.manager import CallbackManagerForLLMRun, AsyncCallbackManagerForLLMRun
from langchain_core.language_models.llms import LLM
from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
)
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.outputs import ChatGeneration, ChatResult


class GuangMingChat(BaseChatModel):
    """Custom LangChain chat model wrapper for DeepSeek API."""

    model_name: str = "DeepSeek-R1-Distill-Qwen-32B"
    base_url: str = "http://your-api-endpoint"  # Replace with your API endpoint
    api_url: str = f"{base_url}/chat/completions"  # Replace with your API endpoint
    api_key: Optional[str] = None
    timeout: int = 120
    streaming: bool = False

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.api_url = kwargs.get("base_url", self.base_url) + "/chat/completions"

    @property
    def _llm_type(self) -> str:
        return "guangming"

    def _convert_messages_to_api_format(self, messages: List[BaseMessage]) -> List[Dict[str, str]]:
        """Convert LangChain messages to DeepSeek API format."""
        api_messages = []

        for message in messages:
            if isinstance(message, HumanMessage):
                api_messages.append({"role": "user", "content": message.content})
            elif isinstance(message, AIMessage):
                api_messages.append({"role": "assistant", "content": message.content})
            elif isinstance(message, SystemMessage):
                api_messages.append({"role": "system", "content": message.content})
            else:
                raise ValueError(f"Message type {type(message)} not supported")

        return api_messages

    def _create_api_request(
        self, messages: List[Dict[str, str]], stream: bool = False
    ) -> Dict[str, Any]:
        """Create API request payload."""
        request = {"model": self.model_name, "messages": messages, "stream": stream}
        return request

    def _create_headers(self) -> Dict[str, str]:
        """Create request headers."""
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"{self.api_key}"
        return headers

    def _parse_response(self, response_data: Dict[str, Any]) -> AIMessage:
        """Parse API response into a LangChain AIMessage."""
        # if response_data.get("code") != "000000" or not response_data.get("success"):
        #     raise ValueError(f"API error: {response_data.get('message', 'Unknown error')}")

        # data = response_data.get("data", {})
        choices = response_data.get("choices", [])

        if not choices:
            raise ValueError("No choices returned from API")

        message = choices[0].get("message", {})
        content = message.get("content", "")

        return AIMessage(content=content)

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Generate a response synchronously."""
        api_messages = self._convert_messages_to_api_format(messages)
        request_data = self._create_api_request(api_messages)
        headers = self._create_headers()

        if self.streaming:
            stream_iter = self._stream(messages, stop=stop, run_manager=run_manager, **kwargs)
            chunks = [chunk for chunk in stream_iter]
            return ChatResult(
                generations=[ChatGeneration(message=AIMessage(content=''.join(chunks)))]
            )

        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                self.api_url,
                json=request_data,
                headers=headers,
                follow_redirects=True,
            )
            response.raise_for_status()
            try:
                response_data = response.json()
            except json.JSONDecodeError:
                raise ValueError(f"Failed to decode JSON response: {response.content}")

        ai_message = self._parse_response(response_data)

        return ChatResult(generations=[ChatGeneration(message=ai_message)])

    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        """Generate a response asynchronously."""
        api_messages = self._convert_messages_to_api_format(messages)
        request_data = self._create_api_request(api_messages)
        headers = self._create_headers()

        if self.streaming:
            stream_iter = self._astream(messages, stop=stop, run_manager=run_manager, **kwargs)
            chunks = [chunk async for chunk in stream_iter]
            return ChatResult(
                generations=[ChatGeneration(message=AIMessage(content=''.join(chunks)))]
            )

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                self.api_url,
                json=request_data,
                headers=headers,
                follow_redirects=True,
            )
            response.raise_for_status()
            try:
                response_data = response.json()
            except json.JSONDecodeError:
                raise ValueError(f"Failed to decode JSON response: {response.content}")

        ai_message = self._parse_response(response_data)

        return ChatResult(generations=[ChatGeneration(message=ai_message)])

    def _process_stream_chunk(self, chunk: Dict[str, Any]) -> Optional[str]:
        """Process a streaming chunk and extract content."""
        # if chunk.get("code") != "000000" or not chunk.get("success"):
        #     raise ValueError(f"API error in stream: {chunk.get('message', 'Unknown error')}")

        # data = chunk.get("data", {})
        choices = chunk.get("choices", [])

        if not choices:
            return ""

        delta = choices[0].get("delta", {})
        content = delta.get("content", "")

        return content

    def _stream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> Iterator[ChatResult]:
        """Stream response synchronously."""
        api_messages = self._convert_messages_to_api_format(messages)
        request_data = self._create_api_request(api_messages, stream=True)
        headers = self._create_headers()

        with httpx.Client(timeout=self.timeout) as client:
            with client.stream(
                "POST",
                self.api_url,
                json=request_data,
                headers=headers,
                follow_redirects=True,
            ) as response:
                response.raise_for_status()
                # content_buffer = ""

                for line in response.iter_lines():
                    if line.startswith("data:"):
                        json_str = line[5:]
                        if json_str.strip() == "[DONE]":
                            break

                        try:
                            chunk = json.loads(json_str)
                            new_content = self._process_stream_chunk(chunk)
                            if new_content:
                                # content_buffer += new_content
                                if run_manager:
                                    run_manager.on_llm_new_token(new_content)

                                yield new_content
                        except json.JSONDecodeError:
                            continue

    async def _astream(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> AsyncIterator[ChatResult]:
        """Stream response asynchronously."""
        api_messages = self._convert_messages_to_api_format(messages)
        request_data = self._create_api_request(api_messages, stream=True)
        headers = self._create_headers()

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            async with client.stream(
                "POST",
                self.api_url,
                json=request_data,
                headers=headers,
                follow_redirects=True,
            ) as response:
                response.raise_for_status()
                # content_buffer = ""
                async for line in response.aiter_lines():
                    if line.startswith("data:"):
                        json_str = line[5:]
                        if json_str.strip() == "[DONE]":
                            break

                        try:
                            chunk = json.loads(json_str)
                            new_content = self._process_stream_chunk(chunk)
                            if new_content:
                                # content_buffer += new_content
                                if run_manager:
                                    await run_manager.on_llm_new_token(new_content)

                                yield new_content
                        except json.JSONDecodeError:
                            continue


# Also add a standard LLM implementation for compatibility with other LangChain components
class GuangMingLLM(LLM):
    """Custom LangChain LLM wrapper for DeepSeek API."""

    model_name: str = "DeepSeek-R1-Distill-Qwen-32B"
    api_url: str = "http://your-api-endpoint/chat/completions"  # Replace with your API endpoint
    api_key: Optional[str] = None
    timeout: int = 120

    @property
    def _llm_type(self) -> str:
        return "deepseek"

    def _call(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """Call the DeepSeek API and return the response."""
        messages = [{"role": "user", "content": prompt}]
        request_data = {"model": self.model_name, "messages": messages, "stream": False}
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"{self.api_key}"

        with httpx.Client(timeout=self.timeout) as client:
            response = client.post(
                self.api_url,
                json=request_data,
                headers=headers,
                follow_redirects=True,
            )
            response.raise_for_status()
            response_data = response.json()

        if response_data.get("code") != "000000" or not response_data.get("success"):
            raise ValueError(f"API error: {response_data.get('message', 'Unknown error')}")

        data = response_data.get("data", {})
        choices = data.get("choices", [])

        if not choices:
            raise ValueError("No choices returned from API")

        message = choices[0].get("message", {})
        content = message.get("content", "")

        return content

    async def _acall(
        self,
        prompt: str,
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> str:
        """Call the DeepSeek API asynchronously and return the response."""
        messages = [{"role": "user", "content": prompt}]
        request_data = {"model": self.model_name, "messages": messages, "stream": False}
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"{self.api_key}"

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            response = await client.post(
                self.api_url,
                json=request_data,
                headers=headers,
                follow_redirects=True,
            )
            response.raise_for_status()
            response_data = response.json()

        if response_data.get("code") != "000000" or not response_data.get("success"):
            raise ValueError(f"API error: {response_data.get('message', 'Unknown error')}")

        data = response_data.get("data", {})
        choices = data.get("choices", [])

        if not choices:
            raise ValueError("No choices returned from API")

        message = choices[0].get("message", {})
        content = message.get("content", "")

        return content

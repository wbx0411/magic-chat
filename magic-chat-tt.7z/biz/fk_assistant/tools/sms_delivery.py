# 短信发送
import json

from langchain_core.tools import BaseTool

background_info = """
短信发送情况：
短信发送成功率为74.08%。
欠费短信有583100条，较前日减少3.71%；
停电短信有1449条，较前日减少32.92%。
余额预警短信185340条，较前日增加5.91%；
复电短信105条，较前日减少23.91%。
"""


class SmsDelivery(BaseTool):
    name = "昨日短信发送情况"
    description = """
        获取昨日短信发送情况
        """
    return_direct = False

    def __init__(self):
        super().__init__()

    async def _arun(self, cons_no: str) -> str:
        output = {
            "result": f"{background_info}",
            "key": "sd"
        }
        json_data = json.dumps(output, ensure_ascii=False)
        return json_data

    def _run(self, cons_no: str) -> str:
        pass

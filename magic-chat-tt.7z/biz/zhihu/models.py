from pgvector.sqlalchemy import Vector
from sqlalchemy import (
    Column,
    Integer,
    Text,
    String,
    TIMESTAMP,
    UniqueConstraint,
    func,
    CheckConstraint,
    Float,
    ARRAY,
    Numeric,
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import mapped_column

Base = declarative_base()


class DocEmbeddingEntity(Base):
    __tablename__ = 'ai_tools_de_doc_embedding'
    id = Column(Integer, primary_key=True, autoincrement=True)
    tool_id = Column(String(255))
    cat1 = Column(String(255))
    cat2 = Column(String(255))
    cat3 = Column(String(255))
    cat4 = Column(String(255))
    cat5 = Column(String(255))
    cat6 = Column(String(255))
    dimension = Column(Text)
    content = Column(Text)
    note = Column(Text)
    content_note = Column(Text)
    content_emb = mapped_column(Vector(512))
    note_emb = mapped_column(Vector(512))
    content_note_emb = mapped_column(Vector(512))
    attach_path = Column(String(255))
    title = Column(String(500))


class ChatRecords(Base):
    __tablename__ = 'chat_records'
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(255))
    question = Column(Text)
    file_name = Column(Text)
    answer = Column(Text)
    org_no = Column(String(16))
    rating = Column(Integer)
    timestamp = Column(TIMESTAMP, server_default=func.now())
    vector_duration = Column(Float)
    llm_duration = Column(Float)

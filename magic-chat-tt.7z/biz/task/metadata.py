from enum import Enum


class TaskStatus(Enum):
    INIT = "INIT"
    RUNNING = "RUNNING"
    DONE = "DONE"
    EXC = "EXC"

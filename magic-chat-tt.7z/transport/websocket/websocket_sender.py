from typing import Optional

from fastapi.websockets import WebSocketState
from pydantic import BaseModel, field_validator


async def send_msg(websocket, sender, message_content, message_type, data=None):
    message_content = message_content or ""
    resp = ChatResponse(sender=sender, message=message_content, type=message_type, data=data)
    if websocket.application_state == WebSocketState.CONNECTED:
        await websocket.send_json(resp.model_dump())


class ChatResponse(BaseModel):
    """Chat response schema."""

    sender: str
    message: str = ""
    type: str
    data: Optional[list | dict] = None

    @field_validator("sender")
    @classmethod
    def sender_must_be_bot_or_you(cls, v):
        if v not in ["bot", "human"]:
            raise ValueError("chat response sender must be bot or human")
        return v

    @field_validator("type")
    @classmethod
    def validate_message_type(cls, v):
        if (
            v
            not in [
                "start",
                "stream",
                "end",
                "error",
                "info",
                "api_code",  # for card
                "chart",  # for chart
                "recommend",  # for recommend
                "error_trace",  # for debug - error traceback
                "prompt",  # for debug - prompt
                "suggestion",  # for suggestion - suggestion
            ]
            and not v.startswith("de.")
            and not v.startswith("kh.")
        ):
            raise ValueError(f"chat response type is not supported: {v}")
        return v

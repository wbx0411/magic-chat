import sys
import os

# 添加项目根目录到sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))
os.environ["RUN_ENV"] = "shan"


import json
import re

import httpx
from biz.task.mc_task_tool import MCTaskTool
from biz.task.metadata import TaskStatus
from framework.llm.llm_manager import LLMManager
from transport.db.postgresdb import PostgresDB
from utils.config_utils import SysConfig
from utils.logger_utils import LoggerFactory
import time

logger = LoggerFactory.get_logger(__name__)
configs = SysConfig.get_config()
llm = LLMManager.create_llm(configs)
tool_configs = SysConfig.get_yaml_config("tool/tool.95598")


class Tool95598(MCTaskTool):
    def init_data(self, task_id: str, task_ext: dict):
        app_nos = task_ext['app_no'] if 'app_no' in task_ext else None
        if app_nos:
            sql_app_nos = ', '.join(["'{}'".format(app_no) for app_no in app_nos.split(",")])
            sql_where = f" a.csc_app_no in ({sql_app_nos}) "
        else:
            sql_where = f"""
                a.mgt_org_code like '{task_ext['org_no'] if not "61102" else "61"}%'
            -- and to_char(a.bus_cplt_time, 'yyyy-mm-dd') >= '{task_ext['handle_day']}'
            """
        # sql_where = " 1=1 "
        commands = [
            # (
            #     f"""
            #         DELETE FROM {self.biz_table} a
            #          WHERE {sql_where}
            #     """, None
            # ),
            (
                f"""
                    INSERT INTO {self.biz_table} ({self.biz_table_cols}) 
                    {tool_configs["init_data"]}
                       and 
                    {sql_where}
                """,
                None,
            ),
            (
                f"""
                    UPDATE {self.biz_table} a
                       SET a.LLM_TASK_ID = '{task_id}',
                           a.LLM_STATUS = '{TaskStatus.INIT.value}',
                           a.LLM_UPDATE_TIME = SYSDATE
                     WHERE a.LLM_TASK_ID = '-9999'
                       and {sql_where}
                """,
                None,
            ),
        ]
        db = PostgresDB(tool_configs["biz_db_name"])
        return db.execute_batch(commands)

    def execute(self, task_detail: dict):
        max_retries = tool_configs.get("biz_max_retries", 1)
        db = PostgresDB(tool_configs["biz_db_name"])
        for index in range(max_retries):
            try:
                answer = llm_invoke(task_detail["question"]).content
                return answer, *self.serialize_answer(task_detail, answer, db)
            except Exception as e:
                logger.error(f"execute task detail error: {task_detail['id']}, retry: {index + 1}")
                if index + 1 == max_retries:
                    raise e

    def serialize_answer(self, task_detail, answer, db):
        json_ans = load_json_str(answer)
        json_ans = json_ans if isinstance(json_ans, list) else [json_ans]
        # 一个工单，智能分析结果中，诉求电话、户号、其中有一个没识别出来就忽略
        json_ans = [
            item
            for item in json_ans
            if (
                item.get("户号") not in ("", "无", "未知", "不清楚")
                and item.get("用户电话") not in ("", "无", "未知", "不清楚")
                and item.get("工单类型") in ("取消", "变更")
            )
        ]
        logger.info(f"serialize answer: {task_detail['id']}, {json_ans=}, {answer=}")
        commands = list()
        for ans_item in json_ans:
            tels = ans_item.get("用户电话").split(",")
            cons_nos = ans_item.get("户号").split(",")
            for tel, cons_no in zip(tels, cons_nos):
                params = {
                    "LLM_CONS_NO": cons_no.strip(),
                    "LLM_TEL": tel.strip(),
                    "LLM_TYPE": ans_item.get("工单类型"),
                    "LLM_STATUS": TaskStatus.DONE.value,
                    "APP_NO": task_detail["busi_id"],
                    "LLM_TASK_ID": task_detail["task_id"],
                }
                if len(commands) == 0:
                    commands.append(
                        (
                            f"""
                    UPDATE {self.biz_table}
                        SET LLM_CONS_NO = %(LLM_CONS_NO)s, LLM_TEL = %(LLM_TEL)s, 
                            LLM_TYPE = %(LLM_TYPE)s, LLM_STATUS = %(LLM_STATUS)s, 
                            LLM_UPDATE_TIME = SYSDATE
                        WHERE {self.biz_col_id} = %(APP_NO)s
                        AND LLM_TASK_ID = %(LLM_TASK_ID)s
                        """,
                            params,
                        )
                    )
                else:
                    commands.append(
                        (
                            f"""
                        INSERT INTO {self.biz_table} ({self.biz_table_cols}, LLM_CONS_NO, LLM_TEL, LLM_TYPE, LLM_STATUS, LLM_UPDATE_TIME)
                        SELECT {self.biz_table_cols}, %(LLM_CONS_NO)s, %(LLM_TEL)s, %(LLM_TYPE)s, %(LLM_STATUS)s, SYSDATE
                            FROM {self.biz_table}
                            WHERE {self.biz_col_id} = %(APP_NO)s
                            AND LLM_TASK_ID = %(LLM_TASK_ID)s
                            limit 1
                        """,
                            params,
                        )
                    )

        assert commands, f"Failed to serialize answer, commands is empty: {task_detail['id']}"
        rowcount = db.execute_batch(commands)
        assert rowcount > 0, f"Failed to serialize answer, execute size 0: {task_detail['id']}"
        return json_ans, rowcount

    def notify(self, task_info: dict):
        httpx.get(tool_configs["biz_notify_url"].format(taskId=task_info['ID']), timeout=3)


def llm_invoke(question: str):
    return llm.invoke(
        [
            ("system", tool_configs["system_prompt"]),
            ("human", tool_configs["user_prompt"].format(message=question)),
        ]
    )


def load_json_str(content):
    # 通过正则表达式匹配json字符串
    json_str = re.findall(r"```json(.*?)```", content, re.DOTALL)
    json_str = json_str[0] if json_str else content
    try:
        return json.loads(json_str)
    except json.JSONDecodeError:
        # 0. 替换换行符和转义字符
        json_str = json_str.replace(r'\n', '').replace(r'\"', '"')
        # 1. 补全缺少的引号
        json_str = re.sub(r'([{,])(\s*)?([A-Za-z0-9_]+)?(:)(\s*)?([{])', r'\1"\3":\5', json_str)
        json_str = re.sub(r'(:)(\s*)?([}])(\s*)?([},])', r'\1"\3"\4', json_str)
        # 2. 补全缺少的逗号和括号
        json_str = re.sub(r'(\s*)?([}])(\s*)?([},])', r'\2,\3', json_str)
        json_str = re.sub(r'(\s*)?([{])(\s*)?', r'\2', json_str)
        # 3. 尝试再次解析补全后的数据
        return json.loads(json_str)


if __name__ == '__main__':
    # from biz.task.mc_task_tool import get_mc_task_tool
    #
    # tool = get_mc_task_tool("95598")
    # ext = {
    #     'org_no': "61401",
    #     'handle_day': "2024-11-13"
    # }
    # ret = tool.init_data(task_id="TEST", task_ext=ext)
    # print(ret)

    msg = (
        ""
        # "【电力短信】客户来电反映，因房子租住的原因，现在要求取消户号为6103946914181的电力短信订阅，接受手机号：13629291482，请相关工作人员核实处理。)"
        # "【错发短信】客户反映，收到[户号为6103944950921]的[催费短信]。客户表示户号非本人。短信发送号码为106804389709559804。客户接收手机号码为18192491913，非客户[更换手机号码、为房屋租户]自身原因造成，认为存在短信错发的问题，请供电公司尽快核实处理。"
        # "【电力短信】客户来电反映，因手机号码变更，现在户号为6103107419661的短信订阅接受手机号由19829266601变更为17791214982的电费/停电信息短信订阅，请相关工作人员核实处理。"
        # "【电力短信】客户反映，收到户号为6106080073252的[电费提醒短信/交费成功短信/阶梯电价提醒短信/催费短信/停电通知短信/等]。客户表示户号非本人。短信发送号码为1068651362095598，客户要求取消的接收手机号码为18710387867。请供电公司尽快核实处理。"
        #    "【电力短信】客户来电反映，需要给户号为6103112448584，接受手机号为15353497835的订阅电费余额预警短信，请相关工作人员核实处理。"
        #    "【电力短信】客户来电反映，因房屋已卖掉，取消户号为6103168909114、接受手机号为13679276184的欠费提醒和别的电费相关短信订阅，请相关工作人员核实处理。"
        #    "【电力短信】客户来电反映，因接受短信的手机号不是自己或家人的，现要将户号为6103079463598的短信订阅接受手机号变更为18909255165和13909205165，客户希望两个手机都能接受短信，另客户表示去年夏天反映过短信接受号码变更的问题，客户表示当时去的营业厅，表示当时营业厅工作人员与客户一起打的95598，但系统未查询到记录，客户需要核实当时为何没有改成功，要求给其一个解释，请相关工作人员核实处理。（客户手机18909255165、13909205165以及座机号87881088都可以联系。）"
        #    "【电力短信】客户来电反映，现在户号为6103246134094的短信订阅接受手机号由13992804362变更为15353700858，请相关工作人员核实处理。另外客户表示13991820009号码保留，不用动 ，回访工单2024110708337037"
        #    "【客户侧用电需求配合】客户来电反映，需要把预留手机号码改成18629454249，方便接收电费短信。现申请对客户侧用电需求进行操作，请尽快核实处理。"
        #    "【电力短信】客户反映，不是自家的电力信息，但仍收到户号为6103759308540的电费提醒电力短信，接收号码13991105532，现要求取消并解绑，请尽快核实处理。"
        #    "【电力短信】客户来电反映，因自己家人再此居住，现在户号为6102004035755的短信订阅接受手机号由13991215903变更为13299097577，请相关工作人员核实处理。"
        #    "【电力短信】客户来电反映，现在户号为6103506212322的短信订阅接受手机号由13289295715变更为13032906621，新增户号为6103506212188接受手机号为13289295715的电费信息短信订阅，请相关工作人员核实处理。"
        #    "【电力短信】客户来电反映因自身原因，要求变更户号为6103814743662、6103908930644、6103510721221、6103947121265、6103947123245的电力短信接收手机号码，变更为13759962067，请相关工作人员核实处理。"
        # "【电力短信】客户来电反映，客户要求取消短信户号：6103745049105接收号码：18092577594，客户短信删除了无法回复。以及户号：6102003079669客户觉得电费有问题希望帮助查看，请相关工作人员核实处理。"
        # "【电力短信】客户来电反映，1、因房屋买卖，现在户号为6103753230074，取消户号为6103753230074、接受手机号为18966806326的短信订阅，2、户号6110000668019  要求订阅电费短信，短信接收号：18966806326，请相关工作人员核实处理。"
        # "【电力短信】客户来电反映因自身原因，要求变更户号为6103814743662、6103908930644、6103510721221、6103947121265、6103947123245的电力短信接收手机号码，变更为13759962067，请相关工作人员核实处理。"
        # "【错发短信】客户反映，收到[户号为6103944950921]的[催费短信]。客户表示户号非本人。短信发送号码为106804389709559804。客户接收手机号码为18192491913，非客户[更换手机号码、为房屋租户]自身原因造成，认为存在短信错发的问题，请供电公司尽快核实处理。"
        # "【客户联系方式调整】户号为6103216293134的客户反映，因[号码更换]原因，申请对该户号的客户[联系电话]进行变更。现将13992877146变更为13991859416，短信也需要同步变更，请尽快核实处理。"
        # "【电力短信】户号为6103151819082的客户反映，因[房子是以前租住的原因]，现要求[取消电费提醒，欠费提醒短信]，[原接收手机号码18710446148，短信发送号码1068541162095598620]，请尽快核实处理。"
        # "【电力短信】客户来电反映，现在户号为6103506212322的短信订阅接受手机号由13289295715变更为13032906621，新增户号为6103506212188接受手机号为13289295715的电费信息短信订阅，请相关工作人员核实处理。"
        # "【电力短信】客户反映，要求将户号为6103190708158的电费预警短信接收号码由自己的号码15091543556变更为13002956516（家人的），且将预留电话一并变更，请供电公司尽快核实处理。"
        # "【电力短信】客户来电反映，因房屋出租了，现在户号为6103228549069的短信订阅接受手机号由13259838398变更为13659154635和15399151067，短信直接发给租户催费，请相关工作人员核实处理。"
        # "【电力短信】客户反映，收到户号为6103127665839的[电费提醒短信/交费成功短信/阶梯电价提醒短信/催费短信/停电通知短信/等]。客户表示户号非本人。短信发送号码为10694937036288 ，客户要求取消的接收手机号码为13474502408 。请供电公司尽快核实处理。"
        # "【电力短信】客户来电反映，因手机号码变更，现在户号为6108208306260的短信订阅接受手机号由17343997578变更为17389291846，请相关工作人员核实处理。"
        # "【电力短信】客户来电反映，因需要更改为实际交费人，现在户号为6103777892683的短信订阅接受手机号由13720409170变更为15596176125，请相关工作人员核实处理。"
        # "【处理完毕】【西咸新区沣东新城】2025年01月07日13时16分，沣东新城供电公司王寺供电所工作人员石海荣（联系电话：13891834456）电话联系客户（联系电话：13759994831，户号：6103777892683）（附件：通话记录），客户管理单位为王寺供电所，客户因自身原因，要求变更联系方式。工作人员已于2025年01月07日13时19分为该客户在系统中将其短信接收号码变更，已即时生效，客户表示满意。处理人：沣东新城供电公司王寺供电所工作人员石海荣，联系电话：13891834456。"
        # "【处理完成】【西安市雁塔区】2024年12月25日14时59分，国网西安市南供电公司曲江中心供电所吉渊哲（83305200）与客户（18682940869）（客户编号：6103255535248）进行联系（附件1），客户反映，收到户号为6103255535251和6103255535248的[电费提醒短信/交费成功短信/阶梯电价提醒短信/催费短信/停电通知短信/等]。客户表示户号非本人。客户要求取消的接收手机号码为18682940869。请供电公司尽快核实处理。经工作人员与客户核实后，于2024年12月25日15时00分将该户号（6103255535251和6103255535248）下客户联系方式18682940869取消，即时生效。客户表示满意。处理人：国网西安市南供电公司曲江中心供电所工作人员吉渊哲，联系电话：83305200。"
        # "【处理完毕】【商洛市山阳县】2024年12月5日17时33分，山阳县供电公司户垣供电所所长陈佩（电话：15891374170）与客户（电话：17386922329，户号：6103142500285）取得联系，客户来电反映，希望能取消户号为6103142500285和6106750000055、接受手机号为15289349396的所有类型短信订阅，请相关工作人员核实处理。解决方案：2024年12月5日18时18分，工作人员告知客户由于短信系统升级中，造成该短信误发送，工作人员联系短信系统后台进行升级。2024年12月6日15时25分，短信系统后台完成系统升级工作并将客户加入短信白名单，工作人员到达客户家中告知客户系统升级后将不再发送错误短信。2024年12月6日15 时35分，陈佩现场将处理结果告知客户，客户表示满意。处理人：山阳县供电公司户垣供电所所长陈佩（电话：15891374170）。"
        # "【处理完成】【西安市雁塔区】2024年12月25日14时59分，国网西安市南供电公司曲江中心供电所吉渊哲（83305200）与客户（18682940869）（客户编号：6103255535248）进行联系（附件1），客户反映，收到户号为6103255535251和6103255535248的[电费提醒短信/交费成功短信/阶梯电价提醒短信/催费短信/停电通知短信/等]。客户表示户号非本人。客户要求取消的接收手机号码为18682940869。请供电公司尽快核实处理。经工作人员与客户核实后，于2024年12月25日15时00分将该户号（6103255535251和6103255535248）下客户联系方式18682940869取消，即时生效。客户表示满意。处理人：国网西安市南供电公司曲江中心供电所工作人员吉渊哲，联系电话：83305200。"
        # "【电力短信】客户反映，收到[客户停电信息告知短信]。客户表示户号非本人。短信发送号码为106934672095598，106814836200000001，1068002395598699，客户要求取消的接收手机号码为15559465360，18392142468，请供电公司尽快核实处理。"
        "【电力短信】客户来电反映，因手机号码变更，现在更改户号为6103689114046的短信订阅，接受手机号从13649249482改为15580024201，请相关工作人员核实处理。"
    )
    print(msg)
    for i in range(10):
        try:
            ans = llm_invoke(msg)
            print("===" + ans.content + "===")
            print(load_json_str(ans.content))
        except Exception as e:
            print(e)

import jionlp as jio

from framework.algorithm.simple_bm25 import SimpleBM25

# text = '聚氯乙烯树脂、塑料制品、切割工具、人造革、人造金刚石、农药（不含危险化学品）、针纺织品自产自销。...'
# word_dict = {'聚氯乙烯': 1, '塑料': 1, '切割': 1, '金刚石': 1}  # 词汇: 词频（词频若未知可全设 1）
# key_phrases = jio.keyphrase.extract_keyphrase(text, top_k=-1, specified_words=word_dict)
# print(key_phrases)


# text = '国务院下发通知，山西省法院、陕西省检察院、四川省法院、成都市教育局。...'
# word_dict = {'局': 1, '国务院': 1, '检察院': 1, '法院': 1}
# key_phrases = jio.keyphrase.extract_keyphrase(text, top_k=-1, specified_words=word_dict,
#                                          remove_phrases_list=['麻将局'])
# print(key_phrases)

# input_file = 'question_text.txt'
# new_words_dict = jio.new_word.new_word_discovery(input_file, min_freq=20, min_entropy=0.1)
# print(new_words_dict)

# jio.help()
#
#
# china_location = jio.parse_location()


bm25 = SimpleBM25()
doc = [
    {'_id': 3705, 'name': '高损', 'code': '01', 'label': '维度值', 'desc': '', '_score': 0.8450199365615845},
    {'_id': 3706, 'name': '负损', 'code': '02', 'label': '维度值', 'desc': '', '_score': 0.8355925679206848}
]
result = bm25.query(doc, '陕西昨日高损台区明细', min_score=0.8)
print(result)
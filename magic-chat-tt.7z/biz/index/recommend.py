import time

from biz.index.dqs_client import make_sentence_list, DQSClient
from biz.index.get_knowledge import get_index, get_org
from biz.index.metadata import label_idx_dim, idx_vec_pre, label_idx, label_idx_val
from framework.algorithm.embed_dis import l2_distance
from framework.algorithm.jionlp_data_collect import jio_parse_time_point, time_wash_text
from framework.algorithm.simple_bm25 import SimpleBM25
from framework.embedding.m3e_client import m3e_client
from utils.config_utils import SysConfig
from utils.date_utils import parse_recommend_date
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)
configs = SysConfig.get_config()
bm25 = SimpleBM25()
dqs_client = DQSClient(configs['dqs_base_url'], configs['dqs_token'], configs['http_timeout'])


def recommend_index(db_namespace, neo4j, nodes_ind, message_content,
                    message_embedding, org_name_query, org_no,
                    user_id, data_time):
    recommend_data = []
    parse_data_time = jio_parse_time_point(message_content, format_str="")
    recommend_data_time = parse_recommend_date(parse_data_time[0]) if parse_data_time else ''
    recommend_org_name = org_name_query
    recommend_dim_name = []

    for node in nodes_ind:
        # 获取维度列表，手工拼装请求参数，未来由llm完成
        dimensions = neo4j.get_neighbor_nodes(db_namespace, node['_id'], label_idx_dim)
        if len(dimensions) == 0:
            recommend_dim_name.append(node['name'])
            continue

        for dim in dimensions:
            # 获取纬度值列表
            index_name = neo4j.get_index_name(idx_vec_pre, db_namespace, label_idx)
            dim_values = neo4j.retrieve_sub_nodes_by_vector(
                db_namespace, index_name, label_idx, message_embedding,
                {'ID(n)': dim["_id"], 'n.label': label_idx_dim}, limit=3)
            dim_values = [value for value in dim_values if value['label'] == label_idx_val]

            # 存在纬度值配置
            if dim_values:
                # 原子指标拼接维度值 与 问题匹配
                for value in list(dim_values):
                    kg_name = node['name'] + value['name'] if 'name' in value else '未知'
                    kg_embedding_response = m3e_client.get_embeddings(kg_name, configs['m3e_model_name'])
                    kg_embedding = kg_embedding_response['data'][0]['embedding'] if kg_embedding_response else None
                    if l2_distance(kg_embedding, message_embedding) > configs['min_score_l2_vector']:
                        dim_values.remove(value)
                    if dim_values:
                        # 先向量，后bm排序，纬度值只保留最相近的
                        dim_values_match = bm25.query(dim_values, message_content, 1,
                                                      min_score=float(configs['min_score_dim_val']), log_level="debug")

                        # 问话匹配到了纬度值
                        if len(dim_values_match) > 0 and isinstance(dim_values_match[0], dict):
                            recommend_dim_name.append(dim_values_match[0]['name'] + node['name'])

            # 匹配问话当中是否包含列出此维度各个纬度值
            dim_match_doc = [{"name": x} for x in make_sentence_list(dim['name'])]
            dim_match = bm25.query(dim_match_doc, message_content, 1,
                                   min_score=configs['min_score_dim_val'], log_level="debug")

            # 问话没有匹配到任何纬度值，或者问话提到了维度，则设置请求参数维度为全部明细维度
            if len(dim_match) > 0 and dim['name'] != node['name']:
                recommend_dim_name.append(dim['name'] + node['name'])
            else:
                recommend_dim_name.append(node['name'])

    if len(recommend_dim_name) > 0:
        recommend_dim_name = list(set(recommend_dim_name))
        if recommend_org_name:
            for dim_name in recommend_dim_name:
                recommend_data.append(f"{data_time}{recommend_data_time}{recommend_org_name}{dim_name}")
        else:
            for dim_name in recommend_dim_name:
                recommend_data.append(f"{data_time}{recommend_data_time}{dim_name}")

    recommend_data_wash = []
    try:
        for recommend_txt in recommend_data:
            recommend_txt = time_wash_text(recommend_txt)
            # 请求嵌入文本
            embedding_response = m3e_client.get_embeddings(recommend_txt, configs['m3e_model_name'])
            if embedding_response is None:
                return "空", 0, []
            embedding = embedding_response['data'][0]['embedding']
            # 原子指标检索
            nodes_ind, scene_flag = get_index(neo4j, db_namespace, recommend_txt, embedding, configs['top_k'])

            # 检索供电单位
            org_no_query, org_name_query = get_org(neo4j, db_namespace, message_content, embedding, org_no)

            try:
                dqs_data, dqs_url_params = dqs_client.get_data_by_kg(db_namespace, neo4j,
                                                                     nodes_ind[:1],
                                                                     recommend_txt,
                                                                     embedding,
                                                                     org_no_query,
                                                                     user_id, data_time, org_name_query)
            except Exception as e:
                logger.error(f"recommend request dqs failed. {e}")

            if dqs_data[0]['指标值'] != '空':
                recommend_data_wash.append(recommend_txt)

    except Exception as e:
        logger.error(f"recommend request dqs failed. {e}")

    return recommend_data_wash

import logging.config
import os

import yaml


class LoggerFactory:
    _initialized = False

    @staticmethod
    def get_logger(name=__name__):
        if not LoggerFactory._initialized:
            current_dir = os.path.dirname(__file__)
            config_file = os.path.join(current_dir, '..', 'configs', 'logging_config.yml')
            with open(config_file, 'r') as f:
                config = yaml.safe_load(f.read())
                logging.config.dictConfig(config)
                LoggerFactory._initialized = True
        _logger = logging.getLogger(name)
        return _logger


if __name__ == '__main__':
    logger = LoggerFactory().get_logger(__name__)
    logger.info("info")
    logger.debug("debug")
    logger.error("error")

import asyncio
import random


async def async_function(fun_id):
    random_time = random.randint(1, 5)
    await asyncio.sleep(random_time)
    print(f"Task {fun_id} completed after {random_time} seconds")
    return fun_id, random_time


async def main():
    tasks = [async_function(i) for i in range(1, 6)]
    print(await asyncio.gather(*tasks))


asyncio.run(main())

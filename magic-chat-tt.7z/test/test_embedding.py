from framework.algorithm.embed_dis import l2_distance
from framework.embedding.m3e_client import m3e_client
from utils.config_utils import SysConfig

configs = SysConfig.get_config()


response1 = m3e_client.get_embeddings('业扩环节达标数考核', "bge-small-zh-v1.5")
response2 = m3e_client.get_embeddings('业扩环节达标数低压非居民', "bge-small-zh-v1.5")
message_embedding = m3e_client.get_embeddings("交流三百五十kV", "bge-small-zh-v1.5")

print(l2_distance(response1['data'][0]['embedding'], message_embedding['data'][0]['embedding']))
print(l2_distance(response2['data'][0]['embedding'], message_embedding['data'][0]['embedding']))


# import jionlp as jio
# print(jio.money_num2char("交流750kV"))
# print(jio.check_any_arabic_num("交流750kV"))





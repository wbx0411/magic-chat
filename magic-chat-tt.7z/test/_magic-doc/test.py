# for local file
import re
from magic_doc.docconv import DocConverter, S3Config


import os

files = [
    # "(优先)供电营业规则（2024年6月1日起施行）.pdf",
    "00 培训资料 - 功能并发重复场景.pptx",
    "1.代收整理.docx",
    "04 -自定义查询.doc",
    "JIRA培训资料_20170821.ppt",
]
current_dir = os.path.dirname(__file__)
converter = DocConverter(s3_config=None)
for f in files:
    try:
        print("=" * 20 + f + "=" * 20)
        markdown_content, time_cost = converter.convert(
            current_dir + "/" + f,
            conv_timeout=300,
            progress_file_path=f'{current_dir}/progress/{f}.txt',
        )
        markdown_content = re.sub(r'\n+', '\n', markdown_content)
        print(markdown_content)
    except Exception as e:
        print(f"Error converting {f}: {e}")
        print("=" * 20)
        continue

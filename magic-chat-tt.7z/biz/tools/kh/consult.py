from biz.tools import RTN_TYPE
from biz.tools.tool_manager import BaseTool, ExecResult, m3e_embedding
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)

KH_TYPE = 'consult'


class Consult(BaseTool):
    async def execute(self, **kwargs):
        logger.info(f"Consult execute: {kwargs}")
        input_emb = m3e_embedding(kwargs['input_msg'])

        results = self.db.query(
            """
            select kh_name, kh_desc, kh_content, kh_name_desc_emb <-> %s::vector AS distance 
              from ai_tool_kh 
             where kh_type = %s
             order by kh_name_desc_emb <-> %s::vector
             limit %s
            """,
            (
                input_emb,
                KH_TYPE,
                input_emb,
                self.chat_chain.configs.get("top_k", 3),
            ),
        )
        return ExecResult(
            [
                {
                    "busi": result["kh_name"],
                    "question": result["kh_desc"],
                    "answer": result["kh_content"],
                    "distance": result["distance"],
                }
                for result in results
                if result["distance"] < self.configs.get("distance_threshold", 15)
            ],
            self.configs['tool_code'],
        )

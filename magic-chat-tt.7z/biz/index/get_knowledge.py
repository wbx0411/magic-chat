import time

from biz.index import metadata
from biz.index.datas import graph_import
from framework.algorithm.simple_bm25 import SimpleBM25
from utils.config_utils import SysConfig
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)
bm25 = SimpleBM25()
configs = SysConfig.get_config()


def get_index(neo4j, db_namespace, message_content, embedding, db_top):
    _time_start = time.time()
    graph_index_idx = neo4j.get_index_name(graph_import.idx_vec_pre, db_namespace, graph_import.label_idx)

    # 检索场景
    logger.info("Scene search start...")
    nodes_scene_search = neo4j.retrieve_nodes_by_vector(
        db_namespace,
        graph_index_idx,
        graph_import.label_scene,
        embedding,
        limit=db_top * 5
    )
    scene_flag = False

    if nodes_scene_search and nodes_scene_search[0]['_score'] > configs['scene_distance_threshold']:
        scene_code = nodes_scene_search[0]['code']
        scene_id = nodes_scene_search[0]['_id']
        scene_name = nodes_scene_search[0]['name']
        logger.info(f"Scene result: {scene_code} - {scene_name} "
                    f"- {nodes_scene_search[0]['_score']} - {configs['scene_distance_threshold']}")
        scene_node_index = neo4j.get_neighbor_nodes(db_namespace, scene_id, graph_import.label_idx)
        # todo: 场景检索优化
        nodes_ind_rank = scene_node_index
        scene_flag = True

    else:
        logger.info("Scene not found. Continue to retrieve index...")
        # 检索原子指标
        nodes_ind_search = neo4j.retrieve_nodes_by_vector(
            db_namespace,
            graph_index_idx,
            graph_import.label_idx_yz,
            embedding,
            limit=db_top * 3
        )

        _time_bm25 = time.time()
        logger.info(f"Search index duration: {_time_bm25 - _time_start}")
        logger.info(f"Search index result: {nodes_ind_search[:3]}")
        # bm25重新排序
        nodes_ind_rank = bm25.query(nodes_ind_search, message_content, db_top * 5,
                                    min_score=float(configs['min_score_index']))
        logger.info(f"Rerank index duration: {time.time() - _time_bm25}")

    return nodes_ind_rank, scene_flag


def get_org(neo4j, db_namespace, message_content, embedding, org_no):
    _time_start = time.time()
    index_org_vec = neo4j.get_index_name(metadata.idx_vec_pre, db_namespace, metadata.label_org)
    index_org_fts = neo4j.get_index_name(metadata.idx_fts_pre, db_namespace, metadata.label_org)

    # # 检索供电单位
    # org_conditions = {"n.code": org_no}
    # # 去掉原来的检索供电单位逻辑
    # org_list = neo4j.retrieve_sub_nodes_by_vector(db_namespace, index_org_vec, metadata.label_org, embedding,
    #                                               org_conditions, float(configs['min_score_org']), 10)
    # org_list = bm25.query(org_list, message_content, 1, min_score=0.01)

    # 改为混合检索并使用简称+全程评分的最高分，再进行比较
    org_type_list = [f'{i:02}' for i in range(1, int(configs['org_type_limit']) + 1)]
    org_conditions = [f"n.code = '{org_no}'", f"node_ft.type in {org_type_list}"]
    org_list = neo4j.retrieve_sub_nodes_by_hybrid(db_namespace, index_org_vec, index_org_fts, metadata.label_org,
                                                  message_content, embedding, org_conditions,
                                                  float(configs['min_score_org']), int(configs['org_top_k']))
    org_list = match_org(message_content, org_list)

    org_no_query = org_list[0]['code'] if org_list else org_no
    org_name_query = org_list[0]['name'] if org_list else neo4j.get_node_desc_by_code(org_no)[2:4]

    # org_name_query =

    _time_end = time.time()
    logger.info(f"Search org result: {org_no} -> {org_no_query}")
    logger.info(f"Search org duration: {_time_end - _time_start}")

    return org_no_query, org_name_query


# 从候选供电单位列表中匹配问题，使用name和desc（可以多个以逗号分隔），共同评分，以最高分参与排序
def match_org(message_content, org_list, min_score=0.01):
    org_match = []
    for org in org_list:
        org_doc = [{'name': org['name'], 'object': org}]
        if org['desc']:
            org_desc_split = org['desc'].split(',')
            for desc in org_desc_split:
                org_doc.append({'name': desc, 'object': org})
        org_match_inner = bm25.get_scores_separate(org_doc, message_content)
        if org_match_inner:
            org_match.append(org_match_inner[0])
    org_match = [doc for doc in org_match if
                 doc[1] > min_score and not org_name_filter(message_content, doc[0]['name'])]
    org_match.sort(key=lambda x: x[1], reverse=True)

    return [doc['object'] for doc, _ in org_match[:1]]


def org_name_filter(message, org_name):
    return ('客户服务中心' not in message and '客服中心' not in message) and (
            '客户服务中心' in org_name or '客服中心' in org_name)


if __name__ == '__main__':
    _namespace = configs['neo4j_config']['namespace']
    _org_no = configs['auth_mock_org']

    from transport.db.neo4jdb import Neo4jDB

    _neo4j = Neo4jDB()

    _message_content_list = [
        '沈阳局本年应收电费',
        '沈阳市总户数',
        '沈阳市法库局本年应收电费',
        '沈阳市法库本年应收电费',
        '辽宁省沈阳市法库县供电公司本年应收电费',
        '法库本年应收电费',
        '沈阳客服中心本年应收电费',
        '沈阳客户服务中心本年应收电费',
        '铁岭客户服务中心本年应收电费',
        '铁岭客服中心本年应收电费',
        '大连客服中心本年应收电费',
        '大连客户服务中心本年应收电费',
        '本年电费回收率',
        '临渭本年电费回收率',
        '渭南本年电费回收率',
        '西安本年电费回收率',
        '台区明细'
    ]

    from framework.embedding.m3e_client import m3e_client

    _result = {}
    for _message_content in _message_content_list:
        _embedding = m3e_client.get_embeddings(_message_content, configs['m3e_model_name'])['data'][0][
            'embedding']
        _o = get_org(_neo4j, _namespace, _message_content, _embedding, _org_no)
        _i = get_index(_neo4j, _namespace, _message_content, _embedding, 3)
        _result[_message_content] = {'org': _o, 'index': _i}
    for k, v in _result.items():
        print(f"{k} - {v}")

# 交费复电
import json

from langchain_core.tools import BaseTool

background_info = """
交费复电情况：
复电工单148条
已交费未生成复电指令户数为0户。
其中排名前三的用户如下：
| 户号 | 交费时间 | 余额 |
|------|----------|------|
"""


class PaymentBasedReconnection(BaseTool):
    name = "昨日交费复电情况"
    description = """
        获取昨日交费复电情况
        """
    return_direct = False

    def __init__(self):
        super().__init__()

    async def _arun(self, cons_no: str) -> str:
        output = {
            "result": f"{background_info}",
            "key": "pbr"
        }
        json_data = json.dumps(output, ensure_ascii=False)
        return json_data

    def _run(self, cons_no: str) -> str:
        pass

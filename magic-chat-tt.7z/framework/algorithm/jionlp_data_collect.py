import datetime
import time

import jionlp as jio


def _parse_date(date_str):
    return datetime.datetime.strptime(date_str, "%Y-%m-%d %H:%M:%S").date()


def _generate_dates(start, end):
    current = start
    while current <= end:
        yield current
        current += datetime.timedelta(days=1)


def parse_time(input_string):
    """
    Parse time from input string
    :param input_string:
    :return: type   time_point|time_span, time  ['2024-01-01 00:00:00', '2024-12-31 23:59:59']
    """
    result = jio.parse_time(input_string, time_base=time.time())
    return _time_list_and_type(result['type'], result['time'])


def jio_parse_time_multi(input_str, time_type='time_point', format_str="%Y%m%d", time_base=None):
    split_text = jio.split_sentence(input_str, criterion='fine')
    dates = []
    for text in split_text:
        try:
            if (date := jio_parse_time(text, format_str, time_base)) is not None:
                dates.append(date)
        except Exception:
            pass
    if not dates:
        return None
    return zip(*[(_, date) for _, date in dates if date['type'] == time_type])


def jio_parse_time(input_str, format_str="%Y%m%d", time_base=None):
    try:
        time_base = time_base or time.time()
        date = jio.parse_time(input_str, time_base=time_base)
    except Exception:
        return None
    if date['type'] == 'time_point':
        return _parse_date(date['time'][0]).strftime(format_str), date
    elif date['type'] == 'time_span':
        return [_parse_date(_).strftime(format_str) for _ in date['time']], date
    elif date['type'] == 'time_period':
        return date['time'], date
    else:
        return date['time'], date


def _time_list_and_type(time_type, times):
    """
    如果是time_point，
    两个日期相同的，返回一个日期，时间类型是日累计，01
    两个日期跨度是一个月的，返回月的第一天，时间类型是月累计，03
    两个日期跨度是一年的，返回年的第一天，时间类型是年累计，05
    如果是time_span，
    时间跨度小于一个月的，时间类型是日累计，01，返回所有日的列表
    时间跨度大于一个月并且小于一年，时间类型是月累计，03，返回所有月的第一天的列表
    时间跨度大于一年的，时间类型是年累计，05，返回所有年的第一天的列表
    """
    start_date = _parse_date(times[0])
    end_date = _parse_date(times[1])
    result = None
    if time_type == "time_point":
        if start_date == end_date:
            # 日累计
            result = ([start_date.strftime("%Y-%m-%d")], '01')
        elif 28 <= (end_date - start_date).days <= 31:
            # 月累计
            result = ([start_date.strftime("%Y-%m-01")], '03')
        elif 364 <= (end_date - start_date).days <= 366:
            # 年累计
            result = ([start_date.strftime("%Y-01-01")], '05')
    elif time_type == "time_span":
        delta_days = (end_date - start_date).days
        if delta_days < 28:
            # 日累计
            dates = [date.strftime("%Y-%m-%d") for date in _generate_dates(start_date, end_date)]
            result = (dates, '01')
        elif 28 <= delta_days < 365:
            # 月累计
            months = set()
            current = start_date
            while current <= end_date:
                months.add(current.strftime("%Y-%m-01"))
                current += datetime.timedelta(days=1)
            result = [sorted(list(months)), '03']
        else:
            # 年累计
            years = set()
            current = start_date
            while current <= end_date:
                years.add(current.strftime("%Y-01-01"))
                current += datetime.timedelta(days=365)
            result = (sorted(list(years)), '05')
    # 2024-01-01 to 20240101
    for i in range(len(result[0])):
        result[0][i] = result[0][i].replace("-", "")
    return result


def jio_parse_time_span(input_str, format_str="%Y%m%d", time_base=None):
    split_text = jio.split_sentence(input_str, criterion='fine')
    dates = [jio_parse_time(text, format_str, time_base) for text in split_text]
    return [date[0] for date in dates if date and date[1]['type'] == 'time_span']


def jio_parse_time_point(input_str, format_str="%Y%m%d", time_base=None):
    """
    解析时间，精确返回时间格式，可能是时间点或时间段，目前时间点只支持年、年月、年月日
    """
    split_text = jio.split_sentence(input_str, criterion='fine')
    time_base = time.time()
    dates = []
    for text in split_text:
        try:
            if (date := jio_parse_time(text, format_str, time_base)) is not None:
                dates.append(date)
        except Exception:
            pass
    if not dates:
        return None

    datas_format = []
    for date in dates:
        d = date[1]
        if d['type'] == 'time_point' or d['type'] == 'time_span':
            d1_str = d['time'][0]
            d2_str = d['time'][1]
            if '00:00:00' in d1_str and '23:59:59' in d2_str:
                d1 = datetime.datetime.strptime(d1_str, "%Y-%m-%d %H:%M:%S")
                d2 = datetime.datetime.strptime(d2_str, "%Y-%m-%d %H:%M:%S")
                if '01 00:00:00' in d1_str:
                    next_year = d1.year if d1.month < 12 else d1.year + 1
                    next_month = d1.month + 1 if d1.month < 12 else 1
                    if (
                        datetime.datetime(next_year, next_month, 1) - datetime.timedelta(seconds=1)
                        == d2
                    ):
                        datas_format.append(d1.strftime("%Y%m"))
                    elif (
                        datetime.datetime(d1.year + 1, d1.month, 1) - datetime.timedelta(seconds=1)
                        == d2
                    ):
                        datas_format.append(d1.strftime("%Y"))
                    else:
                        datas_format.append(d1.strftime("%Y%m%d"))
                else:
                    datas_format.append(d1.strftime("%Y%m%d"))
    return datas_format


def time_wash_text(input_str):
    wash_input = input_str
    res = jio.ner.extract_time(input_str, time_base=time.time(), with_parsing=False)
    for i in res:
        wash_input = wash_input.replace(i['text'], '')

    return wash_input


if __name__ == '__main__':
    inputStr = '''
    据央视新闻消息，福建省莆田市政府召开疫情防控情况新闻发布会，12月13日，介绍最新情况。
    据通报，从本月10日至12日16时，大约两天时间内，累计报告新冠病毒核酸阳性64例，平均每日新增病例30例，
    其中确诊病例32例、无症状感染者32例。本年共1000例，今年10月共100例。
    '''
    # inputStr = "查询一下去年3月到今年1月西安的售电量"
    # ds, dss = jio_parse_time_multi(inputStr, time_type='time_point', format_str="%Y%m%d")
    # print(ds, dss)

    ds = jio_parse_time_span(inputStr, format_str="%Y%m")
    print(ds)

    # ds = time_wash_text(inputStr)
    # print(ds)

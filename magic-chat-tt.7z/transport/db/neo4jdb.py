from threading import Lock
from typing import Dict, List

from py2neo import Graph, NodeMatcher

from utils.config_utils import SysConfig
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)


class Neo4jDB:
    _engine = None
    _transaction = None
    _lock = Lock()

    def __init__(self, config: str = 'neo4j_config'):
        if not config:
            raise ValueError("Neo4jDB config is required")

        self._config = SysConfig.get_config(config)
        self._limit = int(self._config['limit'])

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close_engine()

    def _initialize_engine(self):
        if self._engine is None:
            with self._lock:
                if self._engine is None:
                    self._engine = self.create_graph(self._config)
                    self._transaction = self._engine.begin()

    def get_engine(self):
        if self._engine is None:
            self._initialize_engine()
        return self._engine

    def close_engine(self):
        if self._engine:
            with self._lock:
                if self._engine:
                    self._engine.commit(self._transaction)
                    self._transaction = None
                    self._engine = None

    @staticmethod
    def create_graph(config):
        return Graph(
            config["url"],
            auth=(config["user"], config["password"]),
            name=config["database"]
        )

    @staticmethod
    def get_all_nodes():
        with Neo4jDB() as db:
            return [(node['code'], node['name']) for node in db.get_engine().nodes.match()]

    @staticmethod
    def get_node_by_ids(node_ids, label=None):
        with Neo4jDB() as db:
            nodes = '"' + '\",\"'.join([node for node in node_ids]) + '"'
            return db.get_engine().query(f"MATCH (n) WHERE n.id in [{nodes}] RETURN n")

    def get_node_desc_by_code(self, node_code, label='供电单位'):
        return self.get_engine().run(f"MATCH (n:{label} {{code: '{node_code}'}}) RETURN n.desc").data()[0]['n.desc']

    @staticmethod
    def get_index_name(prefix, *labels):
        return prefix + '_' + '_'.join(labels)

    def match_nodes(self, *labels, **properties):
        matcher = NodeMatcher(self.get_engine())
        nodes = matcher.match(*labels, **properties).limit(self._limit)
        nodes = [node for node in nodes]
        logger.debug(f"Matched {len(nodes)} nodes.")
        return nodes

    def update_node(self, node, *labels, **properties):
        if properties:
            for key, value in properties.items():
                node[key] = value
        if labels:
            node.update_labels(labels)
        self.get_engine().push(node)
        logger.debug(f"Node {node} updated.")
        return node

    def run(self, cypher):
        self.get_engine().run(cypher)

    def query(self, cypher):
        result = self.get_engine().run(cypher).data()
        return result

    def create_index_vector(
            self,
            index_name,
            prop,
            dimensions,
            similarity_function='cosine',
            *labels
    ):
        label_str = ':'.join(labels)
        cypher = f"""
        CREATE VECTOR INDEX {index_name} IF NOT EXISTS
        FOR (m:{label_str})
        ON m.{prop}
        OPTIONS {{indexConfig: {{
         `vector.dimensions`: {dimensions},
         `vector.similarity_function`: '{similarity_function}'
        }}}}
        """
        logger.debug(cypher)
        return self.get_engine().run(cypher)

    def create_index_fts(
            self,
            index_name: str,
            label: str,
            props: List[str],
            analyzer: str = 'cjk',
            eventually_consistent: str = 'true'
    ):
        """
        生成Node的全文检索索引

        SHOW FULLTEXT INDEXES
        call db.index.fulltext.listAvailableAnalyzers
        """
        # analyzer = 'standard-no-stop-words'
        properties_str = ','.join([f'n.{p}' for p in props])
        cypher = f"""
        CREATE FULLTEXT INDEX {index_name} IF NOT EXISTS
        FOR (n:{label}) ON EACH [{properties_str}]
        OPTIONS {{
          indexConfig: {{
            `fulltext.analyzer`: '{analyzer}',
            `fulltext.eventually_consistent`: {eventually_consistent}
          }}
        }}
        """
        logger.debug(cypher)
        return self.get_engine().run(cypher)


    def get_neighbor_nodes(self, namespace, node_id, subgraph_label, limit=None) -> List[Dict]:
        limit = limit or self._limit
        namespace_str = f':{namespace}' if namespace else ''
        label_str = f'{namespace_str}:{subgraph_label}' if subgraph_label else namespace_str
        cypher = f"""
        MATCH (n{namespace_str})-[r{namespace_str}]-(m{label_str})
        WHERE ID(n) = {node_id}
        RETURN DISTINCT ID(m) AS _id, m.name AS name, m.code AS code, m.label AS label, m.desc AS desc, r.weight as weight
        LIMIT {limit}
        """
        logger.debug(cypher)
        return self.get_engine().run(cypher).data()

    def retrieve_nodes_by_vector(self, namespace, index_name, label, text_embedding, limit=None) -> List[Dict]:
        limit = limit or self._limit
        label_str = f':{namespace}:{label}' if label else f':{namespace}'
        cypher = f"""
        CALL db.index.vector.queryNodes('{index_name}', {limit}*10, {text_embedding})
        YIELD node, score
        MATCH (node {label_str})
        RETURN DISTINCT ID(node) AS _id, node.name AS name, node.code AS code, node.label AS label, node.desc AS desc, score AS _score
        ORDER BY _score DESC 
        LIMIT {limit}
        """
        logger.debug(cypher)
        return self.get_engine().run(cypher).data()

    def retrieve_sub_nodes_by_vector(
            self,
            namespace,
            index_name,
            label,
            text_embedding,
            conditions,
            score=0.0,
            limit=None
    ) -> List[Dict]:
        limit = limit or self._limit
        label_str = f':{namespace}:{label}' if label else f':{namespace}'
        r_type_str = f':{namespace}'
        conditions_str = f"WHERE score >= {score}"
        if conditions:
            for key, value in conditions.items():
                if isinstance(value, (int, float)):
                    conditions_str = f"{conditions_str} AND {key} = {value}"
                else:
                    conditions_str = f"{conditions_str} AND {key} = '{value}'"

        # 构造Cypher查询语句，用于向量搜索和条件筛选
        cypher = f"""
        CALL db.index.vector.queryNodes('{index_name}', {limit * 500}, {text_embedding})
        YIELD node, score
        MATCH(n {label_str})-[{r_type_str} *0..100]->(node {label_str})
        {conditions_str}
        RETURN DISTINCT ID(node) AS _id, node.name AS name, node.code AS code, node.label AS label, node.desc AS desc, score AS _score
        ORDER BY _score DESC
        LIMIT {limit} 
        """
        logger.debug(cypher)
        return self.get_engine().run(cypher).data()

    def retrieve_sub_nodes_by_hybrid(
            self,
            namespace,
            index_vector,
            index_fts,
            label,
            text,
            text_embedding,
            conditions,
            score=0.0,
            limit=None
    ) -> List[Dict]:
        limit = limit or self._limit
        label_str = f':{namespace}:{label}' if label else f':{namespace}'
        r_type_str = f':{namespace}'
        conditions_str = f"WHERE score_vec >= {score}"
        if conditions:
            conditions_str = f"{conditions_str} AND {' AND '.join(conditions)}"
        cypher = f"""
        CALL db.index.vector.queryNodes('{index_vector}', {limit * 500}, {text_embedding})
        YIELD node AS node_vec, score AS score_vec
        WITH node_vec, score_vec
        CALL db.index.fulltext.queryNodes('{index_fts}', '{text}')
        YIELD node AS node_ft, score AS score_ft 
        WHERE elementId(node_ft) = elementId(node_vec)
        MATCH(n {label_str})-[{r_type_str} *0..100]->(node_ft {label_str})
        {conditions_str}
        RETURN DISTINCT ID(node_ft) AS _id, node_ft.name AS name, node_ft.code AS code, node_ft.label AS label, node_ft.desc AS desc, score_vec AS _score, score_ft AS _score_ft
        ORDER BY _score_ft DESC
        LIMIT {limit} 
        """
        logger.debug(cypher)
        return self.get_engine().run(cypher).data()


if __name__ == '__main__':
    _db = Neo4jDB()

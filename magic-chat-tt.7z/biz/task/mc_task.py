import json
import traceback
import uuid
from datetime import datetime

from biz.task.mc_task_tool import get_mc_task_tool
from biz.task.metadata import TaskStatus
from transport.db.postgresdb import PostgresDB
from utils.config_utils import SysConfig
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)

configs = SysConfig.get_config()
db = PostgresDB(configs["app_db_name"])
table_task_info = configs["table_task_info"]
table_task_detail = configs["table_task_detail"]


def create_task(task_type: str, ext: str, creator: str, desc: str = None):
    sql = f"""
        INSERT INTO {table_task_info} (
            ID, TASK_TYPE, TASK_STATUS, TASK_DESC, TASK_EXT,
            CREATOR, CREATE_TIME, MODEL_NAME, VERSION
        ) values (
            %(ID)s, %(TASK_TYPE)s, %(TASK_STATUS)s, %(TASK_DESC)s, %(TASK_EXT)s, 
            %(CREATOR)s, SYSDATE, %(MODEL_NAME)s, %(VERSION)s
        )
    """
    task_info = {
        'ID': str(uuid.uuid4()).replace("-", ""),
        'TASK_TYPE': task_type,
        'TASK_STATUS': TaskStatus.INIT.value,
        'TASK_DESC': desc,
        'TASK_EXT': ext,
        "CREATOR": creator,
        "MODEL_NAME": configs["model_name"],
        "VERSION": configs["version"],
    }
    assert db.execute(sql, task_info) == 1, f"Failed to create task: {task_type}"
    return task_info


def run_task(task_id: str):
    sql = f"""
        UPDATE {table_task_info}
           SET TASK_STATUS = %(TASK_STATUS)s, START_TIME = SYSDATE
         WHERE ID = %(ID)s
    """
    task_info = {'ID': task_id, 'TASK_STATUS': TaskStatus.RUNNING.value}
    assert db.execute(sql, task_info) == 1, f"Failed to run task: {task_id}"


def complete_task(task_id: str, result: str = None):
    sql = f"""
        UPDATE {table_task_info}
           SET TASK_STATUS = %(TASK_STATUS)s, END_TIME = SYSDATE, RESULT = %(RESULT)s
         WHERE ID = %(ID)s
    """
    task_info = {'ID': task_id, 'TASK_STATUS': TaskStatus.DONE.value, 'RESULT': result}
    assert db.execute(sql, task_info) == 1, f"Failed to complete task: {task_id}"


def exception_task(task_id: str, exception: str):
    sql = f"""
        UPDATE {table_task_info}
           SET TASK_STATUS = %(TASK_STATUS)s, END_TIME = SYSDATE, RESULT = %(RESULT)s
         WHERE ID = %(ID)s
    """
    task_info = {'ID': task_id, 'TASK_STATUS': TaskStatus.EXC.value, 'RESULT': exception}
    assert db.execute(sql, task_info) == 1, f"Failed to exception task: {task_id}"


def get_task_by_id(task_id: str):
    sql = f"""
        SELECT * FROM {table_task_info} WHERE ID = %(ID)s
    """
    result = db.query(sql, (task_id,))
    return result[0] if result else None


##############################################################################################################
#
def create_task_detail(task_id: str, biz_table: str, biz_col_id: str, biz_col_question: str):
    sql = f"""
        INSERT INTO {table_task_detail} (
            TASK_ID, BUSI_ID, QUESTION, STATUS, CREATE_TIME
        ) 
        SELECT %(TASK_ID)s, {biz_col_id}, {biz_col_question}, %(STATUS)s, SYSDATE
          FROM {biz_table}
         where llm_task_id = %(TASK_ID)s
    """
    task_detail = {'TASK_ID': task_id, 'STATUS': TaskStatus.INIT.value}
    rowcount = db.execute(sql, task_detail)
    assert rowcount > 0, f"no task detail to exec: {task_id}"
    return rowcount


def get_task_detail(task_id: str):
    sql = f"""
        SELECT * FROM {table_task_detail} WHERE TASK_ID = %s
    """
    return db.query(sql, (task_id,))


def run_task_detail(task_detail_id: str):
    sql = f"""
        UPDATE {table_task_detail}
           SET STATUS = %(STATUS)s, START_TIME = SYSDATE
         WHERE ID = %(ID)s
    """
    task_detail = {'ID': task_detail_id, 'STATUS': TaskStatus.RUNNING.value}
    assert db.execute(sql, task_detail) == 1, f"Failed to run task detail: {task_detail_id}"


def complete_task_detail(task_detail_id: str, answer: str, result: str = None):
    sql = f"""
        UPDATE {table_task_detail}
           SET STATUS = %(STATUS)s, END_TIME = SYSDATE, ANSWER = %(ANSWER)s, RESULT = %(RESULT)s
         WHERE ID = %(ID)s
    """
    task_detail = {
        'ID': task_detail_id,
        'STATUS': TaskStatus.DONE.value,
        'ANSWER': answer,
        'RESULT': result,
    }
    assert db.execute(sql, task_detail) == 1, f"Failed to complete task detail: {task_detail_id}"


def exception_task_detail(task_detail_id: str, exception: str):
    sql = f"""
        UPDATE {table_task_detail}
           SET STATUS = %(STATUS)s, END_TIME = SYSDATE, RESULT = %(RESULT)s
         WHERE ID = %(ID)s
    """
    task_detail = {'ID': task_detail_id, 'STATUS': TaskStatus.EXC.value, 'RESULT': exception}
    assert db.execute(sql, task_detail) == 1, f"Failed to exception task detail: {task_detail_id}"


##############################################################################################################
#
def execute_task(task_type: str, ext: dict, desc: str = None, creator: str = "SYSTEM"):
    exec_info = {
        'task_type': task_type,
        'task_ext': ext,
        'task_desc': desc,
        'begin_time': datetime.now(),
        'creator': creator,
        'tool_exec_done': 0,
        'tool_exec_error': 0,
        'exception': '',
    }
    global db
    db = PostgresDB(configs["app_db_name"])
    try:
        # 1. 创建任务
        task_info = create_task(task_type, json.dumps(ext), creator, desc)
        task_id = task_info['ID']
        logger.info(f"1. Task created: {task_id}")
        exec_info['task_id'] = task_id
        # 2. 初始化结果表
        tool = get_mc_task_tool(task_type)
        count = tool.init_data(task_id=task_id, task_ext=ext)
        logger.info(f"2. Init data: {count}")
        if count > 0:
            # 3. 创建任务明细
            count = create_task_detail(task_id, *tool.get_biz_meta())
            logger.info(f"3. Task detail created: {count}")
            exec_info['task_detail_count'] = count
            # 4. 执行任务
            run_task(task_id)
            logger.info(f"4. Task running: {task_id}")
            # 5. 执行任务明细
            details = get_task_detail(task_id)
            for task_detail in details:
                task_detail_id = task_detail['id']
                try:
                    # 5.1. 锁定任务明细
                    run_task_detail(task_detail_id)
                    # 5.2. 处理任务明细
                    answer, json_ans, rowcount = tool.execute(task_detail)
                    # 5.3. 完成任务明细
                    complete_task_detail(
                        task_detail_id, answer, f"updated rows: {rowcount}\njson ans: {json_ans}"
                    )
                    exec_info['tool_exec_done'] += rowcount
                except Exception as e:
                    exception_task_detail(task_detail_id, traceback.format_exc())
                    exec_info['exception'] = f"""{exec_info['exception']}\n{str(e)}"""
                    logger.error(f"Failed to execute task detail: {task_detail_id}", exc_info=True)
                    exec_info['tool_exec_error'] += 1
            logger.info(f"5. Task detail done: {len(details)}")
        # 6. 通知任务完成
        tool.notify(task_info)
        # 7. 完成任务
        exec_info['status'] = "SUCCESS"
        exec_info['end_time'] = datetime.now()
        exec_info['duration'] = (exec_info['end_time'] - exec_info['begin_time']).total_seconds()
        exec_info['begin_time'] = exec_info['begin_time'].strftime("%Y-%m-%d %H:%M:%S")
        exec_info['end_time'] = exec_info['end_time'].strftime("%Y-%m-%d %H:%M:%S")
        complete_task(task_id, json.dumps(exec_info))
        logger.info(f"6. Task done: {task_id}")
    except Exception as e:
        exec_info['status'] = "FAILED"
        if "task_id" in exec_info:
            exception_task(exec_info['task_id'], traceback.format_exc())
            exec_info['exc'] = f"""{exec_info['exception']}\n{str(e)}"""
        raise Exception("Failed to create task.") from e
    finally:
        logger.info("========== Task Execution Info ==========")
        for key, value in exec_info.items():
            logger.info(f"{key}: {value}")
        logger.info("=========================================")


if __name__ == '__main__':
    request = {
        "task_type": "95598",  # 任务类型
        "task_desc": "95598任务",  # 任务描述，非必填
        "creator": "SYSTEM",  # 创建者，系统标识，非必填
        "task_ext": {  # 任务扩展信息(参数列表)
            "org_no": "61102",  # 机构号
            "handle_day": "2024-11-13",  # 业务日期
            # "app_no": "2024111210026829,2024111009309935,2024110909070509"  # 业务ID列表，逗号分隔，非必填，不为空时只处理指定app_no的数据
        },
    }
    response = {
        "rtn_code": "0000",  # 返回码，0000表示成功
        "rtn_msg": "success",  # 返回信息
        "rtn_data": {  # 返回数据
            "task_id": "3d7e25d240aa416bbb35184c6166ca1c"  # 任务ID，关联ms_workorder_appeal_analysis.llm_task_id
        },
    }
    execute_task(request["task_type"], request["task_ext"], request["task_desc"])

from langchain.chains import ConversationChain
from langchain.memory import ConversationBufferWindowMemory
from langchain_core.prompts import (
    ChatPromptTemplate,
    SystemMessagePromptTemplate,
    MessagesPlaceholder,
    HumanMessagePromptTemplate,
)

from framework.chain.i_chain_api import ChainABC
from framework.llm.llm_manager import LLMManager
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)


class ChatChain(ChainABC):
    def __init__(self, configs):
        self.configs = configs
        prompt = ChatPromptTemplate.from_messages(
            [
                SystemMessagePromptTemplate.from_template(configs['system_prompt']),
                MessagesPlaceholder(variable_name="history"),
                HumanMessagePromptTemplate.from_template("{input}"),
            ]
        )
        memory = ConversationBufferWindowMemory(
            k=configs['memory_k'], memory_key=configs['memory_key'], return_messages=True
        )
        self.chain = ConversationChain(
            memory=memory, llm=LLMManager.create_llm(configs), verbose=True, prompt=prompt
        )

    def call(self, **kwargs):
        input_message = self.configs["user_prompt"].format(**kwargs)
        try:
            return self.chain.predict(input=input_message), input_message
        except Exception as e:
            logger.error(f"chain predict error: {e}")
            return "", input_message

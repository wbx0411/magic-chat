"""
web容器
"""

from .fastapi_base import create_base_fastapi

import json
from biz.tools import RTN_TYPE
from biz.tools.tool_manager import BaseTool, ExecResult
from utils.logger_utils import LoggerFactory


logger = LoggerFactory.get_logger(__name__)


class Rpa(BaseTool):
    def __init__(self, config, chat_chain=None):
        super().__init__(config, chat_chain)

    def register(self, **kwargs):
        logger.info(f"Rpa register: {self.configs}")
        super().register()
        try:
            # 注册API
            result = self.db.execute(
                """
                insert into ai_tools_de_rpa (tool_id, input_params)
                values (%s, %s)
                """,
                (
                    self.configs['tool_id'],
                    self.configs['tool_params'].get('input_params', ''),
                ),
            )
            logger.info(f"Rpa register success: {self.configs['tool_id']}, {result=}")
        except Exception as e:
            super().unregister()
            raise e

    def unregister(self, **kwargs):
        super().unregister()

        result = self.db.execute(
            "delete from ai_tools_de_rpa where tool_id = %s",
            (self.configs['tool_id'],),
        )
        logger.info(f"Rpa unregister success: {self.configs['tool_id']}, {result=}")

    def find_tool(self, tool_id: str):
        tool = self.db.query("select * from ai_tools_de_rpa where tool_id = %s", (tool_id,))
        assert tool, f"Tool not found: {tool_id}"
        return tool[0]

    async def execute(self, **kwargs):
        try:
            logger.info(f"Rpa execute: {kwargs}")
            assert 'input_msg' in kwargs, "input_msg is required"
            api_tool = self.find_tool(self.configs['tool_id'])
            api_params = {
                "toolId": self.configs['tool_id'],
                "toolName": self.configs['tool_name'],
                "toolParams": self.get_params(api_tool['input_params'], kwargs['input_msg']),
            }
            return ExecResult(api_params, self.configs['tool_code'])
        except Exception as e:
            logger.error(f"Rpa execute error: {e}")
            return ExecResult.empty()

    def get_params(self, input_params, input_msg):
        try:
            params = json.loads(input_params)
        except Exception as e:
            logger.error(f"Rpa get_params error: {e}")
            return {}

        # TODO 提取供电单位
        return {}

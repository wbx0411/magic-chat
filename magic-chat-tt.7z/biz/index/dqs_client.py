import copy
import datetime
import time
from typing import Dict

import httpx

from biz.index.metadata import *
from framework.algorithm.embed_dis import l2_distance
from framework.algorithm.simple_bm25 import SimpleBM25
from framework.embedding.m3e_client import m3e_client
from utils.config_utils import SysConfig
from utils.date_utils import get_date_time_type
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)
configs = SysConfig.get_config()
bm25 = SimpleBM25()

# DQS Client 参数操作符
PARAM_OPERATORS = {
    "01": "相等",
    "02": "大于",
    "03": "小于",
    "04": "大于等于",
    "05": "小于等于",
    "06": "in",
    "07": "between",
    "08": "like",
    "09": "不相等",
    "99": "其他",
}

# DQS Client 指标值返回值字段
INDEX_COLUMNS = {
    "idxValue": "指标值",
    "lpIdxValue": "上期指标值",
    "lpRate": "指标环比",
    "cpIdxValue": "同期指标值",
    "cpRate": "指标同比",
    "dataDate": "时间"
}

# DQS Client 返回值字段
R_KEY_V = 'idx_value'
R_KEY_D = 'idx_detail'
R_KEY_D_L = 'list'
R_KEY_M = 'cols_comments'
R_KEY_F = 'mgr_flag'
R_KEY_F_D = 'chartFlag'


class DQSClient:
    def __init__(self, base_url, token, timeout=5):
        self.base_url = base_url
        self.headers = {
            "Content-Type": "application/json"
        }
        if token:
            self.headers['Authorization'] = f"Bearer {token}"

        self.timeout = timeout
        self.client = httpx.Client(headers=self.headers, timeout=self.timeout)
        logger.info(f"DQSClient initialized with base URL: {base_url}")

    def request_index(self, code: str, params: Dict):
        url = f"{self.base_url}/dbService"
        req_body = {
            "businessCode": code,
            "requestBody": params
        }

        logger.info(f"DQS request: {req_body}")
        try:
            response = self.client.post(url, headers=self.headers, json=req_body, timeout=self.timeout)
            if response.status_code == 200:
                if response.json()['code'] == 'SYS.200':
                    logger.info("Successfully retrieved index value.")
                    return response.json()['data'], response.json()['msg']
            raise Exception(f"Error retrieving index {code} value: {response.text}, request: {req_body}")
        except Exception as e:

            logger.exception(f"Exception occurred while retrieving index value: {e}")
            raise e

    # 根据知识库信息构建参数请求DQS数据，并返回结果
    def get_data_by_kg(
            self,
            db_namespace,
            neo4j,
            nodes_ind,
            message_content,
            message_embedding,
            org_no,
            user_id,
            data_time,
            org_name=None
    ):
        # DQS请求数据（自然语言）
        dqs_data_list = []
        dqs_url_params = []

        # 检索指标维度
        for index, node in enumerate(nodes_ind):
            grid_data = False
            ind_code = node['code']
            # llm answer sentence
            dqs_data_cn = {'指标名称': node['name'], '指标描述': node['desc']}

            if org_name:
                dqs_data_cn['供电单位'] = org_name
            # DQS request params
            dqs_params_base = {
                'orgNo': {'vals': org_no, 'opt': '01'},
                'userId': {'vals': user_id, "opt": '01'},
                'yzIdxCode': {'vals': ind_code, 'opt': '01'},
                'dataDate': {'vals': data_time, 'opt': '01'}
            }
            dqs_params = {}

            # datatime
            dqs_data_cn['时间'] = data_time

            dqs_data_cn['维度范围'] = []
            # 获取维度列表，手工拼装请求参数，未来由llm完成
            dimensions = neo4j.get_neighbor_nodes(db_namespace, node['_id'], label_idx_dim)
            dim_node_name = copy.deepcopy(node['name'])

            for dim in dimensions:
                # 获取纬度值列表
                # dim_values = neo4j.get_neighbor_nodes(db_namespace, dim['_id'], graph_import.label_idx_val)
                index_name = neo4j.get_index_name(idx_vec_pre, db_namespace, label_idx)
                dim_values = neo4j.retrieve_sub_nodes_by_vector(
                    db_namespace, index_name, label_idx, message_embedding,
                    {'ID(n)': dim["_id"], 'n.label': label_idx_dim}, limit=300)

                dim_values = [value for value in dim_values if value['label'] == label_idx_val]

                logger.info(
                    f"First Dimension id: {dim['_id']}, Dimension name: {dim['name']}, Dimension values: {dim_values}")
                # 无任何纬度值配置，即全部维度值，则设置请求参数维度值不为空。或但问话未提到维度也没有纬度值时
                # 纬度值为空，则设置特殊比较符号99
                v_operator = '99'
                v_value = ''
                v_name = ''
                v_type = '01'

                # 存在纬度值配置
                if dim_values:
                    # 原子指标拼接维度值 与 问题匹配
                    for value in list(dim_values):
                        kg_name = node['name'] + value['name'] if 'name' in value else '未知'
                        kg_embedding_response = m3e_client.get_embeddings(kg_name, configs['m3e_model_name'])
                        kg_embedding = kg_embedding_response['data'][0]['embedding'] if kg_embedding_response else None
                        if l2_distance(kg_embedding, message_embedding) > configs['min_score_l2_vector']:
                            dim_values.remove(value)

                    logger.info(
                        f"Second Dimension id: {dim['_id']}, "
                        f"Dimension name: {dim['name']}, "
                        f"Dimension values: {dim_values}"
                    )

                    if dim_values:
                        # 先向量，后bm排序，纬度值只保留最相近的
                        dim_values_match = bm25.query(dim_values, message_content, 1,
                                                      min_score=float(configs['min_score_dim_val']))

                        # 问话匹配到了纬度值，则设置请求参数纬度为指定纬度值
                        if len(dim_values_match) > 0 and isinstance(dim_values_match[0], dict):
                            dim_value = dim_values_match[0]
                            # 目前只支持条件比较中的“01相等”，未来进行扩展
                            v_operator = '01'
                            v_value = dim_value['code']
                            v_name = dim_value['name']
                            dim_node_name = v_name + dim_node_name

                            # 判断是否是限定词维度，如果是，则清空其他维度值
                            if dim['name'] == node['name']:
                                dqs_params = {
                                    dim['code']: {"vals": v_value, "opt": v_operator, "type": v_type}
                                }
                                # 纬度值有设置才构建对话中文数据
                                v_operator_name = PARAM_OPERATORS[v_operator] if v_operator in PARAM_OPERATORS else '其他'
                                dqs_data_cn = {'维度范围': {
                                    '维度名称': dim['name'],
                                    '维度值': v_name,
                                    '比较方式': v_operator_name
                                }}
                                break
                            dqs_params[dim['code']] = {"vals": v_value, "opt": v_operator, "type": v_type}

                            # 纬度值有设置才构建对话中文数据
                            v_operator_name = PARAM_OPERATORS[v_operator] if v_operator in PARAM_OPERATORS else '其他'
                            dqs_data_cn['维度范围'].append(
                                {'维度名称': dim['name'], '维度值': v_name, '比较方式': v_operator_name})

                if dim['code'] not in dqs_params.keys():
                    # 匹配问话当中是否包含列出此维度各个纬度值
                    dim_match_doc = [{"name": x} for x in make_sentence_list(dim['name'])]
                    logger.info(f"Match dimension values: {dim_match_doc}")
                    dim_match = bm25.query(dim_match_doc, message_content, 1,
                                           min_score=configs['min_score_dim_val'])

                    # 问话没有匹配到任何纬度值，或者问话提到了维度，则设置请求参数维度为全部明细维度
                    if len(dim_match) > 0 and dim['name'] != node['name']:
                        v_type = '02'
                        dqs_params[dim['code']] = {"vals": v_value, "opt": v_operator, "type": v_type}
                        dim_node_name = dim['name'] + dim_node_name
                        # DQS返回数据列表
                        grid_data = True

                # 当weight=999时（借用连线weight属性），表示必选项，如果没有提问中没有提到，则返回错误。此特性暂时未用到
                if 'weight' in dim and dim['weight'] and int(dim['weight']) == 999 and not v_value:
                    dqs_data_error = {'指标名称': node['name'],
                                      '错误原因': f"提问当中缺少维度{dim['name']}的条件，请补充描述"}
                    logger.info(f"Sentences error, missing dimension values: {dqs_data_error}")
                    return [dqs_data_error], []

            dqs_params = {**dqs_params, **dqs_params_base}
            # DQS远程请求指标数据
            _time_start = time.time()
            ind_value, ind_msg = self.request_index(ind_code, dqs_params)
            _time_end = time.time()

            logger.info(f"DQS response: {ind_value}")
            logger.info(f"DQS response duration: {_time_end - _time_start}")
            try:
                dqs_data_value = parse_dqs_data_value(ind_value, ind_code, ind_msg)
            except Exception as e:
                dqs_data_value = None
                logger.error(f"Exception occurred while parsing DQS data: {e}")

            if dqs_data_value:
                dqs_data_cn.update(dqs_data_value)
                dqs_data_list.append(dqs_data_cn)

            # 如果是第一个指标，且(指标值为空 或 指标值不是未知)，则将请求参数加入到请求参数列表中
            # 返回给前台只有一个url
            # if index == 0 :
            if not dqs_data_value:
                dqs_url_params.append({
                    dim_node_name: {
                        "businessCode": node['code'],
                        "requestBody": dqs_params
                    },
                    "chart_type": "tables"
                })
                continue

            if dqs_data_value['指标值'] not in ['未知', '空']:
                dqs_url_params.append({
                    dim_node_name: {
                        "businessCode": node['code'],
                        "requestBody": dqs_params
                    }
                })

                # 如果发送的type不是02，即不是明细数据，则给前端返回下级供电单位10
                if not grid_data:
                    # 日期
                    dqs_url_params_date = copy.deepcopy(dqs_url_params)
                    for dqs_url_params_item in dqs_url_params_date:
                        dqs_url_params_item['chart_type'] = "time"
                        for k, v in dqs_url_params_item.items():
                            if k != 'chart_type':
                                date_time_type = get_date_time_type(data_time)
                                if date_time_type == 'year':
                                    v['requestBody']['dataDate']['opt'] = '07'
                                    v['requestBody']['dataDate']['bgn'] = data_time + '01'
                                    v['requestBody']['dataDate']['end'] = datetime.datetime.now().strftime("%Y%m")
                                    v['requestBody']['dataDate'].__delitem__('vals') if 'vals' in v[
                                        'requestBody']['dataDate'] else None
                                elif date_time_type == 'month':
                                    v['requestBody']['dataDate']['opt'] = '07'
                                    v['requestBody']['dataDate']['bgn'] = data_time + '01'
                                    v['requestBody']['dataDate']['end'] = datetime.datetime.now().strftime("%Y%m%d")
                                    v['requestBody']['dataDate'].__delitem__('vals') if 'vals' in v[
                                        'requestBody']['dataDate'] else None
                                elif date_time_type == 'day':
                                    v['requestBody']['dataDate']['opt'] = '07'
                                    v['requestBody']['dataDate']['bgn'] = (
                                            datetime.datetime.now() - datetime.timedelta(days=7)).strftime("%Y%m%d")
                                    v['requestBody']['dataDate']['end'] = data_time
                                    v['requestBody']['dataDate'].__delitem__('vals') if 'vals' in v[
                                        'requestBody']['dataDate'] else None

                    # 供电单位不是所级
                    if len(org_no) != 9:
                        for dqs_url_params_item in dqs_url_params:
                            dqs_url_params_item['chart_type'] = "org"
                            for k, v in dqs_url_params_item.items():
                                if k != 'chart_type':
                                    v['requestBody']['orgNo']['opt'] = '10'

                        dqs_url_params = dqs_url_params + dqs_url_params_date
                    else:
                        dqs_url_params = dqs_url_params_date

        return dqs_data_list, dqs_url_params


# 解析指标返回值（或明细）
def parse_dqs_data_value(ind_value, ind_code, ind_msg):
    dqs_data_value = {}
    if isinstance(ind_value, dict):
        dqs_data_value['指标值'] = '空'
        assert R_KEY_F in ind_value, f"Invalid response key [{R_KEY_F}] in {ind_value}"
        if ind_value[R_KEY_F][R_KEY_F_D] == 'true':
            # 如果是返回是列表，直接返回
            return None

        assert R_KEY_V in ind_value, f"Invalid response key [{R_KEY_V}] in {ind_value}"
        if ind_value[R_KEY_V]:
            ind_v = ind_value[R_KEY_V][0]
            if ind_v and isinstance(ind_v, dict):
                ind_v_v_dict = {}
                for k, v in ind_v.items():
                    if k in INDEX_COLUMNS:
                        ind_v_v_dict[INDEX_COLUMNS[k]] = v if v else '空'
                if ind_v_v_dict:
                    dqs_data_value.update(ind_v_v_dict)
                dqs_data_value['其他信息'] = ind_msg
            else:
                dqs_data_value['其他信息'] = ind_msg
                raise ValueError(f"Invalid index value: {ind_v}")
        # if R_KEY_D in ind_value and ind_value[R_KEY_D]:
        # dqs_data_value['指标明细'] = '空'
        # ind_d = ind_value[R_KEY_D]
        # if ind_d and isinstance(ind_d, dict):
        #     if R_KEY_D_L in ind_d and ind_d[R_KEY_D_L]:
        #         ind_d_l = ind_d[R_KEY_D_L]
        #         if ind_d_l and isinstance(ind_d_l, list):
        #             if R_KEY_M in ind_value and isinstance(ind_value[R_KEY_M], dict):
        #                 keys_dict = ind_value[R_KEY_M].copy()
        #                 for k, v in keys_dict.items():
        #                     if v:
        #                         v_list = v.split(",")
        #                         if len(v_list) > 1:
        #                             keys_dict[k] = v_list[0]
        #                         else:
        #                             keys_dict[k] = v
        #                 ind_d_l = replace_dict_keys(ind_d_l, keys_dict)
        #         dqs_data_value['指标明细'] = ind_d_l
    else:
        dqs_data_value['指标值'] = '未知'

    return dqs_data_value


def replace_dict_keys(dict_list, key_maps):
    dict_list_new = dict_list.copy()
    for d in dict_list_new:
        for k, v in key_maps.items():
            if k in d:
                d[v] = d.pop(k)
    return dict_list


def make_sentence_list(src_sentence):
    return [f"{x}{src_sentence}" for x in ["", "各个", "每个", "下级", "各"]]


if __name__ == "__main__":
    _base_url = "http://10.4.59.160:9191/graphrag"
    token = "sk-hv6xtPbK183j3RR306Fe23B6196b4d919a8e854887F6213d"
    client = DQSClient(_base_url, token)

    data = client.request_index("yz_pq", {"orgNo": "10101", "userId": "222222"})
    print(data)

# 费控测算
import json

from langchain_core.tools import BaseTool

background_info = """
费控测算情况：
昨日共测算1341.9万户，较前日增加0.13%，
测算余额为149068万元，较前日减少0.28%。
测算电量为8854.78万千瓦时，较前日减少4.35%；
测算电费为4722.26万元，较前日增加4.77%。
大电量户数为82257户，较前日增加17.41%；
零电量户有2533088户，较前日减少0.53%。
"""


class CostControlCalculation(BaseTool):
    name = "昨日费控测算情况"
    description = """
        获取昨日费控测算情况
        """
    return_direct = False

    def __init__(self):
        super().__init__()

    async def _arun(self, cons_no: str) -> str:
        output = {
            "result": f"{background_info}",
            "key": "ccc"
        }
        json_data = json.dumps(output, ensure_ascii=False)
        return json_data

    def _run(self, cons_no: str) -> str:
        pass

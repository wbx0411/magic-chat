import os

import yaml


def load_config():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    base_config_file = os.path.join(current_dir, 'config.base.yaml')
    env = os.getenv('RUN_ENV', 'dev')  # default development
    config_file = os.path.join(current_dir, f'config.{env}.yaml')

    # load yaml
    try:
        with open(base_config_file, 'r', encoding="utf-8") as file:
            base_config = yaml.safe_load(file)
    except FileNotFoundError:
        raise Exception(f"Configuration file {base_config_file} not found.")

    try:
        with open(config_file, 'r', encoding="utf-8") as f:
            config = yaml.safe_load(f)
    except FileNotFoundError:
        raise Exception(f"Configuration file {config_file} not found.")

    final_config = {**base_config, **config}
    return final_config

import os

import jieba

from biz.index import metadata
from transport.db.neo4jdb import Neo4jDB
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)
neo4j = Neo4jDB()

current_dir = os.path.dirname(os.path.abspath(__file__))
config_path = os.path.join(current_dir, '../..', "configs/jieba")

# 词典类型：yz-原子指标，dim-维度，val-维度值
dict_types = ['yz', 'dim', 'val']

"""
paddle模式词性标注对应表如下：

paddle模式词性和专名类别标签集合如下表，其中词性标签 24 个（小写字母），专名类别标签 4 个（大写字母）。

| 标签 | 含义     | 标签 | 含义     | 标签 | 含义     | 标签 | 含义     |
| ---- | -------- | ---- | -------- | ---- | -------- | ---- | -------- |
| n    | 普通名词 | f    | 方位名词 | s    | 处所名词 | t    | 时间     |
| nr   | 人名     | ns   | 地名     | nt   | 机构名   | nw   | 作品名   |
| nz   | 其他专名 | v    | 普通动词 | vd   | 动副词   | vn   | 名动词   |
| a    | 形容词   | ad   | 副形词   | an   | 名形词   | d    | 副词     |
| m    | 数量词   | q    | 量词     | r    | 代词     | p    | 介词     |
| c    | 连词     | u    | 助词     | xc   | 其他虚词 | w    | 标点符号 |
| PER  | 人名     | LOC  | 地名     | ORG  | 机构名   | TIME | 时间     |

"""


def gen_jieba_dict():
    for dict_type in dict_types:
        gen_dict(dict_type)


def gen_dict(node_type):
    nodes = neo4j.match_nodes(getattr(metadata, f'label_idx_{node_type}'))
    # 写入到 idx_dict.txt
    with open(f'{config_path}/{node_type}_dict.txt', 'w', encoding='utf-8') as f:
        for node in nodes:
            f.write(f"{node['name']} 9999 {node_type}\n")
        logger.info(f"{len(nodes)} {node_type} have been written to the dict.")


def load_dict():
    dicts = []
    for dict_type in dict_types:
        dicts.append(d := f"{dict_type}_dict.txt")
        jieba.load_userdict(f"{config_path}/{d}")
    logger.info(f"jieba load dict: {dicts}")

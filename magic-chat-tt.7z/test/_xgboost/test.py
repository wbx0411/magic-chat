import matplotlib.pyplot as plt
import numpy as np
from matplotlib import rcParams

# 设置字体为支持中文的字体
rcParams['font.sans-serif'] = ['SimHei']  # 使用黑体
rcParams['axes.unicode_minus'] = False  # 解决负号显示问题

# 生成演示数据
X = np.linspace(-5, 5, 100)
y = np.sin(X) + np.random.normal(0, 0.1, 100)
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import plot_tree
import matplotlib.pyplot as plt

# 训练模型
model = RandomForestClassifier(n_estimators=10)
model.fit(X, y)

# 绘制第一棵树
plt.figure(figsize=(20, 10))
plot_tree(model.estimators_[0], feature_names=X.columns, filled=True)
plt.show()

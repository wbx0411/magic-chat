import re
import os
import sys


def read_idx_info():
    with open(f'{os.path.dirname(__file__)}/idx_info.txt', 'r', encoding='utf-8') as f:
        return dict(line.strip().split(',') for line in f)


idx_info = read_idx_info()


def read_menu():
    menus = {}
    pattern = r'interfaces\.(\w*)Controller'
    with open(f'{os.path.dirname(__file__)}/menu.txt', 'r', encoding='utf-8') as f:
        for line in f:
            name, uri = line.strip().split(',')
            m = re.findall(pattern, uri)
            menus[m[0].lower() if m else uri.lower()] = name
    return menus


menus = read_menu()


def read_table():
    with open(f'{os.path.dirname(__file__)}/table.txt', 'r', encoding='utf-8') as f:
        return dict(line.strip().split(',') for line in f)


tables = read_table()


def extract_metrics(text):
    pattern = r'(?i)\bYX_JC_[a-zA-Z0-9_]*\b'
    return ["_".join(m.split("_")[0:4]) for m in re.findall(pattern, text)]


def extract_tables(text):
    # 正则表达式模式：(?i)表示忽略大小写，\b是单词边界，确保我们匹配的是独立的单词
    pattern = r'(?i)\bms_[a-zA-Z0-9_]*\b'
    return [m.lower() for m in re.findall(pattern, text)]


file_filter = (".vue", ".xml", ".js", ".java", ".html", ".ts")
dir_ignore = (".svn", "tests")


def extract_metrics_from_files(d, is_table=False):
    metrics = []
    for root, _, files in os.walk(d):
        if any([di in root for di in dir_ignore]):
            continue
        print("=" * 5, root.replace(d + "\\", ''))
        for file in files:
            if not file.endswith(file_filter):
                continue
            file_path = os.path.join(root, file)
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    text = f.read()
                    metrics += [
                        [
                            next(
                                (
                                    name
                                    for uri, name in menus.items()
                                    if uri in file_path.replace(d + "\\", '')
                                    # .replace(r"src\main\resources\mapper", "")
                                    .replace(r"\src\main\resources\resources", "")
                                    # .replace(r"src\main\java\ep", "")
                                    # .replace(r"src\main\java\com\neusoft", ""),
                                    .replace("\\", ".").lower()
                                ),
                                "未知菜单",
                            ),
                            m,
                            getattr(
                                sys.modules[__name__], f"{'tables' if is_table else 'idx_info'}"
                            ).get(m, m),
                            file_path.replace(d + "\\", ''),
                        ]
                        for m in getattr(
                            sys.modules[__name__], f"extract_{'tables' if is_table else 'metrics'}"
                        )(text)
                    ]
            except:
                print(f"error: {file_path}")
    return metrics


if __name__ == '__main__':
    # 指定文件夹路径
    directory = 'E:/work/2402-ai/瞭望台/miop'

    # 提取文件夹下所有文件中以“lwt_”开头的指标
    all_metrics = extract_metrics_from_files(directory, False)
    # print(all_metrics)
    with open(f'{os.path.dirname(__file__)}/out.csv', 'w', encoding='gbk') as out_file:
        for metric in sorted(set(",".join(_) for _ in all_metrics)):
            out_file.write(f"{metric}\n")

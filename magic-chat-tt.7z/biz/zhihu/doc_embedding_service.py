from sqlalchemy import select

from biz.zhihu.database import Database
from biz.zhihu.models import DocEmbeddingEntity
from configs import config_loader
from framework.algorithm.lcs_finder import longest_common_subsequence, longest_common_substring
from framework.algorithm.simple_bm25 import SimpleBM25
from framework.embedding.m3e_client import m3e_client
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)


def find_best_matches(tuples_list, query_string):
    """
    在给定的字符串和键的元组列表中，找到并排序与查询字符串匹配的元组。
    最相关的结果优先排序。

    参数:
    tuples_list (list of tuples): 字符串和键的元组列表。
    query_string (str): 查询字符串。

    返回:
    list: 排序后的与查询字符串匹配的元组列表。
    """
    matches_info = []

    # 计算每个元组的最长公共子序列和最长公共子串长度
    for content, note, attach_path, title in tuples_list:
        lcs = longest_common_subsequence(content + note, query_string)
        lcsstr = longest_common_substring(content + note, query_string)
        lcs_length = len(lcs)
        lcsstr_length = len(lcsstr)
        matches_info.append((content, note, lcs_length, lcsstr_length, attach_path, title))

    # 根据最长公共子序列长度和最长公共子串长度排序
    # 首先按最长公共子序列长度降序排序，然后按最长公共子串长度降序排序
    sorted_matches = sorted(matches_info, key=lambda x: (-x[2], -x[3]))
    # logger.info("Search best matches: %s", sorted_matches)

    # 返回排序后的元组列表，不包括长度信息
    return [
        (content, note, attach_path, title)
        for content, note, _, _, attach_path, title in sorted_matches
    ]


class DocEmbeddingService:
    def __init__(self):
        self.configs = config_loader.load_config()
        self.embedding_client = m3e_client
        self.db = Database()
        self.bm25 = SimpleBM25()
        self.top_k = self.configs['top_k']

    def get_bm25_top_ids(self, search_text, embedding=None):
        session = self.db.get_session()
        try:
            if embedding is None:
                embedding_response = self.embedding_client.get_embeddings([search_text])
                if embedding_response:
                    embedding = embedding_response['data'][0]['embedding']
                else:
                    logger.info("No embedding response for search text: %s", search_text)
                    return [], 0
            stmt = (
                select(
                    DocEmbeddingEntity.id,  # 0
                    DocEmbeddingEntity.content,
                    DocEmbeddingEntity.note,
                    DocEmbeddingEntity.content_note,  # 3
                    DocEmbeddingEntity.attach_path,
                    DocEmbeddingEntity.title,
                )
                .order_by(DocEmbeddingEntity.content_note_emb.l2_distance(embedding))
                .limit(self.top_k)
            )
            results = session.execute(stmt).all()

            bm25_ids = self.bm25.query(results, search_text, num_best=self.top_k, field=3)
            scores = [score for id, content, note, score, attach_path, title in bm25_ids]

            return bm25_ids, scores[0]
        except Exception as e:
            logger.error("An error occurred while getting all desc: %s", e, exc_info=True)
            raise e
        finally:
            session.close()
            logger.debug("Session closed")

    def get_similar_vector_ids(self, search_text, mode, doc_list=[], embedding=None):
        session = self.db.get_session()
        try:
            if embedding is None:
                embedding_response = self.embedding_client.get_embeddings([search_text])
                if embedding_response:
                    embedding = embedding_response['data'][0]['embedding']
                else:
                    logger.info("No embedding response for search text: %s", search_text)
                    return []

            if mode == "note":
                select_col = DocEmbeddingEntity.note_emb.l2_distance(embedding)
            elif mode == "content":
                select_col = DocEmbeddingEntity.content_emb.l2_distance(embedding)
            elif mode == "content_note":
                select_col = DocEmbeddingEntity.content_note_emb.l2_distance(embedding)
            stmt = select(
                DocEmbeddingEntity.id,  # 0
                DocEmbeddingEntity.content,
                DocEmbeddingEntity.note,
                select_col,  # 3
                DocEmbeddingEntity.attach_path,  # 4
                DocEmbeddingEntity.title,
            )
            if doc_list:
                stmt = stmt.where(DocEmbeddingEntity.title.in_(doc_list))
            stmt = stmt.order_by(select_col).limit(self.top_k)
            results = session.execute(stmt).all()
            return results
        except Exception as e:
            logger.error("An error occurred while getting similar vector ids: %s", e, exc_info=True)
            raise e
        finally:
            session.close()
            logger.debug("Session closed")

    def vector_search(self, search_text, doc_list=[]):
        """
        (1) note_embedding_search
        (2) content_embedding_search
        (3) bm25_search
        """
        embedding_response = self.embedding_client.get_embeddings([search_text])
        if embedding_response:
            embedding = embedding_response['data'][0]['embedding']
        # 获取相似的向量ID和它们的距离
        note_search_results = self.get_similar_vector_ids(
            search_text, 'content_note', doc_list, embedding
        )
        content_search_results = self.get_similar_vector_ids(
            search_text, 'content', doc_list, embedding
        )
        if not note_search_results and not content_search_results:
            return "", []

        note_avg_distance = sum([result[3] for result in note_search_results]) / len(
            note_search_results
        )
        logger.info(f"content_note_vector_distances: {note_avg_distance}")

        content_avg_distance = sum([result[3] for result in content_search_results]) / len(
            content_search_results
        )
        logger.info(f"content_vector_distances: {content_avg_distance}")

        # 获取bm25结果
        bm25_results, bm25_score = self.get_bm25_top_ids(search_text, embedding)
        logger.info(f"bm25_score: {bm25_score}")

        # prompt duplicate removal
        prompt_note = [
            (result[1], result[2], result[4], result[5]) for result in note_search_results
        ]
        prompt_content = [
            (result[1], result[2], result[4], result[5]) for result in content_search_results
        ]
        prompt_bm = [(result[1], result[2], result[4], result[5]) for result in bm25_results]
        result = list(set(prompt_note + prompt_content + prompt_bm))

        result = find_best_matches(result, search_text)[: self.top_k * 2]

        prompt = ''

        attach_path = []
        for i, info in enumerate(result):
            prompt += f"信息{i + 1}：" + str(info[1]) + ":" + str(info[0]) + '\n'
            # attach是图片
            # if info[2]:
            #     attach_path.append(info[2])
            attach_path.append(info[3])

        attach_path = list(set(attach_path))
        # logger.info(f"prompt: {prompt}")
        return prompt, attach_path

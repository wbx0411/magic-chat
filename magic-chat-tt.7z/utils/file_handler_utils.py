import os
import sys


"""文件处理工具
"""


def file_reader(file_path: str, **kwargs):
    _, file_extension = os.path.splitext(file_path)
    if hasattr(
        current_module := sys.modules[__name__], reader := (file_extension[1:].lower() + '_reader')
    ):
        res = getattr(current_module, reader)(file_path, **kwargs)
        return res if isinstance(res, list) else [res]
    else:
        raise ValueError(f"Unsupported file extension: {file_extension}")


def txt_reader(file_path: str):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()


def json_reader(file_path: str):
    import json

    with open(file_path, 'r', encoding='utf-8') as file:
        return json.load(file)


def csv_reader(file_path: str):
    import csv

    with open(file_path, 'r', encoding='utf-8') as file:
        reader = csv.reader(file)
        return list(reader)


def md_reader(file_path: str):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.read()


def docx_reader(file_path: str, **kwargs):
    from docx import Document

    doc = Document(file_path)
    file_content = []

    read_type = kwargs.get('read_type', 'text')

    if read_type == 'heading':
        # 处理一级标题
        current_chapter = None
        for paragraph in doc.paragraphs:
            if paragraph.style.name.startswith('Heading'):
                if current_chapter is not None:
                    file_content.append(current_chapter)
                current_chapter = {'title': paragraph.text, 'content': ''}
            elif current_chapter is not None:
                current_chapter['content'] += paragraph.text + '\n'

        if current_chapter is not None:
            file_content.append(current_chapter)
    elif read_type == 'heading2':
        # 处理二级标题
        current_chapter = None
        current_sub_chapter = None
        for paragraph in doc.paragraphs:
            if paragraph.style.name == 'Heading 1':
                if current_sub_chapter:
                    if current_chapter:
                        current_chapter['sub_chapters'].append(current_sub_chapter)
                    current_sub_chapter = None
                if current_chapter:
                    file_content.append(current_chapter)
                current_chapter = {'title': paragraph.text, 'content': '', 'sub_chapters': []}
            elif paragraph.style.name == 'Heading 2':
                if current_sub_chapter:
                    if current_chapter:
                        current_chapter['sub_chapters'].append(current_sub_chapter)
                current_sub_chapter = {'title': paragraph.text, 'content': ''}
            else:
                if current_sub_chapter:
                    current_sub_chapter['content'] += paragraph.text + '\n'
                elif current_chapter:
                    current_chapter['content'] += paragraph.text + '\n'

        if current_sub_chapter:
            if current_chapter:
                current_chapter['sub_chapters'].append(current_sub_chapter)
        if current_chapter:
            file_content.append(current_chapter)
    else:
        # 遍历文档中的每一个段落
        for para in doc.paragraphs:
            # 输出段落的文本
            if para.text.strip():  # strip()用于移除字符串头尾的空格
                text = ''
                for run in para.runs:
                    # 添加run的文本到text变量
                    text += run.text
                    # 检查run是否包含手动换行符
                    if '<w:br/>' in run._r.xml:
                        file_content.append(text.strip())
                        text = ''
                if text != '':
                    file_content.append(text.strip())
        if read_type == 'text':
            file_content = [" ".join(file_content)]

    return file_content


def doc_reader(file_path: str):
    import textract

    return textract.process(file_path)


def pdf_reader(file_path: str):
    # pdf2img(file_path)
    # return ""
    import fitz

    with fitz.open(file_path) as pdf_document:
        return [page.get_text() for page in pdf_document]


def pdf2img(file_path, zoom=3.0):
    import fitz

    # 打开PDF文件
    pdf_document = fitz.open(file_path)
    # 遍历PDF的每一页
    for i in range(pdf_document.page_count):
        # 获取第i页
        page = pdf_document[i]
        mat = fitz.Matrix(zoom, zoom)
        # 将第i页转换为图像
        image = page.get_pixmap(matrix=mat)
        # 保存图像
        image.save(f'page_{i}.png')

    pdf_document.close()


def doc2docx(file_path):
    import pypandoc

    pypandoc.convert_file(file_path, 'docx', outputfile=file_path + '.docx')


def contains_chinese_uppercase_number(s):
    chinese_uppercase_numbers = {'一', '二', '三', '四', '五', '六', '七', '八', '九', '十'}
    return any(char in chinese_uppercase_numbers for char in s[:3])


def supported_file_types():
    return [func[:-7] for func in dir(sys.modules[__name__]) if func.endswith('_reader')]


if __name__ == '__main__':
    # import os
    # import sys

    # sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "..")))
    # from framework.rag.chunking import preprocess_text, semantic_chunking

    # file_root = "resources/docs/"
    # file_name = "第四次现货结算试运行工作日报.pdf"
    # file_content = file_reader(f'{file_root}{file_name}')
    # file_content = [preprocess_text(content) for content in file_content]
    # # chunks = semantic_chunking(file_content, chunk_size=512, overlap=50)
    # print(file_content)

    print(supported_file_types())

import json
import sys

import httpx
from biz.tools.tool_manager import BaseTool, ExecResult
from framework import rag
from utils import get_format_time
from utils.logger_utils import LoggerFactory
import re

logger = LoggerFactory.get_logger(__name__)


class APIFetch(BaseTool):
    """【API调用】工具
    此工具通过配置API的URL、参数、请求头等信息，调用API获取数据
    获取的数据作为大模型的提示词，用于后续的对话生成
    """

    def __init__(self, config, chat_chain=None):
        super().__init__(config, chat_chain)

        headers = {"Content-Type": "application/json"}
        if 'token' in self.configs:
            headers['Authorization'] = f"Bearer {self.configs['token']}"
        self.client = httpx.Client(headers=headers, timeout=self.configs.get('timeout', 5))

    def register(self):
        logger.info(f"APIFetch register: {self.configs}")
        assert 'input_params' in self.configs['tool_params'], "input_params is required"
        super().register()
        try:
            # 注册API
            result = self.db.execute(
                """
                insert into ai_tools_de_api_fetch (tool_id, api_type, input_params)
                values (%s, %s, %s)
                """,
                (
                    self.configs['tool_id'],
                    self.configs['tool_params']['type'],
                    self.configs['tool_params']['input_params'],
                ),
            )
            logger.info(f"APIFetch register success: {self.configs['tool_id']}, {result=}")
        except Exception as e:
            super().unregister()
            raise e

    def unregister(self):
        super().unregister()

        result = self.db.execute(
            "delete from ai_tools_de_api_fetch where tool_id = %s",
            (self.configs['tool_id'],),
        )
        logger.info(f"APIFetch unregister success: {self.configs['tool_id']}, {result=}")

    def find_tool(self, tool_id: str):
        tool = self.db.query("select * from ai_tools_de_api_fetch where tool_id = %s", (tool_id,))
        assert tool, f"Tool not found: {tool_id}"
        return tool[0]

    async def execute(self, **kwargs):
        if self.configs.get('api_mock'):
            return ExecResult.knowledge(
                """
                营业户数：624.86万户
                售电量：5655.86万千瓦时
                到户均价：45.00元/千千瓦时
                应收电费：589.63万元
                帮扶点户数：38731户数
                台区数量：597个
                户均容量：203.57kVA
            """
            )
        try:
            logger.info(f"APIFetch execute: {kwargs}")
            assert 'input_msg' in kwargs, "input_msg is required"
            api_tool = self.find_tool(self.configs['tool_id'])
            api_params = {
                "apiId": self.configs['tool_id'],
                "apiType": api_tool['api_type'],
                "toolName": self.configs['tool_name'],
                "params": self.get_params(api_tool['input_params'], kwargs['input_msg']),
            }
            if api_params['apiType'] == '01':  # 01: 汇总， 02：明细
                logger.info(f"api request: url={self.configs['api_url']}, {api_params=}")
                response = self.client.post(self.configs['api_url'], json=api_params).json()

                if isinstance(response, str) or response.get('code') not in ('1', 'SYS.200'):
                    logger.info(f"APIFetch execute failed, ignore this knowledge: {response}")
                    return ExecResult.empty()

                result = {
                    'name': self.configs['tool_name'],
                    'desc': self.configs['tool_desc'],
                    'data': response,
                }
                logger.info(f"APIFetch execute success: {result}")
                return ExecResult.knowledge(json.dumps(result, ensure_ascii=False))
            else:  # 如果最匹配的api不是指标，直接返回提示
                logger.info(f"apiType is not 01, return api_fetch to user: {api_params}")
                return ExecResult(api_params, self.configs['tool_code'])
        except Exception as e:
            logger.error(f"APIFetch execute error: {e}")
            return ExecResult.empty()

    def get_params(self, input_params, input_msg):
        api_params = json.loads(input_params)
        input_params = {}
        logger.info(f"user_messages: {self.chat_chain.get_user_message()}")

        for param in api_params:
            if hasattr(
                current_module := sys.modules[__name__],
                extracter := ('extract_' + param['paramKey']),
            ):
                input_params.update(getattr(current_module, extracter)(input_msg))
        return input_params


prompt = """
# Role: JSON数据提取专家

## Profile
- 当前时间：{current_time}
- description: 专注于从协议内容中快速提取特定JSON字段的数据专家

## References
### 参数列表
{parameter_list}
### 输入内容
{input_message}

## Skills
- 快速定位目标字段
- 精确提取字段值
- 验证数据准确性

## Rules
- 严格遵守输出JSON格式
- 优先保证执行速度
- 不编造或猜测数据
- 保持极简输出
- 仅提取明确存在的字段
- 缺失字段完全排除
- 不做额外解释
- 仅执行提取

## Workflows
- 目标: 根据参数列表中的参数名称提取输入内容中的值并返回标准化的JSON结果
- 步骤 1: 初始化提取规则和目标字段
- 步骤 2: 应用正则表达式进行内容匹配
- 步骤 3: 验证匹配结果的有效性
- 步骤 4: 构建标准JSON输出
- 预期结果: 得到一个包含参数列表的JSON对象

## OutputFormat
1. JSON格式:
- format: text/json
- structure: {{"客户编号": "string", "供电单位": "string"}}
- style: 无缩进，紧凑格式
- special_requirements: 必须严格遵守JSON语法规范

2. 格式规范：
- indentation: 无
- sections: 只包含参数列表内的参数
- highlighting: 不适用

3. 验证规则：
- validation: 检查是否为有效JSON
- constraints: 字段名必须完全匹配，值必须为字符串类型
- error_handling: 任何格式错误都可能导致任务失败

4. 示例说明：
    1. 示例1：
    - 标题: 正常提取情况
    - 格式类型: text/json
    - 说明: 已正确找到参数列表中的客户编号和供电单位
    - 示例内容:
        {{"客户编号": "string", "供电单位": "string"}}
    2. 示例2：
    - 标题: 缺失字段情况
    - 格式类型: text/json
    - 说明: 只找到客户编号，供电单位缺失
    - 示例内容:
        {{"客户编号": "string"}}

## Initialization
作为协议信息提取专家，我将严格遵守上述规则，按照工作流程高效准确地完成任务，并以指定的JSON格式返回结果。
"""


def extract_custNo(input_msg):
    """提取客户编号"""
    return {"custNo": rag.extract_cons_no(input_msg)}


def extract_mobile(input_msg):
    """提取手机号"""
    return {"mobile": rag.extract_mobile(input_msg)}


if __name__ == "__main__":
    from framework.llm import llm_manager
    from settings import CONFIG

    answer = llm_manager.chat(
        CONFIG,
        prompt.format(
            current_time=get_format_time(),
            parameter_list='''
            [
                {"paramKey":"custNo","paramName":"客户编号","paramDesc":"","defaultValue":"6502132312277"},
                {"paramKey":"orgNo","paramName":"供电单位","paramDesc":"","defaultValue":"654060102"},
                {"paramKey":"phone","paramName":"手机号","paramDesc":"","defaultValue":"13645678901"}
            ]
            ''',
            input_message="帮我查询一下户号为6502132311177的售电量",
        ),
    )
    pattern = r'<think>.*?</think>'
    answer = re.sub(pattern, '', answer, flags=re.DOTALL)
    pattern = r'```json|```'
    answer = re.sub(pattern, '', answer, flags=re.DOTALL)
    print(answer.strip())

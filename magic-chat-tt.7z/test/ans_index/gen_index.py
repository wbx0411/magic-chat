import re
import os


def read_idx_info():
    idx_info = {}
    with open(f'{os.path.dirname(__file__)}/idx_info.txt', 'r', encoding='utf-8') as f:
        for line in f:
            key, value = line.strip().split(',')
            idx_info[key] = value
    return idx_info


idx_info = read_idx_info()


def read_menu():
    menus = {}
    with open(f'{os.path.dirname(__file__)}/menu.txt', 'r', encoding='utf-8') as f:
        for line in f:
            name, uri = line.strip().split(',')
            menus[uri.split("?")[0].split("/")[0]] = name
    return menus


menus = read_menu()


def extract_lwt_metrics(text):
    text = re.sub(r'/\*.*?\*/', '', text, flags=re.DOTALL)
    text = re.sub(r'//.*', '', text)
    text = re.sub(r'\blwt_\w+_\w+_\w+\b', lambda match: match.group(0).rsplit('_', 1)[0], text)
    text = re.sub(r'\blwt_\w+_\w+_\w+\b', lambda match: match.group(0).rsplit('_', 1)[0], text)
    text = re.sub(r'\blwt_\w+_\w+_\w+\b', lambda match: match.group(0).rsplit('_', 1)[0], text)
    pattern = r'\blwt_\w+_\w+\b'
    return re.findall(pattern, text)


def extract_table_names(text):
    pattern = r'\bfrom\s+(\w+)\b'
    return re.findall(pattern, text, re.IGNORECASE)


file_filter = (".vue", ".xml", ".js", ".java", ".html", ".ts")


def extract_lwt_metrics_from_files(d):
    metrics = []
    for root, _, files in os.walk(d):
        for file in files:
            if not file.endswith(file_filter):
                continue
            file_path = os.path.join(root, file)
            print("===", file_path)
            with open(file_path, 'r', encoding='utf-8') as f:
                text = f.read()
                metrics += [
                    [
                        next(
                            (
                                name
                                for uri, name in menus.items()
                                if uri in file_path.replace(d + "\\", '')
                                # .replace(r"src\main\resources\mapper", "*")
                                .replace(r"\src\main\resources\resources", "")
                                # .replace(r"src\main\java\ep", "*")
                                # .replace(r"src\main\java\com\neusoft", "*"),
                                .replace("\\", ".")
                            ),
                            "未知菜单",
                        ),
                        m,
                        idx_info.get(m, m),
                        file_path.replace(d + "\\", ''),
                    ]
                    for m in extract_lwt_metrics(text)
                ]
    return metrics


if __name__ == '__main__':
    # # 示例文本
    # text = """
    # a="lwt_YX_JC_HX_047"; some other text bbb= "lwt_YX_JC_JL_003" another_metric ccc='lwt_metric3'
    # """

    # # 提取以“lwt_”开头的指标
    # metrics = extract_lwt_metrics(text)
    # print(metrics)

    # 指定文件夹路径
    directory = 'E:/work/2402-ai/瞭望台'

    # 提取文件夹下所有文件中以“lwt_”开头的指标
    all_metrics = extract_lwt_metrics_from_files(directory)
    # print(all_metrics)
    with open(f'{os.path.dirname(__file__)}/out.csv', 'w', encoding='gbk') as out_file:
        for metric in sorted(set(",".join(_) for _ in all_metrics)):
            out_file.write(f"{metric}\n")

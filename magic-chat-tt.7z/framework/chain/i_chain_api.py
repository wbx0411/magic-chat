from abc import ABC, abstractmethod
from langchain_core.messages import (
    AIMessage,
    HumanMessage,
)


class ChainABC(ABC):

    @abstractmethod
    async def call(self, info, message):
        pass

    def add_message(self, user_message, ai_message=""):
        self.add_user_message(user_message)
        self.add_ai_message(ai_message)

    def add_user_message(self, message):
        self.chain.memory.chat_memory.add_user_message(message)

    def add_ai_message(self, message):
        self.chain.memory.chat_memory.add_ai_message(message)

    def get_user_message(self):
        return [
            message.content
            for message in self.chain.memory.buffer
            if isinstance(message, HumanMessage)
        ]

    def get_ai_message(self):
        return [
            message.content
            for message in self.chain.memory.buffer
            if isinstance(message, AIMessage)
        ]

from datetime import datetime

from framework.algorithm.simple_bm25 import SimpleBM25

bm25 = SimpleBM25()


def cmp_current_date(data_time):
    if data_time is None:
        return True
    if len(data_time) == 4:
        if int(data_time) == datetime.now().year:
            return True
    elif len(data_time) == 6:
        if int(data_time) == datetime.now().year * 100 + datetime.now().month:
            return True
    elif len(data_time) == 8:
        if (
            int(data_time)
            == datetime.now().year * 10000 + datetime.now().month * 100 + datetime.now().day
        ):
            return True
    return False


def get_date_time_type(data_time):
    if len(data_time) == 4:
        return 'year'
    elif len(data_time) == 6:
        return 'month'
    elif len(data_time) == 8:
        return 'day'
    return 0


def parse_season(input_str, date_str, score):
    if not date_str or len(date_str) != 4:
        return date_str
    data = {
        'Q1': ["一季度", "第一季度", "1季度", "第1季度"],
        'Q2': ["二季度", "第二季度", "2季度", "第2季度"],
        'Q3': ["三季度", "第三季度", "3季度", "第3季度"],
        'Q4': ["四季度", "第四季度", "4季度", "第4季度"],
    }
    season_docs = [{"name": x, "value": y} for y in data for x in data[y]]
    season_match = bm25.query(season_docs, input_str, 1, min_score=score)
    if not season_match:
        return date_str
    return f"{date_str}{season_match[0]['value']}"


def parse_recommend_date(input_str):
    if not input_str:
        return ''
    current_year = datetime.now().year
    current_month = datetime.now().month
    current_day = datetime.now().day

    date_nlp = input_str
    if len(input_str) == 4:
        if int(input_str) == current_year:
            date_nlp = "今年"
        elif int(input_str) == current_year - 1:
            date_nlp = "去年"

    elif len(input_str) == 6:
        if int(input_str) == current_year * 100 + current_month:
            date_nlp = "本月"
        elif int(input_str) == current_year * 100 + current_month - 1:
            date_nlp = "上月"
    elif len(input_str) == 8:
        if int(input_str) == current_year * 10000 + current_month * 100 + current_day:
            date_nlp = "今天"
        elif int(input_str) == current_year * 10000 + current_month * 100 + current_day - 1:
            date_nlp = "昨天"

    return date_nlp

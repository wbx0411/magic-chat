import json
import os
import re

from framework.llm.llm_manager import LLMManager
from transport.db.oradb import OracleDB
from utils.config_utils import SysConfig

configs = SysConfig.get_config()
llm = LLMManager.create_llm(configs)
db = OracleDB("oracle_95598")
current_path = os.path.dirname(__file__)

system_prompt = """
你是国家电网95598客服中心的专家，95598客服中心的工单类型有以下分类：
{types}
"""

user_prompt = """
如果客服工单的处理方案为：
{message}
请给出最适合这个处理方案的两个工单类型。
多层级类型用**分隔，例如：***一级类型 > 二级类型***。
回答时，最先给出结论。
"""

system_prompt_duanxin = """
你是国家电网95598客服中心的专家，95598客服中心的工单类型有以下分类：
一、电力短信订阅变更：
电力短信订阅是一种为电力用户提供的免费增值服务，用户可以通过订阅该服务，以短信方式接收电费账单、购电信息、电费预警、欠费等电力相关信息；
当出现以下情况时用户会进行电力短信订阅变更
1、本人手机号变动：当用户更换手机号码时，需要更新电力短信订阅服务中的手机号码，以确保能够继续接收电力相关信息。
2、本家庭内短信订阅变更：在家庭内部，可能存在多个用户共同使用电力账户的情况。此时，如果某个用户的手机号码发生变化，或者需要更改账务联系人或法人联系人的信息，也需要进行电力短信订阅变更。
3、房屋转让客户更名：当房屋发生转让时，新的业主需要更改电力账户的相关信息，包括短信订阅服务的手机号码等。
4、短信号码绑定错误：由于各种原因导致的短信号码绑定错误，用户在进行缴费等业务后没有收到短信

二、电力短信订阅取消：
电力短信订阅是一种为电力用户提供的免费增值服务，用户可以通过订阅该服务，以短信方式接收电费账单、购电信息、电费预警、欠费等电力相关信息；
电力短信订阅取消是指用户主动取消之前订阅的电力相关短信服务。这通常意味着用户不再希望接收来自电力供应商的电费账单、购电信息、电费预警等短信通知。以下是对电力短信订阅取消原因的详细解释：
1、手机号码变更：当用户更换手机号码时，如果不再使用原手机号码接收短信，可能需要取消原手机号码的电力短信订阅。
2、房屋租住：由于房屋租住退租等原因，需要取消短信订阅
3、信息冗余：部分用户可能认为电力短信服务提供的信息冗余，或者已经通过其他渠道（如网上国网APP、微信公众号等）获取了相关信息，因此不再需要短信服务。
4、隐私保护：出于对个人隐私保护的考虑，部分用户可能希望减少接收来自不同机构的短信通知，以避免个人信息泄露的风险。
5、短信号码绑定错误：由于各种原因导致的短信号码绑定错误，用户收到了不属于自己用电的短信信息

以下是一些例子来帮助你更好地理解这个任务：
  例1：
  提供文本：【处理完毕】【西安市灞桥区】2024年10月02日11：02分，国网西安供电公司市东供电分公司席王供电所工作人员乔小涛 （电话：83529932）与客户（电话：18992870468）（客户编号：客户无法提供）进行联系，见附件。客户来电反映，因房子租住的原因，现在要求取消户号为6103946914181的电力短信订阅，接受手机号：13629291482，请相关工作人员核实处理。2024年10月02日11：20分，工作人员告知客户，已在营销系统将户号为6103946914181接收手机号13629291482取消，即时生效。该客户对工作人员的服务态度表示满意。处理人：国网西安供电公司市东供电分公司席王供电所工作人员乔小涛 （电话：83529932）。
  结果应为：
  {
    "用户电话": "13629291482",
    "工单类型": "取消",
    "完成状态": "已完成",
    "户号": "6103946914181"
  }
  例2：
  提供文本：【处理完毕】【西安市灞桥区】2024年10月3日11：03分，国网西安市东供电公司纺织城供电所工作人员荀晨浩（81010227）与客户（13402953648）（用户编号：客户未提供）联系（见附件）客户来电反映，取消户号为6103226779893、接受手机号为13402953648的预警短信，请相关工作人员核实处理。经了解，该客户反映收到非本人的电力短信，需要工作人员帮忙取消。工作人员了解情况后于2024年10月3日11:27分通过营销2.0系统将电话号码由13402953648变更为18502969807，即时生效，并告知客户,客户联系方式调整时间为2024年10月3日11:27分，客户表示知晓并对工作人员的服务态度表示满意。处理人：国网西安市东供电公司纺织城供电所工作人员荀晨浩（81010227）。
  结果应为：
  {
    "用户电话": "18502969807",
    "工单类型": "变更",
    "完成状态": "已完成",
    "户号": "6103226779893"
  }
  例3：
  提供文本：【处理完毕】【西咸新区沣西新城】2024年01月05日17时01分，沣西新城供电分公司统一中心供电所工作人员薛明喜（电话：18503442149）电话联系客户（电话：15802987157）（见附件:7157），客户编号：客户未提供，因客户未提供客户编号故无法得知客户名称以及所属台区，根据用电地址该客户属于统一中心供电所管辖。工作人员根据客户提供信息到达现场核实是否存在安全隐患，检查结果为景三线3号柜柜门正常关闭无异常，已向客户解释清楚，客户表示满意。处理人：沣西新城供电分公司统一中心供电所工作人员薛明喜（电话：18503442149）。
  结果应为：
  {
    "用户电话": "15802987157",
    "工单类型": "其他",
    "完成状态": "已完成",
    "户号": "无"
  }
"""

user_prompt_duanxin = """
如果客服工单的处理方案为：
{message}
判断这个处理方案，提取用户电话、完成状态（已完成、未完成）、工单类型（变更、取消）、户号（用户编号），以json格式返回。
如果未识别出工单类型，请回答“其他”。
"""


def read_ling_types():
    with open(f'{current_path}/type_95598.txt', 'r', encoding='utf-8') as f:
        return [line.strip() for line in f]


def read_app_no():
    with open(f'{current_path}/app_no.txt', 'r', encoding='utf-8') as f:
        return [line.strip() for line in f]


def read_json_types():
    with open(f'{current_path}/type_95598.json', 'r', encoding='utf-8') as f:
        return json.load(f)


def read_handle_situation():
    with open(f'{current_path}/handle_situation.txt', 'r', encoding='utf-8') as f:
        return [line.split('\t') for line in f]


def find_types(content):
    types = re.findall(r"\*\*\*(.*?)\*\*\*", content)
    if not types or len(types) == 0:
        types = ["", ""]
    elif len(types) == 1:
        types.append("")
    return types


def find_json_str(content):
    # 通过正则表达式匹配json字符串
    json_str = re.findall(r"```json(.*?)```", content, re.DOTALL)
    return json_str[0] if json_str else content


def generate_types():
    types_sql = """
        SELECT TYPE_LEVEL1, TYPE_LEVEL2, TYPE_LEVEL3 
        FROM SH.MS_DR_95998_2024
        WHERE TYPE_LEVEL1 NOT LIKE '%删%'
        AND  TYPE_LEVEL2 NOT LIKE '%删%'
        AND  TYPE_LEVEL3 NOT LIKE '%删%'
        GROUP BY TYPE_LEVEL1, TYPE_LEVEL2, TYPE_LEVEL3 
        ORDER BY TYPE_LEVEL1 ,TYPE_LEVEL2, TYPE_LEVEL3
    """
    results = db.query(types_sql)

    types = {}
    for result in results:
        level1 = result["TYPE_LEVEL1"]
        level2 = result["TYPE_LEVEL2"]
        level3 = result["TYPE_LEVEL3"]
        if level1 not in types:
            types[level1] = {}
        if level2 and level2 != '-' and level2 not in types[level1]:
            types[level1][level2] = []
        if level3 and level3 != '-' and level3 not in types[level1][level2]:
            types[level1][level2].append(level3)
    print(types)


def main():
    results = db.query("""
        SELECT *
        FROM SH.MS_DR_95998_2024
        WHERE LLM_TYPE1 IS NULL
        AND LLM_TYPE2 IS NULL
        AND rownum < 100
    """)
    update_sql = """
        update SH.MS_DR_95998_2024 
        set LLM_TYPE1=:type1, LLM_TYPE2=:type2, LLM_MODEL_NAME=:model_name 
        where ID=:id
    """
    types_95598 = read_json_types()
    for index, result in enumerate(results):
        answer = llm.invoke([
            ("system", system_prompt.format(types=types_95598)),
            ("human", user_prompt.format(message=result["HANDLE_SITUATION"]))
        ])
        print(answer.content)
        types = find_types(answer.content)
        db.execute(update_sql, (types[0], types[1], configs['model_name'], result["ID"]))
        print(f"{index + 1} / {len(results)}")


def main_duanxin(tag):
    results = db.query("""
        SELECT ID, HANDLE_SITUATION
        FROM SH.MS_DR_95998_2024
        WHERE LLM_PHONE IS NULL
        AND LLM_TYPE IS NULL
        AND LLM_STATUS IS NULL
        AND LLM_CONS_NO IS NULL
    """)
    update_sql = """
        update SH.MS_DR_95998_2024 
        set LLM_PHONE=:phone, LLM_TYPE=:type, LLM_STATUS=:status, LLM_CONS_NO=:cons_no, 
        LLM_MODEL_NAME=:model_name, LLM_TAG=:tag, LLM_ANSWER=:answer
        where ID=:id
    """
    for index, result in enumerate(results):
        answer = llm.invoke([
            ("system", system_prompt_duanxin),
            ("human", user_prompt_duanxin.format(message=result["HANDLE_SITUATION"]))
        ])
        print(answer.content)
        try:
            json_ans = json.loads(find_json_str(answer.content))
            db.execute(update_sql, (
                json_ans['用户电话'] if isinstance(json_ans['用户电话'], str) else ','.join(json_ans['用户电话']),
                json_ans['工单类型'], json_ans['完成状态'],
                json_ans['户号'] if isinstance(json_ans['户号'], str) else ','.join(json_ans['户号']),
                configs['model_name'], tag, answer.content, result["ID"]
            ))
        except Exception as e:
            print(e)
        print(f"{index + 1} / {len(results)}")


if __name__ == '__main__':
    # print(read_json_types())

    # main()
    # main_duanxin(datetime.datetime.now().strftime("%Y%m%d%H%M%S"))

    # app_nos = read_app_no()
    # rs = db.query(f"""
    #     SELECT *
    #     FROM SH.MS_DR_95998_2024
    #     WHERE app_no in ({','.join([':{}'.format(i+1) for i in range(len(app_nos))])})
    # """, *app_nos)
    # print(rs)

    # 【处理完毕】【西安市灞桥区】2024年10月3日11：03分，国网西安市东供电公司纺织城供电所工作人员荀晨浩（81010227）与客户（13402953648）（用户编号：客户未提供）联系（见附件）客户来电反映，取消户号为6103226779893、接受手机号为13402953648的预警短信，请相关工作人员核实处理。经了解，该客户反映收到非本人的电力短信，需要工作人员帮忙取消。工作人员了解情况后于2024年10月3日11:27分通过营销2.0系统将电话号码由13402953648变更为18502969807，即时生效，并告知客户,客户联系方式调整时间为2024年10月3日11:27分，客户表示知晓并对工作人员的服务态度表示满意。处理人：国网西安市东供电公司纺织城供电所工作人员荀晨浩（81010227）。
    # ans = llm_invoke_duanxin("""
    # 【处理完毕】【西安市灞桥区】2024年10月07日13：29分，
    # 国网西安供电公司市东分公司灞桥供电所工作人员吴启栋（83615311）与客户（15389237107）
    # （用户编号：6103956970696）联系（见附件），
    # 客户来电反映收到户号为6103956961890和户号为6103956961379的欠费和余额短信提醒，
    # 短信接收号码15389237107，短信发送平台号码10694403955980955980，
    # 客户表示这2个户号都不是自己的，要求都解绑手机号，都给取消短信，烦请尽快处理。
    # 经核实，客户提供户号的预留电话为上户时预留，经与客户沟通，需要取消。
    # 工作人员已在2024年10月7日13：39分已在营销系统将电话给客户取消，即刻生效，该客户对工作人员服务态度表示满意。
    # """)
    # print(ans.content)

    # print(configs['model_name'])
    # for hs in read_handle_situation():
    #     if not hs or len(hs) < 2:
    #         continue
    #     ans = llm_invoke_duanxin(hs[1])
    #     print(ans.content)
    #     json_ans = json.loads(find_json_str(ans.content))
    #     vals = [val if isinstance(val, str) else ','.join(val) for val in json_ans.values()]
    #     print(hs[0] + "\t" + "\t".join(vals))

    params = {
        "app_no": '2023123073942403',
        "id": 542806,
        "city_name": '国网宝鸡供电公司',
        "coun_name": '高新公司'
    }
    rs = db.query(f"""
        SELECT *
        FROM SH.MS_DR_95998_2024
        WHERE app_no = :app_no
        and id = :id
        and city_name = :city_name
        and coun_name = :coun_name
    """, params)
    print(rs)

import os


os.environ['ORACLE_HOME'] = r'D:\devtools\instantclient_11_2'
os.environ['RUN_ENV'] = 'liao'


if __name__ == '__main__':
    from biz.index.jieba_manager import gen_jieba_dict
    gen_jieba_dict()

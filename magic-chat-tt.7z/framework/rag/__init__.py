import re


def rmWWW(txt):
    """
    去除问句中的无效词
    :param txt: 输入文本
    :return: 处理后的文本
    """
    patts = [
        (
            r"是*(什么样的|哪家|一下|那家|请问|啥样|咋样了|什么时候|何时|何地|何人|是否|是不是|多少|哪里|怎么|哪儿|怎么样|如何|哪些|是啥|啥是|啊|吗|呢|吧|咋|什么|有没有|呀|谁|哪位|哪个)是*",
            "",
        ),
        (r"(^| )(what|who|how|which|where|why)('re|'s)? ", " "),
        (
            r"(^| )('s|'re|is|are|were|was|do|does|did|don't|doesn't|didn't|has|have|be|there|you|me|your|my|mine|just|please|may|i|should|would|wouldn't|will|won't|done|go|for|with|so|the|a|an|by|i'm|it's|he's|she's|they|they're|you're|as|by|on|in|at|up|out|down|of|to|or|and|if) ",
            " ",
        ),
    ]
    otxt = txt
    for r, p in patts:
        txt = re.sub(r, p, txt, flags=re.IGNORECASE)
    if not txt:
        txt = otxt
    return txt


def extract_cons_no(txt):
    """
    提取用户号
    :param txt: 输入消息
    :return: 用户号
    """
    match = re.search(r'(?<!\d)\d{13}(?!\d)', txt)
    return match.group(0) if match else None


def extract_mobile(txt):
    """
    提取手机号
    :param txt: 输入消息
    :return: 手机号
    """
    match = re.search(r'1[3-9]\d{9}(?!\d)', txt)
    return match.group(0) if match else None


def extract_time(txt):
    """
    提取时间
    :param txt: 输入消息
    :return: 时间
    """
    match = re.search(r'(\d{4}[-/]\d{1,2}[-/]\d{1,2})|(\d{1,2}[-/]\d{1,2}[-/]\d{4})', txt)
    return match.group(0) if match else None

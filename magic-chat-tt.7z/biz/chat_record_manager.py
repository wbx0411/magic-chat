import asyncio

from transport.db.basedb import BaseDB
from utils.config_utils import SysConfig
from utils.logger_utils import LoggerFactory

configs = SysConfig.get_config()
logger = LoggerFactory.get_logger(__name__)

sql_ora = f"""
    INSERT INTO AI_CHAT_RECORDS 
    VALUES (SEQ_AI_CHAT_RECORDS.NEXTVAL, :1, :2, :3, :4, :5, :6, SYSDATE, :7, :8)
"""
sql_pg = f"""
    INSERT INTO ai_chat_records
    (session_code, question, api_code, answer, org_no, rating, vector_duration, llm_duration)
    VALUES ({('%s,' * 8)[:-1]})
"""


class ChatRecordManager:

    def __init__(self):
        self.db_instance: list[tuple[BaseDB, str]] = []
        record_dbs = configs['chat_record_dbs'] or []
        for db in set(record_dbs):
            if db.startswith('postgres'):
                from transport.db.postgresdb import PostgresDB

                self.db_instance.append((PostgresDB(db), sql_pg))
            elif db.startswith('oracle'):
                from transport.db.oradb import OracleDB

                self.db_instance.append((OracleDB(db), sql_ora))
            else:
                raise ValueError(f"Invalid chat record db: {db}")
            logger.debug(f"{db} initialized in ChatRecordManager")

    def add_chat_record(
        self,
        session_code,
        question,
        api_code,
        answer,
        org_no,
        vector_duration,
        llm_duration,
        rating=None,
    ):
        tasks = []
        for instance, sql in self.db_instance:
            tasks.append(
                self.add_chat_record_async(
                    instance,
                    sql,
                    session_code,
                    question,
                    api_code,
                    answer,
                    org_no,
                    vector_duration,
                    llm_duration,
                    rating,
                )
            )
        if tasks:
            asyncio.gather(*tasks)

    @staticmethod
    async def add_chat_record_async(
        instance: BaseDB,
        sql: str,
        session_code,
        question,
        api_code,
        answer,
        org_no,
        vector_duration,
        llm_duration,
        rating=None,
    ):
        try:
            instance.execute(
                sql,
                (
                    session_code,
                    question,
                    api_code,
                    answer,
                    org_no,
                    rating,
                    vector_duration,
                    llm_duration,
                ),
            )
            logger.debug(f"Insert chat record to [{instance.config_name}]: {session_code}")
            await asyncio.sleep(0)
        except Exception as e:
            logger.error(
                f"Failed to insert chat record to {instance.config_name}: %s", e, exc_info=True
            )


if __name__ == '__main__':
    # todo oracle need to be tested
    ChatRecordManager().add_chat_record(
        session_code='test001',
        question="question",
        api_code="api_code",
        answer="answer",
        org_no="org_no",
        vector_duration=100,
        llm_duration=200,
        rating=1,
    )

import httpx

from utils.logger_utils import LoggerFactory


class AuthClient:
    def __init__(self, base_url, timeout=5):
        self.base_url = base_url
        self.headers = {
            "accept": "*/*",
            # "Content-Type": "application/json;charset=UTF-8"
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
        }
        self.timeout = timeout
        self.client = httpx.Client(headers=self.headers, timeout=self.timeout)
        self.logger = LoggerFactory.get_logger(__name__)
        self.logger.info(f"AuthClient initialized with base_url: {self.base_url}")

    def check_auth(self, auth_code):
        self.logger.info(f"Checking auth for code: {auth_code}")
        url = f"{self.base_url}"
        data = {"authCode": auth_code}

        try:
            response = self.client.post(url, headers=self.headers, data=data)
            if response.status_code == 200:
                try:
                    response_json = response.json()
                    return self._handle_response(response_json)
                except ValueError:
                    self.logger.error("Failed to parse JSON response.")
                    return self._build_response(False, "解析JSON失败", None)
            else:
                self.logger.error(f"Received error status code: {response.status_code}, response: {response.text}")
                return self._build_response(False, f"请求错误, 状态码: {response.status_code}", None)
        except httpx.RequestError as e:
            self.logger.error(f"Request failed: {str(e)}")
            return self._build_response(False, f"请求失败: {str(e)}", None)

    def _handle_response(self, response_json):
        if response_json.get("code") == "SYS.200":
            self.logger.info("Auth check successful.")
            return self._build_response(True, "请求成功", response_json['data']['userInfo'])
        else:
            self.logger.warning("Auth check failed.")
            return self._build_response(False, "请求失败", response_json)

    def _build_response(self, success, message, data):
        return {"success": success, "message": message, "data": data}

# # 使用示例
# if __name__ == "__main__":
#     client = AuthClient("http://10.4.59.50")
#     result = client.check_auth("7174235946299166000")
#     print(result['message'])
#     if result['data']:
#         print(result['data'])
# shan: 373235353034393238323034353038333938347c7378746573747c3030303030303430

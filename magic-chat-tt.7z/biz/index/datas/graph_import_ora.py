import csv
import datetime
import os

from py2neo import Node, NodeMatcher, Relationship

from biz.index.datas.graph_import import create_graph_index, clear_graph, node_embedding
from biz.index.datas.graph_import_csv import import_graph_scene
from biz.index.metadata import *
from transport.db.neo4jdb import Neo4jDB
from transport.db.oradb import OracleDB
from utils.config_utils import SysConfig
from utils.logger_utils import LoggerFactory

configs = SysConfig.get_config()
neo4j = Neo4jDB()
graph_db = neo4j.get_engine()
node_matcher = NodeMatcher(graph_db)
logger = LoggerFactory.get_logger(__name__)

oraDB = OracleDB('oracle_dqs')
encoding = configs['encoding']
org_name_map = configs['org_name_map'] if 'org_name_map' in configs else {}


def import_yz_idx(ns):
    sql = "SELECT * FROM bm_yz_idx_info ORDER BY yz_idx_code"
    idx_list = oraDB.query(sql)
    for idx in idx_list:
        try:
            node = Node(
                ns, label_idx, label_idx_yz,
                name=idx['YZ_IDX_NAME'],
                code=idx['YZ_IDX_CODE'],
                label=label_idx_yz,
                desc=idx['YZ_IDX_DESC']
            )
            graph_db.merge(node, label_idx_yz, 'code')
        except Exception as e:
            logger.error(f"Row: {idx}, Error: {str(e)}")
            raise e
    logger.info(f"{len(idx_list)} yz indexes have been imported into the database.")
    return len(idx_list)


def import_dimension(ns):
    sql = "SELECT * FROM VIEW_BM_DIMENSION_INFO ORDER BY id"
    dim_list = oraDB.query(sql)
    for dim in dim_list:
        try:
            node = Node(
                ns, label_idx, label_idx_dim,
                name=dim['DIMENSION_NAME'],
                code=dim['STD_COL_NAME'],
                label=label_idx_dim,
                desc=dim['DIMENSION_CODE']
            )
            graph_db.merge(node, label_idx_dim, 'code')
        except Exception as e:
            logger.error(f"Row: {dim}, Error: {str(e)}")
            raise e
    logger.info(f"{len(dim_list)} dimensions have been imported into the database.")
    return len(dim_list)


def import_dimension_rela(ns):
    rela_name = '使用'
    sql = "SELECT * FROM view_bm_yz_dimension_rela ORDER BY yz_idx_code, dimension_code"
    rela_list = oraDB.query(sql)
    for rela in rela_list:
        try:
            start_node = node_matcher.match(ns, label_idx_yz, code=rela['YZ_IDX_CODE']).first()
            if not start_node:
                logger.error(f"StartNode {label_idx_yz} - {rela['YZ_IDX_CODE']} not found.")
                continue
            end_node = node_matcher.match(ns, label_idx_dim, desc=rela['DIMENSION_CODE']).first()
            if not end_node:
                logger.error(f"EndNode {label_idx_dim} - {rela['DIMENSION_CODE']} not found.")
                continue

            rel_prop = {'NAME': rela_name}
            if 'REQUIRED' in rela:
                weight = 9999 if rela['REQUIRED'] == 'Y' else 0
                rel_prop['WEIGHT'] = weight

            r = Relationship(start_node, ns, end_node, **rel_prop)
            graph_db.merge(r)
        except Exception as e:
            logger.error(f"Row: {rela}, Error: {str(e)}")
            raise e
    logger.info(f"{len(rela_list)} relationships have been imported into the database.")
    return len(rela_list)


def import_dimension_value(ns):
    rela_name = '包含'
    sql_prop = "SELECT * FROM EP_PROP_LIST WHERE PROP_TYPE_ID = :1"
    sql_dim = "SELECT * FROM VIEW_BM_DIMENSION_INFO ORDER BY ID"
    sql_value = "SELECT * FROM view_bm_dimension_value WHERE DIMENSION_CODE = :1 ORDER BY DIMENSION_VALUE"

    dim_list = oraDB.query(sql_dim)
    dim_values_count = 0
    for dim in dim_list:
        try:
            table_name = dim['TABLE_NAME']
            dimension_code = dim['DIMENSION_CODE']
            root_node = node_matcher.match(ns, label_idx_dim, desc=dimension_code).first()
            if not root_node:
                logger.info(f"Node {label_idx_dim} - {dim} not found.")
                continue

            if 'ep_prop_list' in table_name:
                prop_type_id = dim['COL_NAME']
                if 'ecCateg' == prop_type_id:
                    value_list = oraDB.query(sql_prop + "and LENGTH(PROP_LIST_ID) = 2", (prop_type_id,))
                elif prop_type_id in ['trade_type_code', 'indElecCls']:
                    value_list = oraDB.query(sql_prop + " and PROP_LIST_ID like '%%000'", (prop_type_id,))
                else:
                    value_list = oraDB.query(sql_prop, (prop_type_id,))

                column_name = 'PROP_LIST_NAME'
                column_code = 'PROP_LIST_ID'
            elif 'view_bm_dimension_value' in table_name:
                value_list = oraDB.query(sql_value, (dimension_code,))
                column_name = 'VALUE_NAME'
                column_code = 'DIMENSION_VALUE'
            else:
                continue

            if value_list:
                dim_values_count += len(value_list)
                for value in value_list:
                    node = Node(
                        ns, label_idx, label_idx_val,
                        name=value[column_name],
                        code=value[column_code],
                        label=label_idx_val,
                        desc=''
                    )
                    graph_db.merge(node, label_idx_val, ('code', 'name'))
                    graph_db.merge(Relationship(root_node, ns, node, name=rela_name))

        except Exception as e:
            logger.error(f"Row: {dim}, Error: {str(e)}")
            raise e
    logger.info(f"{dim_values_count} dimension values have been imported into the database.")
    return dim_values_count


def import_org(ns):
    sql = "SELECT * FROM sa_org WHERE is_delete = '0' and org_tree is not null ORDER BY org_tree"
    org_list = oraDB.query(sql)
    org_dict = {o['ORG_NO']: o for o in org_list}

    _import_org_subs(ns, org_dict, org_list, p_org='0')
    logger.info(f"{len(org_list)} organizations have been imported into the database.")
    return len(org_list)


def _import_org_subs(ns, org_dict, org_list, p_org='0'):
    rela_name = '包含'
    for o in _find_dict_by_key_value(org_list, 'P_ORG_NO', p_org):
        try:
            org_type = o['ORG_TYPE']
            org_name = o['ORG_NAME']
            org_tree = o['ORG_TREE']
            org_name_s = _get_org_name_display(o)
            org_tree_list = org_tree.split('|')

            # 如果供电单位是客服中心则从地市开始
            if org_name_s in org_logic_unit:
                org_tree_list = org_tree_list[1:-1]
            else:
                org_tree_list = org_tree_list[2:-1]

            org_name_concat = []
            for x in org_tree_list:
                if x in org_dict:
                    org_name_concat.append(_get_org_name_display(org_dict[x]))
            org_name_concat.append(org_name_s)
            org_name_str = ''.join(org_name_concat)

            node = Node(
                ns, label_org,
                name=org_name_str,
                code=o['ORG_NO'],
                label=label_org,
                desc=org_name,
                info=org_tree,
                type=org_type
            )
            graph_db.merge(node, label_org, 'code')
            if p_org != '0':
                parent_node = node_matcher.match(ns, label_org, code=p_org).first()
                if not parent_node:
                    logger.error(f"StartNode {label_org} - {p_org} not found.")
                    continue
                r = Relationship(parent_node, ns, node, name=rela_name)
                graph_db.merge(r)

            _import_org_subs(ns, org_dict, org_list, o['ORG_NO'])
        except Exception as e:
            logger.error(f"Row: {o}, Error: {str(e)}")
            raise e


def _get_org_name_display(org):
    org_name = org['ORG_NAME']
    if org_name in org_name_map:
        org_name_s = org_name_map[org_name]
    else:
        org_name_s = org['ATTR1'] if org['ATTR1'] else org_name
    return org_name_s


def _find_dict_by_key_value(dict_list, key, value):
    for d in dict_list:
        if d[key] == value:
            yield d


def export_db_to_csv(path='graph'):
    csv_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), path)

    # 维度 -> 纬度值
    dimension_value_dict = [
        ("01", "用电类别",
         "select prop_list_id, prop_list_name from ep_prop_list where prop_type_id = 'ecCateg' and length(prop_list_id) = 2"),
        ("02", "行业类别",
         "select prop_list_id, prop_list_name from ep_prop_list where prop_type_id = 'indElecCls' and prop_list_id like '%%000'"),
        ("03", "用户分类",
         "select prop_list_id, prop_list_name from ep_prop_list where prop_type_id = 'custCls'"),
        ("04", "电压等级",
         "select prop_list_id , prop_list_name from ep_prop_list where prop_type_id = 'baseVolt'"),
        # ("05", "催费责任人",),
        # ("06", "抄表责任人",),
        # ("07", "台区经理",),
    ]

    conf_list = [
        ("entity_yz", "select yz_idx_code, yz_idx_name,'' from bm_yz_idx_info"),
        ("entity_dimension",
         "select std_col_name, dimension_name, dimension_code from VIEW_BM_DIMENSION_INFO order by dimension_code"),
        ("rela_yz-dimension", "select yz_idx_code, dimension_code from view_bm_yz_dimension_rela")
    ]

    conf_list.extend(list(map(lambda x: (f"dimension_value_{x[0]}", x[2]), dimension_value_dict)))

    # 当前时间戳
    now = datetime.datetime.now()
    for conf in conf_list:
        file_path = os.path.join(csv_path, f"{conf[0]}_{now.strftime('%Y%m%d%H')}.csv")
        with open(file_path, 'w', encoding=encoding, newline='') as f:
            writer = csv.writer(f)
            result = oraDB.query(conf[1])
            for r in result:
                row = list(r.values())
                writer.writerow(row)
        logger.info(f"Export to {file_path}.")


def import_graph(ns, scope=None):
    if scope == 'all':
        create_graph_index(ns)
        clear_graph(ns)
    if scope == 'all' or scope == 'org':
        count_org = import_org(ns)
        node_embedding(ns, label_org)
    else:
        count_org = 0
        clear_graph(f"{ns} & !{label_org}")
    count_idx = import_yz_idx(ns)
    count_dim = import_dimension(ns)
    count_rela = import_dimension_rela(ns)
    count_val = import_dimension_value(ns)
    count_scene, count_scene_rel = import_graph_scene(ns)
    node_embedding(ns, label_idx)
    result = {
        "idx count": count_idx,
        "dim count": count_dim,
        "rela count": count_rela,
        "val count": count_val,
        "scene count": count_scene,
        "scene rela count": count_scene_rel,
        "org count": count_org
    }
    return result


if __name__ == '__main__':
    _namespace = configs['neo4j_config']['namespace']

    info = import_graph(_namespace, "")
    print(info)

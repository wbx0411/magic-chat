import base64


class SimpleEncryptor:
    def __init__(self, salt="QIN"):
        self.salt = salt

    def encrypt(self, message: str) -> str:
        """
        '加密'消息，实际上是对消息进行base64编码，并在编码前后添加盐。
        :param message: 要加密的字符串。
        :return: 编码后的字符串。
        """
        salted_message = self.salt + message + self.salt  # 在消息前后添加盐
        message_bytes = salted_message.encode('utf-8')  # 将字符串转换为字节
        base64_bytes = base64.b64encode(message_bytes)  # 对字节进行base64编码
        base64_message = base64_bytes.decode('utf-8')  # 将编码后的字节转换回字符串
        return base64_message

    def decrypt(self, base64_message: str) -> str:
        """
        '解密'消息，实际上是对base64编码的消息进行解码，并移除前后的盐。
        :param base64_message: 要解密的编码字符串。
        :return: 解码后的字符串，移除了前后的盐。
        """
        base64_bytes = base64_message.encode('utf-8')  # 将编码的字符串转换为字节
        message_bytes = base64.b64decode(base64_bytes)  # 对字节进行base64解码
        salted_message = message_bytes.decode('utf-8')  # 将解码后的字节转换回字符串
        if salted_message.startswith(self.salt) and salted_message.endswith(self.salt):
            return salted_message[len(self.salt) : -len(self.salt)]  # 移除前后的盐
        else:
            raise ValueError("Message does not contain the correct salt or has been tampered with.")


# # 使用示例
if __name__ == "__main__":
    encryptor = SimpleEncryptor()
    print("Original:" + encryptor.decrypt("UUlOTmV1c29mdF8xMjNRSU4="))
    print("Encrypted:" + encryptor.encrypt("Neusoft_123"))
    # # python执行文件 获取第二个参数，并进行加密，第一个参数是d或e，即解密或加密
    # import sys
    # if len(sys.argv) > 2:
    #     encrypt_type = sys.argv[1]
    #     original_message = sys.argv[2]
    #     encrypted_message = None
    #     if encrypt_type == "d":
    #         encrypted_message = encryptor.decrypt(original_message)
    #         print(f"Encrypted (base64): {original_message}")
    #         print(f"Original: {encrypted_message}")
    #     elif encrypt_type == "e":
    #         encrypted_message = encryptor.encrypt(original_message)
    #         print(f"Original: {original_message}")
    #         print(f"Encrypted (base64): {encrypted_message}")
    #     else:
    #         print("Wrong encrypt type.")
    # else:
    #     print("Please provide encrypt type and a message.")


#
#     original_message = "postgres"
#     encrypted_message = encryptor.encrypt(original_message)
#     decrypted_message = encryptor.decrypt(encrypted_message)
#
#     print(f"Original: {original_message}")
#     print(f"Encrypted (base64): {encrypted_message}")
#     print(f"Decrypted: {decrypted_message}")

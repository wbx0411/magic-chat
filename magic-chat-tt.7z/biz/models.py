from pgvector.sqlalchemy import Vector
from sqlalchemy import Column, Integer, Text, String, TIMESTAMP, func, CheckConstraint, Float, ARRAY
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import mapped_column

Base = declarative_base()


class MiopModuleEmbedding(Base):
    __table_name__ = 'miop_module_embedding'
    embedding = mapped_column(Vector(512))
    vector_id = Column(Integer, primary_key=True)
    api_code = Column(String(255))
    api_desc = Column(Text)


class MiopModuleRoute(Base):
    __table_name__ = 'miop_module_route'
    id = Column(Integer, primary_key=True)
    key_words = Column(ARRAY(Text))
    vector_id = Column(Integer)


class MiopModuleDatas(Base):
    __table_name__ = 'miop_module_datas'
    vector_id = Column(Integer)
    module_description = Column(Text)
    module_name = Column(Text)
    api_code = Column(String(255), primary_key=True)
    org_no = Column(String(16), primary_key=True)


class ChatRecord(Base):
    __table_name__ = 'chat_records'
    id = Column(Integer, primary_key=True, autoincrement=True)
    session_code = Column(String(255))
    question = Column(Text)
    api_code = Column(String(255))
    answer = Column(Text, nullable=False)
    org_no = Column(String(16), nullable=False)
    rating = Column(Integer, CheckConstraint('rating >= 1 AND rating <= 5 OR rating IS NULL'), nullable=True)
    timestamp = Column(TIMESTAMP(timezone=True), server_default=func.now())
    vector_duration = Column(Float)
    llm_duration = Column(Float)


# todo delete
class MiopModuleDesc(Base):
    __table_name__ = 'miop_module_desc'
    subject = Column(Text)
    page = Column(Text)
    ability = Column(Text)
    embed_search = Column(Text)
    detail_data = Column(Text)
    card_key = Column(Text, primary_key=True)

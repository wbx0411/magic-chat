import importlib
from abc import abstractmethod, ABC

from biz.tools import RTN_TYPE
from framework.embedding.m3e_client import m3e_client
from transport.db.postgresdb import PostgresDB
from utils.config_utils import SysConfig
from utils.logger_utils import LoggerFactory

"""
1. tool模块定义：路径为biz/tools/{tool_type}.py
2. tool实现类定义：继承自MCTaskTool抽象类，名字为Tool{tool_type}，实现init_data、execute、notify方法
3. tool配置文件：tool/tool.{tool_type}.yaml，配置业务表、字段、历史表等信息
"""

tool_config_prefix = "tool/tool."
tool_module_prefix = "biz.tools."

logger = LoggerFactory.get_logger(__name__)


class ExecResult:
    def __init__(self, value: str, type: str, distance: float = None):
        self.value = value
        self.type = type
        self.distance = distance

    def __str__(self):
        return f"ExecResult({self.type}[{self.distance}]: {self.value})"

    def __repr__(self):
        return f"ExecResult({self.type}[{self.distance}]: {self.value})"

    @classmethod
    def knowledge(cls, value: str, distance: float = None):
        return cls(value=value, type=RTN_TYPE.KNOWLEDGE, distance=distance)

    @classmethod
    def suggestion(cls, value: str, distance: float = None):
        return cls(value=value, type=RTN_TYPE.SUGGESTION, distance=distance)

    @classmethod
    def empty(cls):
        return cls(value="", type=RTN_TYPE.NONE)


class BaseTool(ABC):
    db = PostgresDB('postgres_rag')

    def __init__(self, config: dict, chat_chain=None):
        """工具初始化
        Args:
            config: tool配置
            chat_chain: chat_chain的实例
        """
        assert "tool_code" in config, "tool_code is required in config"
        self.tool_code = config["tool_code"]
        # 加载tool配置
        try:
            self.configs = SysConfig.get_yaml_config(f"{tool_config_prefix}{self.tool_code}")
        except Exception:
            # 捕获配置文件不存在的异常
            self.configs = {}
        # 关联chat_chain
        self.chat_chain = chat_chain
        # 加载chat_config
        self.configs.update({**chat_chain.configs} if chat_chain else {})
        # 加载knowledge_sources
        self.configs.update(config)

    def register(self, **kwargs):
        assert (tool_id := self.configs.get('tool_id')), "tool_id is required"
        assert (tool_code := self.configs.get('tool_code')), "tool_code is required"
        assert (tool_type := self.configs.get('tool_type')), "tool_type is required"
        assert (tool_name := self.configs.get('tool_name')), "tool_name is required"

        tool_desc = self.configs.get('tool_desc', '')
        result = self.db.execute(
            """
            insert into ai_tools_embedding (
                tool_id, tool_code, tool_type, tool_name, tool_desc, 
                prompt_prefix, prompt_suffix, embedding, modify_time
            ) values (
                %s, %s, %s, %s, %s, 
                %s, %s, %s::vector, CURRENT_TIMESTAMP
            )
            """,
            (
                tool_id,
                tool_code,
                tool_type,
                tool_name,
                tool_desc,
                self.configs.get('prompt_prefix', ''),
                self.configs.get('prompt_suffix', ''),
                m3e_embedding(f"{self.configs['tool_name']} {tool_desc}"),
            ),
        )
        logger.info(f"Tool register success: {tool_id=}, {result=}")

    def unregister(self, **kwargs):
        assert 'tool_id' in self.configs, "tool_id is required"

        result = self.db.execute(
            "delete from ai_tools_embedding where tool_id = %s",
            (tool_id := self.configs['tool_id'],),
        )
        logger.info(f"Tool unregister success: {tool_id=}, {result=}")

    @abstractmethod
    def execute(self, **kwargs) -> ExecResult:
        pass

    def find_tool(self, tool_id: str) -> dict:
        tool = self.db.query(
            """
            select tool_id, tool_type, tool_name, tool_desc, prompt_prefix, prompt_suffix
              from ai_tools_embedding
             where tool_id = %s
            """,
            (tool_id,),
        )
        assert tool, f"tool not found: {tool_id}"
        return tool[0]

    def format_prompt(self, tool_id: str, prompt: str) -> str:
        tool = self.find_tool(tool_id)
        return f"{tool.get('prompt_prefix', '')} {prompt} {tool.get('prompt_suffix', '')}"


def get_tool(config: dict, chat_chain=None) -> BaseTool:
    """
    获取tool实例
    :param config: tool配置
        tool_code: tool编码，可以用"."区分不同的模块，如"de.api_fetch"
    :return tool实例
    """
    try:
        assert "tool_code" in config, "tool_code is required in config"
        module = importlib.import_module(f"{tool_module_prefix}{config['tool_code']}")
        tools = [
            clz
            for clz in module.__dict__.values()
            if isinstance(clz, type) and issubclass(clz, BaseTool) and clz is not BaseTool
        ]
        assert len(tools) == 1, f"tool class not found in module: {module}"
        return tools[0](config, chat_chain)
    except Exception as e:
        raise Exception(f"Failed to get tool instance: {e}")


def m3e_embedding(text: str, m3e_model_name='m3e-small') -> list[float]:
    embedding_response = m3e_client.get_embeddings(
        text,
        m3e_model_name,
    )
    return embedding_response['data'][0]['embedding']


def register(tool_config: dict):
    get_tool(tool_config).register()


def unregister(tool_config: dict):
    get_tool(tool_config).unregister()


async def name_match(input_msg: str, chat_chain) -> list:
    """名称匹配
    :param input_msg: 输入消息
    :param chat_chain: chat_chain实例
    """
    result = []
    try:
        logger.info(f"Start to name_match")
        tool_ids = chat_chain.configs.get("knowledge_sources").get("name_match", [])
        if not isinstance(tool_ids, list):
            raise ValueError("name_match tool_ids must be a list")
        if tool_ids == []:
            logger.info("No tool_ids found in name_match")
            return []

        top_k = chat_chain.configs.get("top_k", 3)
        distance = chat_chain.configs.get("distance_threshold", 15)
        # 获取输入消息的embedding
        embedding = m3e_embedding(input_msg)
        # 查询最相似的API
        tools = BaseTool.db.query(
            """
            select tool_id, tool_code, tool_name, tool_desc, 
                   prompt_prefix, prompt_suffix, 
                   embedding <-> %s::vector AS distance 
              from ai_tools_embedding
             where tool_id = ANY(%s)
               and tool_type = 'name_match'
             order by embedding <-> %s::vector
             limit %s
            """,
            (embedding, tool_ids, embedding, top_k),
        )
        logger.info(f"Find tools: {[(tool['tool_name'], tool['distance']) for tool in tools]}")
        tools = [tool for tool in tools if tool.get("distance") < distance]
        logger.info(f"Filter tools: {[(tool['tool_name'], tool['distance']) for tool in tools]}")

        should_break = False
        for tool in tools:
            res = await get_tool(tool, chat_chain).execute(input_msg=input_msg)
            res = res if isinstance(res, list) else [res]
            res = [r for r in res if r.type != RTN_TYPE.NONE]
            for r in res:
                if r.type != RTN_TYPE.KNOWLEDGE:
                    # 如果不是knowledge且是第一个工具，则不在继续查找
                    if len(result) == 0:
                        result.append(r)
                        should_break = True
                        break
                    # 如果不是knowledge且不是第一个工具，则忽略
                    else:
                        continue
                else:
                    result.append(r)
            if should_break:
                break

        # 推荐
        if len(tools) > 1:
            result.append(
                ExecResult([tool['tool_name'] for tool in tools[1:]], RTN_TYPE.SUGGESTION)
            )
    except Exception as e:
        logger.error(f"Failed to name_match: {e}")
    logger.info(f"End to name_match: {result}")
    return result


async def content_match(input_msg: str, chat_chain):
    logger.info(f"Start to content_match")
    result = []
    try:
        tool_ids = chat_chain.configs.get("knowledge_sources").get("content_match")
        if not tool_ids:
            logger.info("No tool_ids found in content_match")
            return []
        if not isinstance(tool_ids, list):
            raise ValueError("content_match tool_ids must be a list")
        # 查询最相似的API
        tools = BaseTool.db.query(
            """
            select tool_id, tool_code, tool_name, tool_desc, prompt_prefix, prompt_suffix
              from ai_tools_embedding
             where tool_id = ANY(%s)
               and tool_type = 'content_match'
            """,
            (tool_ids,),
        )
        for tool in tools:
            res = await get_tool(tool, chat_chain).execute(input_msg=input_msg)
            res = res if isinstance(res, list) else [res]
            result.extend([r for r in res if r.type != RTN_TYPE.NONE])
    except Exception as e:
        logger.error(f"Failed to content_match: {e}")
    logger.info(f"End to content_match: {result}")
    return result

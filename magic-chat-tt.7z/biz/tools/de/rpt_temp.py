import os
from biz.tools import RTN_TYPE
from biz.tools.tool_manager import BaseTool, ExecResult
from utils import file_handler_utils
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)


class RptTemp(BaseTool):
    """【报表模板】工具
    此工具通过匹配报表模板的关键词，获取对应的报表模板
    获取的数据作为大模型的提示词，用于后续的对话生成
    """

    def __init__(self, config, chat_chain=None):
        super().__init__(config, chat_chain)

    def register(self):
        logger.info(f"RptTemp register: {self.configs}")

        assert (tool_params := self.configs.get('tool_params')), "tool_params is required"
        assert (file_path := (tool_params.get('file_path'))), "file_path is required"
        assert (file_name := tool_params.get('file_name')), "file_name is required"

        super().register()
        try:
            # 注册API
            result = self.db.execute(
                """
                insert into ai_tools_de_rpt_temp (tool_id, file_path, file_name, file_content)
                values (%s, %s, %s, %s)
                """,
                (
                    self.configs['tool_id'],
                    file_path,
                    file_name,
                    file_handler_utils.file_reader(os.path.join(file_path, file_name)),
                ),
            )
            logger.info(f"RptTemp register success: {self.configs['tool_id']}, {result=}")
        except Exception as e:
            super().unregister()
            raise e

    def unregister(self):
        super().unregister()

        result = self.db.execute(
            "delete from ai_tools_de_rpt_temp where tool_id = %s",
            (self.configs['tool_id'],),
        )
        logger.info(f"RptTemp unregister success: {self.configs['tool_id']}, {result=}")

    async def execute(self, **kwargs):
        result = self.db.query(
            "select file_content from ai_tools_de_rpt_temp where tool_id = %s",
            (tool_id := self.configs['tool_id'],),
        )
        if not result:
            return ExecResult.empty()
        return ExecResult.knowledge(super().format_prompt(tool_id, result[0]['file_content']))

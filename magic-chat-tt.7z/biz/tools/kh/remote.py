from biz.tools.tool_manager import BaseTool, ExecResult, m3e_embedding
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)

KH_TYPE = "remote"


class Remote(BaseTool):
    async def execute(self, **kwargs):
        logger.info(f"Remote execute: {kwargs}")
        input_emb = m3e_embedding(kwargs['input_msg'])

        order_col = ["kh_name_emb", "kh_desc_emb", "kh_name_desc_emb"]
        results = []
        for col in order_col:
            rs = self.db.query(
                f"""
                select kh_name, kh_desc, kh_content, 
                       {col} <-> %s::vector AS distance, '{col}' as col_name 
                  from ai_tool_kh 
                 where kh_type = %s
                 order by {col} <-> %s::vector
                 limit %s
                """,
                (
                    input_emb,
                    KH_TYPE,
                    input_emb,
                    top_k := self.chat_chain.configs.get("top_k", 3),
                ),
            )
            results.extend(rs)
        results.sort(key=lambda x: x["distance"])
        results = results[:top_k]
        logger.info("Find Remote: %s", [result.values() for result in results])
        return ExecResult(
            [
                {
                    "name": result["kh_name"],
                    "desc": result["kh_desc"],
                    "content": result["kh_content"],
                    "distance": result["distance"],
                    "col_name": result["col_name"],
                }
                for result in results
            ],
            self.configs['tool_code'],
        )

from typing import Union

from psycopg2 import pool, extras

from transport.db.basedb import BaseDB
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)


class PostgresDB(BaseDB):

    def __init__(self, config=None):
        super().__init__(config)

        self.pg_pool = pool.SimpleConnectionPool(
            minconn=self.config.get('min_conn') or 2,
            maxconn=self.config.get('max_conn') or 10,
            host=self.config['host'],
            port=self.config['port'],
            user=self.config['user'],
            password=self.config['password'],
            database=self.config['database'],
            keepalives=self.config.get('keepalives') or 1,
            keepalives_idle=self.config.get('keepalives_idle') or 30,
            keepalives_interval=self.config.get('keepalives_interval') or 10,
            keepalives_count=self.config.get('keepalives_count') or 5,
            client_encoding=self.config.get('encoding') or 'utf8',
            sslmode='disable',
        )

    def query(
        self,
        statement: str,
        parameters: Union[list, tuple, dict] = None,
        **keyword_parameters: dict,
    ):
        conn, cursor = None, None
        try:
            conn = self.pg_pool.getconn()
            cursor = conn.cursor(cursor_factory=extras.RealDictCursor)
            logger.debug(f"Executing query: {statement=}, {parameters=}, {keyword_parameters=}")
            cursor.execute(statement, parameters, **keyword_parameters)
            result = cursor.fetchall()
            logger.debug(f"Query result: {result}")
            return result
        except Exception as e:
            logger.error(f"postgresql select error: ", exc_info=True)
            raise e
        finally:
            if cursor:
                cursor.close()
            if conn:
                self.pg_pool.putconn(conn)

    def execute(
        self,
        statement: str,
        parameters: Union[list, tuple, dict] = None,
        **keyword_parameters: dict,
    ):
        conn, cursor = None, None
        try:
            conn = self.pg_pool.getconn()
            cursor = conn.cursor()
            logger.debug(f"Executing execute: {statement=}, {parameters=}, {keyword_parameters=}")
            cursor.execute(statement, parameters, **keyword_parameters)
            conn.commit()
            return cursor.rowcount
        except Exception as e:
            if conn is not None:
                conn.rollback()
            logger.error(f"postgresql execute error: ", exc_info=True)
            raise e
        finally:
            if cursor:
                cursor.close()
            if conn:
                self.pg_pool.putconn(conn)

    def execute_batch(self, command: list[(str, Union[list, tuple, dict])]):
        conn, cursor = None, None
        rowcount = 0
        try:
            conn = self.pg_pool.getconn()
            cursor = conn.cursor()
            for statement, parameters in command:
                logger.debug(f"Executing batch statement: {statement}, params: {parameters}")
                cursor.execute(statement, parameters)
                rowcount += cursor.rowcount
            conn.commit()
            return rowcount
        except Exception as e:
            if conn is not None:
                conn.rollback()
            logger.error(f"postgresql execute batch error: ", exc_info=True)
            raise e
        finally:
            if cursor:
                cursor.close()
            if conn:
                self.pg_pool.putconn(conn)


if __name__ == '__main__':
    db = PostgresDB("postgres_qin")
    print(db.query("select * from qin_chat_records"))

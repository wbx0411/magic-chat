import os

from biz.zhihu.database import Database
from biz.zhihu.models import DocEmbeddingEntity
from framework.embedding.m3e_client import m3e_client
from framework.rag.chunking import preprocess_text, semantic_chunking
from utils.file_handler_utils import contains_chinese_uppercase_number, file_reader
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)


def remove_rules(tool_id):
    session = Database().get_session()
    # 删除tool_id的记录
    session.query(DocEmbeddingEntity).filter(DocEmbeddingEntity.tool_id == tool_id).delete()
    session.commit()


def insert_rules(cat1, cat2, cat3, cat4, content, file_path='', tool_id=''):
    note = cat1 + '-' + cat2 + '-' + cat3 + '-' + cat4
    # print(f"Inserting rule: {cat2}, {cat3}, {content}")
    try:
        content_emb_response = m3e_client.get_embeddings([content])
        note_emb_response = m3e_client.get_embeddings([note])
        content_note_emb_response = m3e_client.get_embeddings([note + ' ' + content])
        content_vector = content_emb_response['data'][0]['embedding']
        note_vector = note_emb_response['data'][0]['embedding']
        note_content_vector = content_note_emb_response['data'][0]['embedding']
    except Exception as e:
        logger.error(f"An error occurred while embedding: {e}")
        raise e

    try:
        session = Database().get_session()
        # 插入新记录
        session.add(
            DocEmbeddingEntity(
                tool_id=tool_id,
                cat1=cat1,
                cat2=cat2,
                cat3=cat3,
                cat4=cat4,
                content=content,
                note=note,
                content_note=content + note,
                content_emb=content_vector,
                note_emb=note_vector,
                content_note_emb=note_content_vector,
                attach_path=os.path.dirname(file_path),
                title=os.path.basename(file_path),
            )
        )
        session.commit()
    except Exception as e:
        logger.error(f"An error occurred while inserting rule: {e}")
        raise e

    return "success"


def batch_insert_rules(notes, contents, file_path='', tool_id=''):
    try:
        session = Database().get_session()
        notes_emb_res = m3e_client.get_embeddings(notes)
        contents_emb_res = m3e_client.get_embeddings(contents)
        content_note_emb_res = m3e_client.get_embeddings(
            [content + " " + note for note, content in zip(notes, contents)]
        )
        assert (
            notes_emb_res
            and contents_emb_res
            and content_note_emb_res
            and len(notes)
            == len(contents)
            == len(notes_emb_res['data'])
            == len(contents_emb_res['data'])
            == len(content_note_emb_res['data'])
        ), (
            f"Length of notes, contents and embeddings should be the same: "
            f"{len(notes)=}, {len(contents)=}, {len(notes_emb_res['data'])=}, {len(contents_emb_res['data'])=}, {len(content_note_emb_res['data'])=}"
        )
        for note, content, note_emb, content_emb, content_note_emb in zip(
            notes,
            contents,
            notes_emb_res['data'],
            contents_emb_res['data'],
            content_note_emb_res['data'],
        ):
            session.add(
                DocEmbeddingEntity(
                    tool_id=tool_id,
                    content=content,
                    note=note,
                    content_note=content + note,
                    content_emb=content_emb['embedding'],
                    note_emb=note_emb['embedding'],
                    content_note_emb=content_note_emb['embedding'],
                    attach_path=os.path.dirname(file_path),
                    title=os.path.basename(file_path),
                )
            )
        session.commit()
        logger.info(f"Batch insert rules success: {file_path=}, {len(notes)=}")
    except Exception as e:
        logger.error(f"An error occurred while embedding: {e}")
        raise e
    return "success"


def insert_img(cat1, content, attach_path):
    session = Database().get_session()
    note = cat1
    try:
        content_emb_response = m3e_client.get_embeddings([content])
        note_emb_response = m3e_client.get_embeddings([note])
        content_note_emb_response = m3e_client.get_embeddings([note + ' ' + content])
        content_vector = content_emb_response['data'][0]['embedding']
        note_vector = note_emb_response['data'][0]['embedding']
        note_content_vector = content_note_emb_response['data'][0]['embedding']
    except Exception as e:
        print(f"An error occurred while embedding: {e}")

    try:
        rule = DocEmbeddingEntity(
            cat1=cat1,
            content=content,
            note=note,
            content_note=content + note,
            content_emb=content_vector,
            note_emb=note_vector,
            content_note_emb=note_content_vector,
            attach_path=attach_path,
        )

        session.add(rule)
        session.commit()
    except Exception as e:
        logger.error(f"An error occurred while inserting rule: {e}")
        raise e

    return "success"


def handle_chunk(file_path, file_name, tool_id='', chunk_size=512, chunk_overlap=50, **kwargs):
    """
    对文件进行进行无格式分块处理
    1. 读取文件内容
    2. 对文件内容进行预处理，文本清洗与标准化
    3. 对文件内容进行分块处理
    4. 对分块后的内容进行插入
    :param file_path: 文件路径
    :param file_name: 文件名
    :param tool_id: 工具ID
    :param chunk_size: 分块大小
    :param chunk_overlap: 分块重叠大小
    :param kwargs: 其他参数
    :return: 插入结果
    """
    full_path = os.path.join(file_path, file_name)
    file_content = file_reader(full_path)
    note = file_name.split('.')[0]
    file_content = [preprocess_text(" ".join(file_content))]
    chunks = [
        chunk
        for content in file_content
        for chunk in semantic_chunking(content, chunk_size=chunk_size, overlap=chunk_overlap)
    ]
    notes = [note] * len(chunks)
    return batch_insert_rules(notes, chunks, full_path, tool_id)


def handle_paragraph(file_path, file_name, tool_id='', **kwargs):
    """
    对带格式的文本，主要针对docx文件进行段落处理
    1. 读取文件内容，按照段落进行分割
    2. 对文件内容进行预处理，文本清洗与标准化
    3. 对文件内容进行插入
    :param file_path: 文件路径
    :param file_name: 文件名
    :param tool_id: 工具ID
    :param kwargs: 其他参数
    """
    full_path = os.path.join(file_path, file_name)
    file_content = file_reader(full_path)
    note = file_name.split('.')[0]
    contents = [preprocess_text(content) for content in file_content]
    return batch_insert_rules([note] * len(contents), contents, full_path, tool_id)


def handle_qa(file_path, file_name, tool_id='', **kwargs):
    """
    对于问答格式的文本进行处理
    1. 读取文件内容，按照问答进行分割
    2. 对文件内容进行预处理，文本清洗与标准化
    3. 对文件内容进行插入

    文档格式：
    标题
    1. xxx
    答: xxx
    2 . xxx
    答: xxx

    :param file_path: 文件路径
    :param file_name: 文件名
    :param tool_id: 工具ID
    :param kwargs: 其他参数
    """
    full_path = os.path.join(file_path, file_name)
    file_content = file_reader(full_path)

    note = file_content.pop(0).strip()

    answer = ""
    question = ''
    contents = []

    for content in file_content:
        if (content[0].isdigit() and content[1] == '.') or (
            content[0].isdigit() and content[2] == '.'
        ):
            contents.append(question + " " + answer)
            question = content
            answer = ""
        elif content.startswith('答'):
            answer = content
        else:
            if question:
                question += content
            else:
                answer += content
    return batch_insert_rules([note] * len(contents), contents, full_path, tool_id)


def save_doc_services_1(file_path, tool_id=''):
    """
    inform
    inform
    """
    file_content = file_reader(file_path)

    cat1 = file_content[0].strip()
    file_content.pop(0)

    contents = []
    notes = []
    for content in file_content:
        contents.append(content.strip())
        notes.append(cat1)
    return batch_insert_rules(notes, contents, file_path, tool_id)


def save_doc_services_3(file_path, tool_id=''):
    """
    X、
    (x)
    """
    file_content = file_reader(file_path)

    cat1 = file_content[0].strip()
    file_content.pop(0)
    cat2, cat3, cat4 = '', '', ''

    for content in file_content:
        if contains_chinese_uppercase_number(content[0]) and content[1] == '、':
            cat2 = content
            cat3 = ''
        elif content.startswith(('(', '（')) and contains_chinese_uppercase_number(content[1]):
            if len(content) < 30:
                cat3 = content
            else:
                insert_rules(cat1, cat2, cat3, cat4, content, file_path, tool_id)
        else:
            insert_rules(cat1, cat2, cat3, cat4, content, file_path, tool_id)


def save_doc_services_4(file_path, tool_id=''):
    """
    电价表
    注：
    """
    file_content = file_reader(file_path)

    cat1 = '省级电网输配电价表'
    cat2, cat3, cat4 = '', '', ''

    for content in file_content:
        if content.endswith('电价表'):
            cat2 = content
        else:
            insert_rules(cat1, cat2, cat3, cat4, content, file_path, tool_id)


def save_doc_services_5(file_path, tool_id=''):
    """
    第x章
        第x节
        第x条
    """
    file_content = file_reader(file_path)

    cat1 = file_content[0].strip()
    file_content.pop(0)
    cat2, cat3, cat4 = '', '', ''

    temp = ''
    for content in file_content:
        if content.startswith('第') and (content[2] == '章' or content[3] == '章'):
            if temp:
                insert_rules(cat1, cat2, cat3, cat4, temp, file_path, tool_id)
            temp = ''
            cat2 = content
            cat3 = ''
        elif content.startswith('第') and content[2] == '节':
            if temp:
                insert_rules(cat1, cat2, cat3, cat4, temp, file_path, tool_id)
            temp = ''
            cat3 = content
        elif content.startswith('第') and '条' in content[:7]:
            if temp:
                insert_rules(cat1, cat2, cat3, cat4, temp, file_path, tool_id)
            temp = content
        else:
            temp += content
    if temp:
        insert_rules(tool_id, cat1, cat2, cat3, cat4, temp, file_path, tool_id)


def save_img_service(img_path):
    """
    save img
    """
    cat1 = img_path.split('.')[1].split('/')[-1]
    content = cat1
    insert_img(cat1, content, img_path)


def support_doc_type():
    import sys

    m = sys.modules[__name__]
    return [(func[7:], getattr(m, func).__doc__) for func in dir(m) if func.startswith('handle_')]


if __name__ == '__main__':
    for name, doc in support_doc_type():
        print(f"{name}: {doc}")

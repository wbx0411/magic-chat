import os
from openai import OpenAI


client = OpenAI(
    api_key="***",
    base_url="http://10.4.57.222:21434/v1",
)

response = client.chat.completions.create(
    model="deepseek-r1:32b",
    messages=[
        {"role": "system", "content": "You are a helpful assistant"},
        {"role": "user", "content": "Hello"},
    ],
    stream=False,
)

print(response.choices[0].message.content)

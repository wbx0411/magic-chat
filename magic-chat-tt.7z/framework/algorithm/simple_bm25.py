import math
import os
from collections import Counter
from collections.abc import Iterable

import jieba

from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)

current_dir = os.path.dirname(os.path.abspath(__file__))
config_dir = os.path.join(current_dir, '../../configs', "jieba_dict.txt")
jieba.load_userdict(config_dir)


class SimpleBM25:
    def __init__(self):
        self.idf = None
        self.df = None
        self.avgdl = None
        self.dl = None
        self.N = None
        self.corpus = None
        self.docs = None

    def set_docs(self, documents: Iterable, field: str | int, cut_all=True):
        self.docs = documents
        self.corpus = [jieba.lcut(doc[field], cut_all=cut_all) for doc in self.docs]
        self.N = len(self.corpus)
        self.dl = [len(doc) for doc in self.corpus]
        self.avgdl = sum(self.dl) / self.N if self.N else 0
        self.df = {}
        self.idf = {}
        # 计算文档频率
        for doc in self.corpus:
            for word in set(doc):
                self.df[word] = self.df.get(word, 0) + 1
        # 计算IDF
        for word, freq in self.df.items():
            self.idf[word] = math.log((self.N - freq + 0.5) / (freq + 0.5) + 1)

    def query(
        self,
        documents: Iterable,
        query_str: str,
        num_best: int = 1,
        field: str | int = "name",
        min_score: float = 0,
        log_level: str = "info",
        cut_all=True,
    ):
        """
        bm25匹配检索
        :param documents: 可迭代对象
        :param query_str: 匹配字符串
        :param num_best: 返回的最佳匹配数
        :param field: 匹配字段：如果documents是字典列表，则为字典的键；如果documents是元组列表，则为元组的索引
        :param min_score: 最低匹配分数
        :param log_level: 日志级别
        :param cut_all: 是否全模式分词
        """
        self.set_docs(documents, field)
        # 使用此方式会对本地字典进行二次分词
        query = jieba.lcut(query_str, cut_all=cut_all)
        scores = []
        for index, doc in enumerate(self.corpus):
            score = self.get_score(doc, query)
            if score < min_score:
                continue
            scores.append((self.docs[index], score))
        scores.sort(key=lambda x: x[1], reverse=True)
        getattr(logger, log_level)(f"BM25 Sort: {query_str} in {self.docs[:3]} -> {scores[:3]}")
        return [doc for doc, _ in scores[:num_best]]

    def get_scores_separate(
        self, documents: Iterable, query_str: str, field: str | int = "name", cut_all=True
    ):
        # 每个文档单独评分，如果放到一起作为语料，则分组间的评分标准不一致
        query = jieba.lcut(query_str, cut_all=cut_all)
        scores = []
        for doc in documents:
            self.set_docs([doc], field)
            for index, doc in enumerate(self.corpus):
                score = self.get_score(doc, query)
                scores.append((self.docs[index], score))
        scores.sort(key=lambda x: x[1], reverse=True)
        logger.info(f"BM25 Sort: {query_str} in {self.docs[:3]} -> {scores[:3]}")
        return scores

    def get_score(self, doc, query):
        score = 0
        doc_counter = Counter(doc)
        for word in query:
            if word in doc_counter:
                tf = doc_counter[word]
                idf = self.idf.get(word, 0)
                score += (idf * tf * 2.2) / (tf + 1.2 * (0.25 + 0.75 * len(doc) / self.avgdl))
        return score


# 示例
if __name__ == "__main__":
    bm25 = SimpleBM25()

    # docs = [{"value": "用户平均停电时长."}, {"value": "台区平均停电时长."}, {"value": "用户平均停电次数."}]
    # q = "国网陕西省电力公司2024年8月的用户平均停电时长是多少"
    # result = bm25.query(docs, q, 3, 'value')
    # print(result)
    #
    # docs = [(1, "这是一个测试文档。"), (2, "这是另一个测试文档，包含更多的测试词汇。")]
    # q = "测试文档"
    # result = SimpleBM25().query(docs, q, 3, 1)
    # print(result)

    # docs = [(1, "法库站"), (2, "法库")]
    # q = "法库本年应收电费"
    # result = SimpleBM25().query(docs, q, 3, 1, 0.1)
    # print(result)

    # docs = [(1, "沈阳"), (2, "大连"), (3, "法库"), (4, "法库法库站")]
    # q = "法库县本年应收电费"
    # result = SimpleBM25().query(docs, q, 3, 1, 0.1)
    # print(result)

    docs = [{"name": "沈阳客户服务中心"}, {"name": "大连客户服务中心"}]
    q = "大连客户服务中心本年应收电费"
    result = SimpleBM25().get_scores_separate(docs, q)
    print(result)

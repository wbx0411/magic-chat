import os
from typing import Union

import oracledb

from transport.db.basedb import BaseDB
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)

oracle_home = os.getenv('ORACLE_HOME', '/app/instantclient_11_2')


class OracleDB(BaseDB):

    def __init__(
            self,
            config=None,
            min_pool_size=None,
            max_pool_size=None,
            increment=None
    ):
        super().__init__(config)

        oracledb.init_oracle_client(lib_dir=oracle_home)
        self.pool = oracledb.create_pool(
            user=self.config['user'],
            password=self.config['password'],
            dsn=f"{self.config['host']}:{self.config['port']}/{self.config['service_name']}",
            min=min_pool_size or (self.config.get('min_pool_size') and int(self.config['min_pool_size'])) or 1,
            max=max_pool_size or (self.config.get('max_pool_size') and int(self.config['max_pool_size'])) or 10,
            increment=increment or (self.config.get('increment') and int(self.config['increment'])) or 1
        )

    def get_connection(self):
        return self.pool.acquire()

    def release_connection(self, connection):
        self.pool.release(connection)

    def query(self, statement: str, parameters: Union[list, tuple, dict] = None, **keyword_parameters: dict):
        cursor = None
        connection = self.get_connection()
        try:
            cursor = connection.cursor()
            logger.debug(
                f"Executing query: {statement}, "
                f"params: {parameters}, "
                f"keyword_params: {keyword_parameters}"
            )
            cursor.execute(statement, parameters, **keyword_parameters)
            columns = [col[0] for col in cursor.description]
            rows = cursor.fetchall()
            result = [dict(zip(columns, row)) for row in rows]
            logger.debug(f"Query result: {result}")
            return result
        except Exception as e:
            logger.error(f"oracle select error: ", exc_info=True)
            raise e
        finally:
            if cursor:
                cursor.close()
            if connection:
                self.release_connection(connection)

    def execute(self, statement: str, parameters: Union[list, tuple, dict] = None, **keyword_parameters: dict):
        cursor = None
        connection = self.get_connection()
        try:
            cursor = connection.cursor()
            logger.debug(
                f"Executing statement: {statement}, "
                f"params: {parameters}, "
                f"keyword_params: {keyword_parameters}"
            )
            cursor.execute(statement, parameters, **keyword_parameters)
            connection.commit()
            return cursor.rowcount
        except Exception as e:
            if connection:
                connection.rollback()
            logger.error(f"oracle execute error: ", exc_info=True)
            raise e
        finally:
            if cursor:
                cursor.close()
            if connection:
                self.release_connection(connection)

    def execute_batch(self, command: list[(str, Union[list, tuple, dict])]):
        cursor = None
        connection = self.get_connection()
        rowcount = 0
        try:
            cursor = connection.cursor()
            for statement, parameters in command:
                logger.debug(f"Executing batch statement: {statement}, params: {parameters}")
                cursor.execute(statement, parameters)
                rowcount += cursor.rowcount
            connection.commit()
            return rowcount
        except Exception as e:
            if connection:
                connection.rollback()
            logger.error(f"oracle execute batch error: ", exc_info=True)
            raise e
        finally:
            if cursor:
                cursor.close()
            if connection:
                self.release_connection(connection)

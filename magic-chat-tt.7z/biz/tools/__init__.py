from enum import Enum


class RTN_TYPE(Enum):
    NONE = "none"  # 无返回值
    KNOWLEDGE = "knowledge"  # 知识
    SUGGESTION = "suggestion"  # 建议

    def __str__(self):
        return self.value

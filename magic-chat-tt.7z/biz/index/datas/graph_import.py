
from ..metadata import *
from framework.embedding.m3e_client import m3e_client
from transport.db.neo4jdb import Neo4jDB
from utils.config_utils import SysConfig
from utils.logger_utils import LoggerFactory

configs = SysConfig.get_config()
logger = LoggerFactory.get_logger(__name__)

neo4j = Neo4jDB()


# 创建索引，目前只针对指标和供电单位建立索引，后续根据需求（标签）建立
def create_graph_index(ns):
    index_name = neo4j.get_index_name(idx_vec_pre, ns, label_idx)
    neo4j.create_index_vector(index_name, 'vector', 512, 'cosine', label_idx)
    logger.info(f"create graph index {index_name} to the database.")
    index_name = neo4j.get_index_name(idx_vec_pre, ns, label_org)
    neo4j.create_index_vector(index_name, 'vector', 512, 'cosine', label_org)
    logger.info(f"create graph index {index_name} to the database.")
    index_name = neo4j.get_index_name(idx_fts_pre, ns, label_org)
    neo4j.create_index_fts(index_name, label_org, ['name'])
    logger.info(f"create graph index {index_name} to the database.")


def clear_graph(ns):
    cypher = f'match (n:{ns}) detach delete n'
    neo4j.run(cypher)
    logger.info(f"clear graphdb {ns}.")


def node_embedding(ns, label=None):
    logger.info(f"Start to embed nodes in {ns} with label {label}.")
    if label:
        nodes = neo4j.match_nodes(ns, label)
    else:
        nodes = neo4j.match_nodes(ns)
    name_list = [node['name'] for node in nodes]
    embedding_texts = m3e_client.get_embeddings(name_list, configs['m3e_model_name'])
    embedding_texts = [embedding['embedding'] for embedding in embedding_texts['data']]

    for i, node in enumerate(nodes):
        neo4j.update_node(node, vector=embedding_texts[i])
        if i != 0 and (i % 100 == 0 or i == len(nodes) - 1):
            logger.info(f"{i} node embedding to the database.")


if __name__ == '__main__':
    _namespace = configs['neo4j_config']['namespace']
    create_graph_index(_namespace)
    # node_embedding(_namespace)

import torch
from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments
from datasets import load_dataset

# 加载数据集（这里以情感分析为例）
dataset = load_dataset('imdb')

# 加载预训练的BERT分词器和模型
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertForSequenceClassification.from_pretrained('bert-base-uncased', num_labels=2)


# 数据预处理函数
def preprocess_function(examples):
    return tokenizer(examples['text'], padding='max_length', truncation=True, max_length=512)


# 对整个数据集进行预处理
encoded_dataset = dataset.map(preprocess_function, batched=True)

# 设置PyTorch格式的数据集
train_dataset = (
    encoded_dataset['train'].shuffle(seed=42).select(range(1000))
)  # 只用一部分数据作为示例
test_dataset = encoded_dataset['test'].shuffle(seed=42).select(range(1000))

# 定义训练参数
training_args = TrainingArguments(
    output_dir='./results',
    evaluation_strategy="epoch",
    learning_rate=2e-5,
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    num_train_epochs=3,
    weight_decay=0.01,
)

# 使用Trainer API简化训练过程
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=test_dataset,
)

# 开始训练
trainer.train()

# 评估模型
eval_results = trainer.evaluate()
print(f"Evaluation results: {eval_results}")

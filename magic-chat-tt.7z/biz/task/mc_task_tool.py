import importlib
from abc import abstractmethod, ABC

from utils.config_utils import SysConfig

"""
1. tool模块定义：路径为biz/task/tool_{tool_type}.py
2. tool实现类定义：继承自MCTaskTool抽象类，名字为Tool{tool_type}，实现init_data、execute、notify方法
3. tool配置文件：tool/tool.{tool_type}.yaml，配置业务表、字段、历史表等信息
"""

tool_config_prefix = "tool/tool."
tool_module_prefix = "biz.task.tool_"
tool_class_prefix = "Tool"


class MCTaskTool(ABC):
    def __init__(self, tool_type: str):
        self.tool_type = tool_type
        self.configs = SysConfig.get_yaml_config(f"{tool_config_prefix}{tool_type}")
        self.biz_table = self.configs["biz_table"]
        self.biz_table_cols = self.configs["biz_table_cols"]
        self.biz_col_id = self.configs["biz_col_id"]
        self.biz_col_question = self.configs["biz_col_question"]

    def get_biz_meta(self):
        return (
            self.biz_table,
            self.biz_col_id,
            self.biz_col_question
        )

    @abstractmethod
    def init_data(self, **kwargs):
        pass

    @abstractmethod
    def execute(self, task_detail: dict):
        pass

    @abstractmethod
    def notify(self, task_info: dict):
        pass


tool_cache = {}


def get_mc_task_tool(tool_type: str) -> MCTaskTool:
    try:
        if tool_type not in tool_cache:
            module = importlib.import_module(f"{tool_module_prefix}{tool_type}")
            tool = getattr(module, f"{tool_class_prefix}{tool_type}")
            tool_cache[tool_type] = tool(tool_type)
        return tool_cache[tool_type]
    except Exception as e:
        raise ValueError(f"Failed to get tool: {tool_type}, exc: {str(e)}")

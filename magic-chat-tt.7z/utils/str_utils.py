import os
import re

current_dir = os.path.dirname(__file__)


def text_wash(text):
    """
    根据text_wash.txt文件中的文本内容，对text文本进行清洗
    """
    with open(f'{current_dir}/../configs/text_wash.txt', 'r', encoding='utf-8') as f:
        wash_text = [line.strip() for line in f.readlines() if line.strip() != '']
    for wt in wash_text:
        text = re.sub(wt, '', text)
    return text


if __name__ == '__main__':
    print(text_wash('沈阳市今年的售电量是多少'))
# 停电工单审批
import json

from langchain_core.tools import BaseTool

background_info = """
停电工单审批情况:
审批工单784条
未审批工单共7866条
排名前三的用户如下:
| 户号       | 测算时间            | 余额      |
|------------|---------------------|-----------|
| 8616639281 | 2024-02-21 01:02    | -37483.46 |
| 3168528791 | 2024-02-21 00:05    | -9890.63  |
| 3000345166 | 2024-02-21 00:18    | -8374.43  |
"""


class OutageOrderApproval(BaseTool):
    name = "昨日停电工单审批情况"
    description = """
        获取昨日停电工单审批情况
        """
    return_direct = False

    def __init__(self):
        super().__init__()

    async def _arun(self, cons_no: str) -> str:
        output = {
            "result": f"{background_info}",
            "key": "ooa"
        }
        json_data = json.dumps(output, ensure_ascii=False)
        return json_data

    def _run(self, cons_no: str) -> str:
        pass

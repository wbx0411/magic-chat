from difflib import SequenceMatcher


def longest_common_subsequence(sequence1, sequence2):
    """
    计算并返回两个序列的最长公共子序列（LCS）。

    参数:
    sequence1 (str): 第一个序列。
    sequence2 (str): 第二个序列。

    返回:
    str: 两个序列的最长公共子序列。
    """
    length_seq1 = len(sequence1)
    length_seq2 = len(sequence2)
    dp_table = [[0] * (length_seq2 + 1) for _ in range(length_seq1 + 1)]

    # 构建 DP 表
    for i in range(length_seq1 + 1):
        for j in range(length_seq2 + 1):
            if i == 0 or j == 0:
                dp_table[i][j] = 0
            elif sequence1[i - 1] == sequence2[j - 1]:
                dp_table[i][j] = dp_table[i - 1][j - 1] + 1
            else:
                dp_table[i][j] = max(dp_table[i - 1][j], dp_table[i][j - 1])

    # 回溯 DP 表以找到 LCS
    index = dp_table[length_seq1][length_seq2]
    lcs = [""] * index

    i, j = length_seq1, length_seq2
    while i > 0 and j > 0:
        if sequence1[i - 1] == sequence2[j - 1]:
            lcs[index - 1] = sequence1[i - 1]
            i -= 1
            j -= 1
            index -= 1
        elif dp_table[i - 1][j] > dp_table[i][j - 1]:
            i -= 1
        else:
            j -= 1

    return ''.join(lcs)


def longest_common_substring(str1, str2):
    """
    计算并返回两个字符串的最长公共子串。

    参数:
    str1 (str): 第一个字符串。
    str2 (str): 第二个字符串。

    返回:
    str: 两个字符串的最长公共子串。
    """
    match = SequenceMatcher(None, str1, str2).find_longest_match(0, len(str1), 0, len(str2))
    if match.size != 0:
        return str1[match.a: match.a + match.size]
    else:
        return ""

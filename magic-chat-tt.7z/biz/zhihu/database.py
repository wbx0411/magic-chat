from sqlalchemy import create_engine
from sqlalchemy.engine.url import URL
from sqlalchemy.orm import sessionmaker, scoped_session

from configs import config_loader
from utils.encryptor_utils import SimpleEncryptor

simple_encryptor = SimpleEncryptor()


class Database:
    configs = config_loader.load_config()

    def __init__(self, config=configs[configs['app_db_name']]):
        self.engine = self._create_engine(config)
        self.Session = scoped_session(sessionmaker(bind=self.engine))

    def _create_engine(self, config):
        db_url = URL.create(
            drivername=config['driver'],
            username=config['user'],
            password=(
                simple_encryptor.decrypt(config['password'])
                if config['password'].endswith('=')
                else config['password']
            ),
            host=config['host'],
            port=config['port'],
            database=config['database'],
        )
        engine = create_engine(db_url)
        return engine

    def get_session(self):
        return self.Session()

    def close_session(self):
        self.Session.remove()

    def get_engine(self):
        return self.engine

    def close_engine(self):
        if self.engine:
            self.engine.dispose()  # 关闭引擎的连接池
            self._is_engine_connected = False


# # 使用示例
# db = Database()  # 创建 Database 实例
# session = db.get_session()  # 获取新的会话
# # 进行数据库操作...
# session.close()  # 关闭会话
# db.close_session()  # 关闭当前线程/请求的会话

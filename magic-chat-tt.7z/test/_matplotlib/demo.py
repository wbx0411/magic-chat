import matplotlib.pyplot as plt
import numpy as np
import math

# 设置中文字体，防止中文乱码
plt.rcParams['font.sans-serif'] = ['SimHei']  # 黑体
plt.rcParams['axes.unicode_minus'] = False  # 正常显示负号

# 测试范围
n = np.arange(1, 8)

# 绘制图形
plt.figure(figsize=(10, 6))
plt.plot(n, [1 for i in n], label='常数阶: O(1)', color='black')
plt.plot(n, [math.log2(i) for i in n], label='对数阶: O(log n)', color='green')
plt.plot(n, [i for i in n], label='线性阶: O(n)', color='blue')
plt.plot(n, [math.log2(i) * i for i in n], label='线性对数阶: O(n log n)', color='magenta')
plt.plot(n, [math.pow(i, 2) for i in n], label='平方阶: O(n^2)', color='red')
plt.plot(n, [math.pow(2, i) for i in n], label='指数阶: O(2^n)', color='purple')
plt.plot(n, [math.factorial(i) for i in n], label='阶乘阶: O(n!)', color='brown')

plt.ylim(top=100, bottom=0)  # 设置y轴范围
plt.title('Time Complexity Comparison')
plt.xlabel('Input Size (n)')
plt.ylabel('Operations')
plt.legend()
plt.show()

# 停电执行
import json

from langchain_core.tools import BaseTool

background_info = """
停电执行情况:
停电执行用户有140户，较前日下降51.39%；
停电用户有74户，较前日下降68.64%。
停电成功率为100.00%，
在执行中的用户有66户，停电失败的用户有0户。
| 失败原因TOP3         |
|----------------|
"""


class OutExecutionManager(BaseTool):
    name = "昨日停电执行情况"
    description = """
        获取昨日停电执行情况
        """
    return_direct = False

    def __init__(self):
        super().__init__()

    async def _arun(self, cons_no: str) -> str:
        output = {
            "result": f"{background_info}",
            "key": "oem"
        }
        json_data = json.dumps(output, ensure_ascii=False)
        return json_data

    def _run(self, cons_no: str) -> str:
        pass

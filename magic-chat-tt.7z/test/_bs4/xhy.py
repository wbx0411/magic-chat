# -*- coding: utf-8 -*-

"""

description: 抓取下载歇后语并保存

"""

import requests, json
from bs4 import BeautifulSoup

destination_site = [
    'http://xhy.5156edu.com/html2/xhy.html',
    'http://xhy.5156edu.com/html2/xhy_2.html',
]

# requests增加代理
proxies = {
    'http': r'http://wang-bx:123qwe%21%40%23QWE4@proxy.neusoft.com:8080',
    'https': r'http://wang-bx:123qwe%21%40%23QWE4@proxy.neusoft.com:8080',
}
headers = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36',
}


def downloader(url):
    """
    下载歇后语并保存
    """
    response = requests.get(url, proxies=proxies, headers=headers)
    if response.status_code != 200:
        print(f'{url} is failed!')
        return
    print(f'{url} is parsing')
    html = BeautifulSoup(response.content.decode('gbk'), "lxml")
    tr = html.find('table', style='word-break:break-all').find_all('tr')
    return [
        {
            'riddle': t.find_all('td')[0].text,
            'answer': t.find_all('td')[1].text,
        }
        for t in tr
    ][1:]


if __name__ == '__main__':
    res = downloader('http://xhy.5156edu.com/html2/xhy.html')
    if res is None:
        print('Failed to download the first page.')
        exit(1)
    for i in range(2, 282):
        res += downloader(f'http://xhy.5156edu.com/html2/xhy_{i}.html')
    print(len(res))
    with open('xiehouyu.json', mode='w+', encoding='utf-8') as json_file:
        json.dump(res, json_file, ensure_ascii=False)

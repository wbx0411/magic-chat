
idx_vec_pre = 'Idx_Vec_Node'
idx_fts_pre = 'Idx_Fts_Node'

# 此标签包含后四个标签
label_idx = '指标'
label_scene = '场景'
label_idx_yz = '原子指标'
label_idx_dim = '维度'
label_idx_val = '维度值'

label_org = '供电单位'

org_logic_unit = ['客服中心', '客户服务中心']

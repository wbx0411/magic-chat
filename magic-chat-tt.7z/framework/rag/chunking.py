import re
from typing import List
from langchain_text_splitters import RecursiveCharacterTextSplitter


def preprocess_text(text: str) -> str:
    """文本清洗与标准化"""
    # 移除特殊字符、多余换行、HTML标签等
    text = re.sub(r'<[^>]+>', '', text)  # 去HTML标签
    text = re.sub(r'\s+', ' ', text)  # 合并连续空白符
    text = re.sub(r'[^\w\s\u4e00-\u9fff，。！？；：、（）“”‘’—…]', '', text)  # 保留中英文标点
    return text.strip()


def semantic_chunking(text: str, chunk_size: int = 512, overlap: int = 50) -> List[str]:
    """混合分块策略：先按段落分割，长段落再递归分块"""
    # 第一阶段：按段落分割
    paragraphs = [p for p in text.split('\n') if p.strip()]

    chunks = []
    for para in paragraphs:
        if len(para) <= chunk_size:
            chunks.append(para)
        else:
            # 第二阶段：对长段落递归分块
            splitter = RecursiveCharacterTextSplitter(
                chunk_size=chunk_size,
                chunk_overlap=overlap,
                separators=["。", "！", "？", "；", "\n", "，", " "],
            )
            chunks.extend(splitter.split_text(para))

    # 添加重叠区域（滑动窗口）
    final_chunks = []
    for i in range(len(chunks)):
        current = chunks[i]
        if i > 0:
            prev_overlap = chunks[i - 1][-overlap:]
            current = prev_overlap + current
        final_chunks.append(current[:chunk_size])  # 确保不超过最大长度

    return final_chunks


if __name__ == '__main__':
    import os
    import sys
    from utils.file_handler_utils import file_reader

    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

    file_root = "resources/docs/"
    # file_name = "(优先)供电营业规则（2024年6月1日起施行）.docx"
    file_name = "第四次现货结算试运行工作日报.pdf"
    file_content = file_reader(f'{file_root}{file_name}')
    file_content = preprocess_text(file_content)
    chunks = semantic_chunking(file_content, chunk_size=512, overlap=50)
    for index, chunk in enumerate(chunks):
        print(f"Chunk {index + 1}:", chunk)

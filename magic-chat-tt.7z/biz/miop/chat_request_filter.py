import json
import re
from enum import Enum
from typing import Optional

from jinja2 import FileSystemLoader, Environment, select_autoescape
from pydantic import BaseModel

from biz.miop.filter import remote_service, code_collection
from utils.logger_utils import LoggerFactory

PREFIX_MARK = '#'
MAX_FINDALL = 5


class Modes(Enum):
    MONO = 1
    APPEND = 2
    OPTION = 3


class Methods(Enum):
    FINDALL = 'findall'
    SEARCH = 'search'


def get_regex_prefix(keyword):
    return f'{PREFIX_MARK}{keyword}' + r'\s*([^,.:;?!，。：；？！￥…*@%&$+=^`{}\\\/\n\s]+)'


# 过滤器配置字典列表:(目前只支持单一过滤模式处理，即匹配到第一个就返回)
# - "name": 过滤器的名称
# - "mode": 过滤模式，比如过滤后对后续处理的影响等（例如："append"表示追加模式处理；"mono"表示单一模式处理；"option"表示选项模式处理）
# - "pattern": 一个正则表达式，用于匹配文档中的特定内容
# - "method": 使用的正则表达式方法（例如："findall"表示寻找所有匹配项；"search"表示寻找第一个匹配项；"match"表示匹配整个字符串；等）
# - "function": 当找到匹配内容时，要调用的函数名称
# - "template": 格式返回文本的模板文件名
# - "api": 相关API的代码或URL，如果有的话需要以Constants.API_CODE_KEY开头和结尾
filter_config_list = [
    {
        "name": "cust_no_prefix",
        "mode": Modes.MONO,
        "pattern": get_regex_prefix('户号'),
        "method": Methods.FINDALL,
        "function": "query_cust_360_by_no",
        "template": "cust_360_info",
        "api": None
    },
    {
        "name": "cust_no_number",
        "mode": Modes.MONO,
        "pattern": r'\d{13}',  # 13位数字
        "method": Methods.FINDALL,
        "function": "query_cust_360_by_no",
        "template": "cust_360_info",
        "api": None
    },
    # {
    #     "name": "cust_name_prefix",
    #     "mode": Modes.MONO,
    #     "pattern": get_regex_prefix('户名'),
    #     "method": "search",
    #     "function": "query_cust_360_by_name",
    #     "template": "cust_360_info",
    #     "api": None,
    # },
]

logger = LoggerFactory.get_logger(__name__)
loader = FileSystemLoader('streaming/templates')
env = Environment(loader=loader, autoescape=select_autoescape(['txt']))
service = remote_service.MiopService()


class Filtration(BaseModel):
    """
    定义了一个Filtration模型，用于表示过滤信息。
    属性:
        mode (str): 过滤的类型。
        api (Optional[str]): 相关API的标识符，可为空。
        info (Optional[str]): 过滤的额外信息或说明，可为空。
    """
    mode: int
    api: Optional[str]
    info: Optional[str]


def regex_match_keyword(message, pattern, method):
    """
    使用给定的正则表达式模式和方法在消息中搜索关键词。
    参数:
    - message: str, 要搜索的消息文本
    - pattern: str, 正则表达式模式
    - method: str, 要使用的正则表达式方法, 如search, match, findall
    返回值:
    - list, 匹配到的关键词列表。如果没有匹配到任何关键词，则返回None。
    """
    try:
        # 使用正则表达式搜索消息中是否包含关键词
        pattern = re.compile(pattern)
        method = getattr(pattern, method)
        filter_result = method(message)

        # 如果没有匹配到关键词，则返回None
        if not filter_result:
            return None

        if isinstance(filter_result, list):
            # 如果是列表则是findall，直接获取匹配的关键词列表，并限制最多5个
            return filter_result[0: MAX_FINDALL]

        if isinstance(filter_result, re.Match):
            # 获取匹配的关键词的最后一组
            search_groups = filter_result.groups()
            index = len(search_groups) - 1
            if index >= 0:
                return [search_groups[index]]
            elif filter_result.group():
                return [filter_result.group()]

        # 如果没有获得结果，怎返回None
        return None
    except re.error as e:
        logger.error(f"Invalid regular expression error: {repr(e)}")
        return None
    except Exception as e:
        logger.error(f"Filter regex match error: {repr(e)}")
        return None


async def exec_func(function, *keys):
    """
    异步执行指定函数。
    参数:
    - function: str, 要执行的函数名称
    - keys: str, 传递给函数的关键词或参数
    返回值:
    - 执行指定函数的返回值，如果执行过程中出现异常，则返回None。
    """
    try:
        # 根据提供的函数名称，从service对象中获取函数
        func = getattr(service, function)
        # 异步调用函数，并传入关键词key
        data = await func(*keys)

        logger.info(f"Execute function {function} success")
        return data
    except Exception as e:
        logger.error(f"Execute function {function} error: {repr(e)}")
        return None


def render_text(template, data):
    """
    提供渲染返回数据。
    参数:
    - template: str, 模板名称
    - data: json, 数据
    返回值:
    - 渲染后的文本或JSON格式化的数据。如果执行过程中出现异常，则返回None。
    """
    try:
        if not data or not isinstance(data, dict) or len(data) == 0:
            return None

        # 判断是否需要使用模板渲染数据
        if template:
            # 加载指定名称的模板文件
            jinja_template = env.get_template(f'{template}.jinja2')
            # 获取与模板名称对应的属性字典，用于模板渲染
            prop = getattr(code_collection, template)
            # 使用模板和数据渲染出最终文本
            info = jinja_template.render(data=data, prop=prop)
        else:
            # 直接将数据转换为JSON格式字符串
            info = json.dumps(data, ensure_ascii=False)

        logger.info(f"Render template {template} success")
        return info
    except Exception as e:
        logger.error(f"Render template {template} error: {repr(e)}")
        return None


async def filter_request_message(message, org_no):
    """
    根据预设的过滤条件异步过滤消息中的关键词，并根据匹配的条件调用相应的API获取数据。
    参数:
    - message: str, 待检查的消息文本。
    - org_no: str, 供电单位编码。
    返回值:
    - 如果消息中包含匹配的关键词，并且调用API成功获取到数据，则返回一个Filtration对象，包含过滤类型、API信息和处理结果；
    - 如果没有匹配到任何关键词或API调用失败，则返回None。
    """
    try:
        # 遍历预设的过滤条件，检查消息是否匹配
        for f in filter_config_list:
            # 根据预设模式匹配消息中的关键词
            key_list = regex_match_keyword(message, f['pattern'], f['method'].value)
            logger.info(f"Filter {f['name']} regex match: {key_list}")
            # 如果没有匹配到关键词，则尝试下一个过滤条件
            if not key_list:
                continue

            info_list = []
            # 对匹配到的每个关键词调用相应的函数，并处理结果
            for key in key_list:
                data = await exec_func(f['function'], org_no, key)
                info = render_text(f['template'], data)
                if info:
                    info_list.append(info)
            # 目前只支持一个过滤，则立即返回Filtration对象，包含过滤信息
            filtration = Filtration(mode=f['mode'], api=f['api'], info='\n'.join(info_list))
            logger.info(f"Filter result: {filtration}")
            return filtration
        # 如果没有匹配到任何条件，返回None
        return None
    except Exception as e:
        # 记录异常信息，并返回None
        logger.error(f"Filter request message error: {repr(e)}")
        return None

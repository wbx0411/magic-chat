import uuid


print(uuid.uuid1().hex)

import os
import uuid
from framework.embedding.m3e_client import m3e_client
from transport.db.postgresdb import PostgresDB
from utils import file_handler_utils
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)

db = PostgresDB('postgres_rag')
doc_root = os.path.dirname(__file__)


def init_remote():
    contents = [
        {"name": "信息咨询", "desc": "咨询关于营业厅的内容", "content": "/consult"},
        {"name": "电费问询", "desc": "查询电费", "content": "/query"},
        {"name": "业务办理", "desc": "办理用户的用电业务", "content": "/handle"},
        {"name": "自助打印", "desc": "打印发票、收据等", "content": "/query"},
    ]

    name_emb_respone = m3e_client.get_embeddings(
        [content['name'] for content in contents],
        'm3e-small',
    )

    desc_emb_respone = m3e_client.get_embeddings(
        [content['desc'] for content in contents],
        'm3e-small',
    )

    name_desc_emb_respone = m3e_client.get_embeddings(
        [content['name'] + content['desc'] for content in contents],
        'm3e-small',
    )

    commands = [
        (
            """
            insert into ai_tool_kh
            (kh_id, kh_type, kh_name, kh_desc, kh_group, kh_source, kh_content, modify_time, 
            kh_name_emb, kh_desc_emb, kh_name_desc_emb)
            values(%s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP, 
            %s::vector, %s::vector, %s::vector);
            """,
            (
                str(uuid.uuid4()).replace("-", ""),
                'remote',
                content['name'],
                content['desc'],
                '业务流转',
                'system',
                content['content'],
                name_emb['embedding'],
                desc_emb['embedding'],
                name_desc_emb['embedding'],
            ),
        )
        for content, name_emb, desc_emb, name_desc_emb in zip(
            contents,
            name_emb_respone['data'],
            desc_emb_respone['data'],
            name_desc_emb_respone['data'],
        )
    ]
    commands.insert(0, ("delete from ai_tool_kh where kh_type='remote';", ()))
    result = db.execute_batch(commands)
    logger.info(f"init data [remote], {result=}")


def init_biz_type():
    contents = file_handler_utils.file_reader(f'{doc_root}/业务分类.docx', read_type='heading')

    contents = [content for content in contents if content['content']]

    emb_respone = m3e_client.get_embeddings(
        [content['title'] for content in contents],
        'm3e-small',
    )

    commands = [
        (
            """
            insert into ai_tool_kh
            (kh_id, kh_type, kh_name, kh_desc, kh_group, kh_source, kh_content, modify_time, kh_name_desc_emb)
            values(%s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP, %s::vector);
            """,
            (
                str(uuid.uuid4()).replace("-", ""),
                'biz_type',
                content['title'],
                '',
                '业务分类',
                '业务分类.docx',
                content['content'],
                emb_data['embedding'],
            ),
        )
        for content, emb_data in zip(contents, emb_respone['data'])
    ]
    commands.insert(0, ("delete from ai_tool_kh where kh_type='biz_type';", ()))
    result = db.execute_batch(commands)
    logger.info(f"init data [业务分类.docx], {result=}")


def init_biz_qa(doc_name, kh_group):
    contents = file_handler_utils.file_reader(f'{doc_root}/{doc_name}', read_type='heading2')
    contents = [
        {
            "title": content['title'],
            "sub_title": sub_content['title'],
            "content": sub_content['content'],
        }
        for content in contents
        for sub_content in content['sub_chapters']
        if sub_content['content'].strip()
    ]

    emb_respone = m3e_client.get_embeddings(
        [content['title'] + content['sub_title'] for content in contents],
        'm3e-small',
    )

    commands = [
        (
            """
            insert into ai_tool_kh
            (kh_id, kh_type, kh_name, kh_desc, kh_group, kh_source, kh_content, modify_time, kh_name_desc_emb)
            values(%s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP, %s::vector);
            """,
            (
                str(uuid.uuid4()).replace("-", ""),
                'consult',
                content['title'],
                content['sub_title'],
                kh_group,
                doc_name,
                content['content'],
                emb_data['embedding'],
            ),
        )
        for content, emb_data in zip(contents, emb_respone['data'])
    ]
    commands.insert(
        0, (f"delete from ai_tool_kh where kh_type='consult' and kh_group='{kh_group}';", ())
    )
    result = db.execute_batch(commands)
    logger.info(f"init data [{doc_name}], {result=}")
    return result


if __name__ == "__main__":
    init_remote()
    init_biz_type()

    docs = [
        ("第一章 标问标答（业扩）.docx", '业扩'),
        ("第二章 标问标答（计量）.docx", '计量'),
        ("第二章 标问标答（新兴业务）.docx", '新兴业务'),
        ("第二章 标问标答（电费电价）.docx", '电费电价'),
    ]
    [init_biz_qa(doc, biz) for doc, biz in docs]

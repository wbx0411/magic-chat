import random


random_funcs = [
    'betavariate',
    'choice',
    'choices',
    'expovariate',
    'gammavariate',
    'gauss',
    'getrandbits',
    'getstate',
    'lognormvariate',
    'normalvariate',
    'paretovariate',
    'randbytes',
    'randint',
    'random',
    'randrange',
    'sample',
    'seed',
    'setstate',
    'shuffle',
    'triangular',
    'uniform',
    'vonmisesvariate',
    'weibullvariate',
]
print("betavariate:", random.betavariate(0.5, 0.5))
print("choice:", random.choice([1, 2, 3]))
print("choices:", random.choices([1, 2, 3], k=2))
print("expovariate:", random.expovariate(1.5))
print("gammavariate:", random.gammavariate(2.0, 2.0))
print("gauss:", random.gauss(0, 1))
print("getrandbits:", random.getrandbits(8))
# print("getstate:", random.getstate())
print("lognormvariate:", random.lognormvariate(0, 1))
print("normalvariate:", random.normalvariate(0, 1))
print("paretovariate:", random.paretovariate(1.0))
print("randbytes:", random.randbytes(5))
print("randint:", random.randint(1, 10))
print("random:", random.random())
print("randrange:", random.randrange(1, 10))
print("sample:", random.sample([1, 2, 3, 4, 5], 3))
print("seed:", random.seed(42))
print("shuffle:", random.shuffle([1, 2, 3, 4, 5]))
print("triangular:", random.triangular(1, 10, 5))
print("uniform:", random.uniform(1, 10))
print("vonmisesvariate:", random.vonmisesvariate(0, 4))
print("weibullvariate:", random.weibullvariate(1, 1.5))

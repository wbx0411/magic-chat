select * from BM_YZ_IDX_INFO;	--原子指标信息表
select * from BM_DIMENSION_INFO order by id;	--维度信息表
select * from BM_DIMENSION_VALUE;	--维度值表
select * from BM_YZ_DIMENSION_RELA;--原子指标与维度关系表

--原子指标
select dimension_code , dimension_name from bm_dimension_info order by dimension_code;
--维度
select yz_idx_code, yz_idx_name from bm_yz_idx_info;
--原子指标与维度
select yz_idx_code, dimension_code from bm_yz_dimension_rela;
-- 纬度值：BM_DIMENSION_INFO表中的table_name字段和col_name字段定义纬度值明细
-- 01
select prop_list_id, prop_list_name from ep_prop_list where prop_type_id = 'ecCateg' and length(prop_list_id) = 2;
-- 02
select prop_list_id, prop_list_name from ep_prop_list where prop_type_id = 'indElecCls' and prop_list_id like '%000';
-- 03
select prop_list_id, prop_list_name from ep_prop_list where prop_type_id = 'custCls';
-- 04
select prop_list_id, prop_list_name from ep_prop_list where prop_type_id = 'baseVolt';
-- 05
select system_user_id, user_name from buf_cms20_emss.emss_cmc_system_user;
-- 06
select system_user_id, user_name from buf_cms20_emss.emss_cmc_system_user;
-- 07
select manager_id, tg_manager from dws_miop_sxdp.tg_manager_edit;


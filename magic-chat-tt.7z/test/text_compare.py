import math
import os
from collections import Counter
from collections.abc import Iterable
from paddlenlp import Taskflow
import jieba

from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)


def extract_entity(text):
    schema = ['学校名称', "申请变压器", "选择用电", "放弃用电", "申请用电", "报装用电"]
    ie = Taskflow('information_extraction', schema=schema)
    res = ie(text)
    logger.info("Entity extraction result: {}".format(res))
    return res


import jieba  # jieba分词
import difflib  # 方法一：Python自带标准库计算相似度的方法，可直接用
from fuzzywuzzy import fuzz  # 方法二：Python自带标准库计算相似度的方法，可直接用
import numpy as np
from collections import Counter


# 方法三：编辑距离，又称Levenshtein距离
def edit_similar(str1, str2):  # str1，str2是分词后的标签列表
    len_str1 = len(str1)
    len_str2 = len(str2)
    taglist = np.zeros((len_str1 + 1, len_str2 + 1))
    for a in range(len_str1):
        taglist[a][0] = a
    for a in range(len_str2):
        taglist[0][a] = a
    for i in range(1, len_str1 + 1):
        for j in range(1, len_str2 + 1):
            if str1[i - 1] == str2[j - 1]:
                temp = 0
            else:
                temp = 1
            taglist[i][j] = min(
                taglist[i - 1][j - 1] + temp, taglist[i][j - 1] + 1, taglist[i - 1][j] + 1
            )
    return 1 - taglist[len_str1][len_str2] / max(len_str1, len_str2)


# 方法四：余弦相似度
def cos_sim(str1, str2):  # str1，str2是分词后的标签列表
    co_str1 = Counter(str1)
    co_str2 = Counter(str2)
    p_str1 = []
    p_str2 = []
    for temp in set(str1 + str2):
        p_str1.append(co_str1[temp])
        p_str2.append(co_str2[temp])
    p_str1 = np.array(p_str1)
    p_str2 = np.array(p_str2)
    return p_str1.dot(p_str2) / (np.sqrt(p_str1.dot(p_str1)) * np.sqrt(p_str2.dot(p_str2)))


# 备注，一般采用几种方法，给每个方法配个权重，算总分，这样比较好！

# —————— Copyright (C)2020 闲人Ne. All Rights Reserved —————— END OF FILE —————— #
# 示例
if __name__ == "__main__":
    docs = ["西华小学教育果小电大校区, 富强民主文明和谐, 自由平等公正法治, 爱国敬业诚信友善"]
    q = "G, 事业单位法人证书, 证第111011000154, GG, GG, 名, 称北京市顺义区西辛小学, 法定代表人王间, 品, 宗, 旨, 和为实施小学义务教育货进基础校, 经费来源全额拔款, G品G, 育发展，小学学历教育, G, 业务范围, 开办资金￥110万元, GOGGGGGGGG, 举办单位北京市顺义区教育委员会, 住, 所北京市顺义区西辛南区, 制发机关, 登记管理机关, 年度报告标记, 年3月311, 营理机关报进上一年度的, 有故期自2014年1月111, 公示、不再私贴平度报合称记, G"
    docs = [extract_entity(doc) for doc in docs]
    q = extract_entity(q)

    # 举例说明
    # str1 = "西华"
    # str2 = "西辛"
    # str11 = jieba.lcut(str1)
    # str22 = jieba.lcut(str2)
    # print('str1=' + str1)  # jieba分词后
    # print('str2=' + str2)  # jieba分词后
    # diff_result = difflib.SequenceMatcher(None, str1, str2).ratio()
    # print('方法一：Python标准库difflib的计算分值：' + str(diff_result))
    # print('方法二：Python标准库fuzz的计算分值：' + str(fuzz.ratio(str1, str2) / 100))
    # print('方法三：编辑距离的计算分值：' + str(edit_similar(str11, str22)))
    # print('方法四：余弦相似度的计算分值：' + str(cos_sim(str11, str22)))

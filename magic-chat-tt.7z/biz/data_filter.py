import json

keywords = ["西安", "渭南", "咸阳", "宝鸡", "汉中", "铜川", "安康", "商洛", "延安", "榆林", "西咸新区"]
uni_keywords = ["全部地市", "所有地市", "各地市", "各个地市", "全省"]


def filter_cities(search_text, json_str):
    data_list = json.loads(json_str)
    selected_data = []
    # 如果是下级地市，返回全部
    if 1 == len(data_list):
        for item in data_list:
            selected_data.append(item)
        return selected_data

    # 如果问全部地址，返回全部
    for keyword in uni_keywords:
        if keyword in search_text:
            for item in data_list:
                selected_data.append(item)
            return selected_data

    # 按搜索内容中提及的城市匹配数据
    for keyword in keywords:
        if keyword in search_text:
            for item in data_list:
                if item["org"] == keyword:
                    selected_data.append(item)

    # 如果没有找到任何匹配的数据，添加 org 为 "陕西" 的数据
    if not selected_data:
        for item in data_list:
            if item["org"] == "陕西":
                selected_data.append(item)

    return selected_data

from contextlib import contextmanager
import os
import re


@contextmanager
def timer():
    from time import time

    start = time()
    print("Timer started")
    yield
    print(f'Timer ended, elapsed time: {time() - start}')


def monitor(func):
    def wrapper(*args, **kwargs):
        from time import time

        start = time()
        print(f'Calling {func.__name__}, args: {args}, kwargs: {kwargs}')
        result = func(*args, **kwargs)
        print(f"Result: {result}")
        print(f'Elapsed time: {time() - start}')
        return result

    return wrapper


@monitor
def read_idx_info(*args, **kwargs):
    with open(f'{os.path.dirname(__file__)}/idx_info.txt', 'r', encoding='utf-8') as f:
        return dict(line.strip().split(',') for line in f)


# with timer():
#     idx_info = read_idx_info()
#     print(idx_info)


def read_menu():
    pattern = r'.*menuTitle:(\w*).*|.*interfaces\.(\w*)Controller.*'
    with open(f'{os.path.dirname(__file__)}/menu.txt', 'r', encoding='utf-8') as f:
        return dict(
            (re.sub(pattern, lambda m: m.group(1) or m.group(2), uri).lower(), name)
            for name, uri in [line.strip().split(',') for line in f]
        )


def re_split():
    pattern = r',|;|、'
    s = 'a,b;c、d'
    print(re.split(pattern, s))


txt = "The rain in Spain"

# Check if "ain" is present at the end of a WORD:

x = re.findall(r"\w*ain\b", txt)

print(x)

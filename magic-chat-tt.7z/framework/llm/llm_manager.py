import asyncio
import os
import warnings

from langchain_community.chat_models import ChatOpenAI
from langchain_core._api import LangChainDeprecationWarning
from langchain_qianwen import Qwen_v1

from framework.llm.chat_guangming import GuangMingChat
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)
warnings.filterwarnings("ignore", category=LangChainDeprecationWarning)


class LLMManager:
    def __init__(self):
        pass

    @staticmethod
    def _create_llm_instance(configs, streaming=False):
        logger.info(f"llm model api: {configs['model_type']}")
        if configs['model_type'] == 'dashscope':
            return Qwen_v1(model_name=configs['dashscope_model_name'], streaming=streaming)
        elif configs['model_type'] == 'openai':
            return ChatOpenAI(
                base_url=configs['llm_base_url'],
                model_name=configs['model_name'],
                openai_api_key=configs.get('api_key', os.environ.get('OPENAI_API_KEY', 'EMPTY')),
                streaming=streaming,
            )
        elif configs['model_type'] == 'guangming':
            return ChatOpenAI(
                base_url=configs['llm_base_url'],
                model_name=configs['model_name'],
                api_key=configs.get('api_key', os.environ.get('GUANGMING_API_KEY', 'EMPTY')),
                streaming=streaming,
                model_kwargs={
                    "headers": {
                        "Authorization": configs.get(
                            'api_key', os.environ.get('GUANGMING_API_KEY', 'EMPTY')
                        ),
                    }
                },
            )
        else:
            raise ValueError(f"Unsupported llm model type: {configs['model_type']}")

    @staticmethod
    async def _create_llm_instance_async(configs):
        await asyncio.sleep(0)
        return LLMManager._create_llm_instance(configs, streaming=True)

    @staticmethod
    async def create_streaming_llm_async(configs):
        return await LLMManager._create_llm_instance_async(configs)

    @staticmethod
    def create_streaming_llm(configs):
        return LLMManager._create_llm_instance(configs, streaming=True)

    @staticmethod
    def create_llm(configs):
        return LLMManager._create_llm_instance(configs, streaming=False)


def chat(configs, message, prompt=None, streaming=False):
    llm = LLMManager._create_llm_instance(configs, streaming=streaming)
    input = [("human", message)]
    if prompt:
        input.append(("system", prompt))
    return llm.invoke(input).content


async def achat(configs, message, prompt=None, streaming=False):
    llm = LLMManager._create_llm_instance(configs, streaming=streaming)
    input = [("human", message)]
    if prompt:
        input.append(("system", prompt))
    result = await llm.ainvoke(input)
    return result.content

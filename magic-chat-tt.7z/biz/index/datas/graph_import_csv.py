import csv
import os

from py2neo import Node, Relationship, NodeMatcher

from biz.index.metadata import *
from configs import config_loader
from transport.db.neo4jdb import Neo4jDB
from utils.logger_utils import LoggerFactory

configs = config_loader.load_config()
neo4j = Neo4jDB()
db = neo4j.get_engine()
node_matcher = NodeMatcher(db)

current_dir = os.path.dirname(os.path.abspath(__file__))
import_root = os.path.join(current_dir, "graph")
encoding = configs['encoding']

logger = LoggerFactory.get_logger(__name__)

def import_csv(ns, file_prefix):
    # csv header definition
    _headers = ['name', 'code', 'label']
    _header_index_type = 2  # header index of the type
    _header_index_id = 1  # header index of the id
    _start_node_index = [0, 1, 2]  # index of the properties of the start node
    _end_node_index = [8, 9, 10]  # index of the properties of the end node
    _rela_index = 6  # index of the relationship

    # open a csv file
    file_path = latest_file(file_prefix)
    with open(file_path, 'r', encoding=encoding) as f:
        print(f"=== import file: {file_path}")
        # loop through each row of the csv file
        for row_num, row in enumerate(csv.reader(f)):
            if row_num == 0:
                print(f"Headers: {row}")
                continue
            start_props = dict(zip(_headers, [row[i] for i in _start_node_index]))
            end_props = dict(zip(_headers, [row[i] for i in _end_node_index]))
            # handle one row of csv file
            node_start = Node(ns, start_props[_headers[_header_index_type]], **start_props)
            node_end = Node(ns, end_props[_headers[_header_index_type]], **end_props)
            db.merge(node_start, _headers[_header_index_type], _headers[_header_index_id])
            db.merge(node_end, _headers[_header_index_type], _headers[_header_index_id])
            db.merge(Relationship(node_start, ns, node_end, name=row[_rela_index]))
            logger.info(row_num) if row_num % 5 == 0 else None
        logger.info(f"{row_num} rows have been imported into the database.")


def import_entity(ns, file_prefix, *labels, has_name_label=False):
    file_path = latest_file(file_prefix)
    with open(file_path, 'r', encoding=encoding) as f:
        logger.info(f"=== import file: {file_path}")
        for row_num, row in enumerate(csv.reader(f)):
            if row_num == 0:
                logger.info(f"Headers: {','.join(row)}")
                continue
            try:
                if len(labels) == 1:
                    node = Node(ns, labels, name=row[1], code=row[0], label=labels, desc=row[0])
                elif len(labels) == 2:
                    node = Node(ns, labels[0], labels[1], name=row[1], code=row[0], label=labels[1], desc=row[0])
                else:
                    raise ValueError("labels length must be 1 or 2.")

                if has_name_label:
                    node.add_label(row[1])
                db.merge(node, labels, 'code')
                # db.run(f"""
                # create (:{label}{(':' + row[1]) if has_name_label else ''}
                #  {{name: '{row[1]}', code: '{row[0]}'}})
                #  """)
            except Exception as e:
                logger.info(f"row_num: {row_num}, row: {row}")
                logger.info(f"Error: {e}")
                raise e
        logger.info(f"{row_num} entities have been imported into the database.")
        return row_num


def import_relation(ns, file_prefix, start_label, end_label, rela_name):
    file_path = latest_file(file_prefix)
    with open(file_path, 'r', encoding=encoding) as f:
        logger.info(f"=== import file: {file_path}")
        for row_num, row in enumerate(csv.reader(f)):
            if row_num == 0:
                logger.info(f"Headers: {','.join(row)}")
                continue
            try:
                start_node = node_matcher.match(ns, start_label, code=row[0]).first()
                if not start_node:
                    logger.info(f"Node {start_label} - {row[0]} not found.")
                    continue
                end_node = node_matcher.match(ns, end_label, code=row[1]).first()
                if not end_node:
                    logger.info(f"Node {end_label} - {row[1]} not found.")
                    continue
                r = Relationship(start_node, ns, end_node, name=rela_name)
                db.merge(r)
            except Exception as e:
                logger.info(f"row_num: {row_num}, row: {row}")
                logger.info(f"Error: {e}")
                raise e
        logger.info(f"{row_num} relationships have been imported into the database.")
        return row_num


def import_entity_to_root(ns, file_prefix, label, node_name, rela_name):
    """
    Import entities and add relationships from the root node.
    """
    file_path = latest_file(file_prefix)
    with open(file_path, 'r', encoding=encoding) as f:
        print(f"=== import file: {file_path}")
        for row_num, row in enumerate(csv.reader(f)):
            if row_num == 0:
                print(f"Headers: {','.join(row)}")
                continue
            try:
                root_node = node_matcher.match(ns, node_name, name=node_name).first()
                if not root_node:
                    print(f"Node {label} - {row} not found.")
                    continue
                node = Node(ns, label, name=row[1], code=row[0], label=label)
                node.add_label(node_name)
                db.merge(node, label, ('code', 'name'))
                db.merge(Relationship(root_node, ns, node, name=rela_name))
            except Exception as e:
                print(f"row_num: {row_num}, row: {row}")
                print(f"Error: {e}")
        print(f"{row_num} entities have been imported into the database.")


def latest_file(prefix):
    import os
    files = os.listdir(import_root)
    files = [f for f in files if f.startswith(prefix)]
    files.sort()
    return os.path.join(import_root, files[-1])


def import_graph_combine(ns):
    # 原子指标 -> 维度
    import_entity(ns, 'entity_yz', '原子指标')
    import_entity(ns, 'entity_dimension', '维度', True)
    import_relation(ns, 'rela_yz-dimension', '原子指标', '维度', '使用')

    # 维度 -> 纬度值
    dimension_value_dict = {
        "01": "用电类别",
        "02": "行业类别",
        "03": "用户分类",
        "04": "电压等级",
        "05": "催费责任人",
        "06": "抄表责任人",
        "07": "台区经理",
    }
    for k, v in dimension_value_dict.items():
        import_entity_to_root(ns, f'dimension_value_{k}', '维度值', v, '包含')


def import_graph_scene(ns):
    # 场景 -> 原子指标
    entity_num = import_entity(ns, 'entity_scene', label_idx, label_scene)
    rel_num = import_relation(ns, 'rela_scene-yz', '场景', '原子指标', '包含')
    return entity_num, rel_num


if __name__ == '__main__':
    _namespace = configs['neo4j_config']['namespace']

    # import_graph_combine(_namespace)

    # import_csv(namespace, '20240830.csv')
    #
    # neo4j.close_engine()

    import_graph_scene(_namespace)

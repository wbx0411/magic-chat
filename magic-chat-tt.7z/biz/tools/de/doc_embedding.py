import os
from biz.tools import RTN_TYPE
from biz.tools.tool_manager import BaseTool, ExecResult
from biz.zhihu import save_doc_services
from biz.zhihu.doc_embedding_service import DocEmbeddingService
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)
embedding_service = DocEmbeddingService()


class DOCEmbedding(BaseTool):
    def __init__(self, config, chat_chain=None):
        super().__init__(config, chat_chain)

    def register(self, **kwargs):
        logger.info(f"DOCEmbedding register: {self.configs}")
        try:
            super().register()
            self.embedding(**kwargs)
        except Exception as e:
            super().unregister()
            raise e

    def unregister(self):
        logger.info(f"DOCEmbedding unregister: {self.configs}")
        if hasattr(save_doc_services, f"remove_rules"):
            getattr(save_doc_services, f"remove_rules")(self.configs.get('tool_id', ''))
        super().unregister()

    def embedding(self, **kwargs):
        logger.info(f"DOCEmbedding embedding: {kwargs=} {self.configs=}")
        assert (tool_params := self.configs.get('tool_params')), "tool_params is required"
        assert (doc_type := tool_params.get('doc_type')), "doc_type is required"

        if hasattr(save_doc_services, f"handle_{doc_type}"):
            getattr(save_doc_services, f"handle_{doc_type}")(
                tool_id=self.configs.get('tool_id', ''), **tool_params
            )
        else:
            raise ValueError(f"Doc type [{doc_type}] not supported.")

    async def execute(self, **kwargs):
        logger.info(f"DOCEmbedding execute: {kwargs}")
        prompt, attach_path = embedding_service.vector_search(
            kwargs['input_msg'], [self.find_doc_name(self.configs['tool_id'])]
        )
        logger.info(f"DOCEmbedding execute: {prompt=} {attach_path=}")
        return [ExecResult.knowledge(prompt), ExecResult(attach_path, self.configs['tool_code'])]

    def find_doc_name(self, tool_id: str):
        tool = self.db.query(
            "select * from ai_tools_de_doc_embedding where tool_id = %s limit 1", (tool_id,)
        )
        assert tool, f"doc not found: {tool_id=}"
        return tool[0]['title']

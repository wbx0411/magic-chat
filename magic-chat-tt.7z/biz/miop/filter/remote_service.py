import json
import os
import time
from urllib.parse import urljoin

import httpx

from utils.config_utils import SysConfig
from utils.logger_utils import LoggerFactory

timeout_default = float(os.environ.get('HTTP_REQUEST_TIMEOUT', 5.0))
RESPONSE_SUCCESS = 'SYS.200'


headers = {
    "Accept": "*/*",
    "Content-Type": "application/json"
}
logger = LoggerFactory.get_logger(__name__)

base_url_key = 'miop_base_url'


async def async_get(key, url, params=None, timeout=timeout_default):
    """
    异步发送GET请求
    """
    try:
        start_time = time.time()
        async with httpx.AsyncClient() as client:
            resp = await client.get(url=url, params=params, headers=headers, timeout=timeout)
            if resp.status_code == 200:
                logger.info(f"Client async get {key} duration: {time.time() - start_time}")
                return key, json.loads(resp.text)
            else:
                logger.error(f"Remote async get {url} fail:{resp.status_code}.")
                return key, None
    except httpx.ConnectTimeout as e:
        logger.error(f"Remote async get timeout：{url}")
        raise e
    except httpx.RequestError as e:
        logger.error(f"Remote async get {url} requestError：{repr(e)}")
        raise e
    except Exception as e:
        logger.error(f"Remote async get {url} exception：{repr(e)}")
        raise e


class MiopService:

    def __init__(self):
        self.configs = SysConfig.get_config()
        self.base_url = self.configs[base_url_key] if base_url_key in self.configs else None

    @staticmethod
    def _get_data(resp):
        if not resp or resp['code'] != RESPONSE_SUCCESS:
            raise Exception(resp['msg'])
        elif 'data' not in resp or not resp['data']:
            raise Exception(resp['msg'] + ' and data is empty')
        else:
            return resp['data']

    async def query_cust_360_by_no(self, org_no, cons_no):
        """
        根据客户编号异步查询客户360信息。
        参数:
        - cons_no: str, 客户编号，用于查询客户全方位信息。
        返回值:
        - 包含客户基本信息、账单信息、服务请求、投诉、历史用电信息和历史缴费信息的字典。如果请求失败或任何网络问题发生，返回None。
        """
        if not self.base_url or len(self.base_url) == 0:
            logger.error(f"miop_base_url is not in config")
            return None

        path = f'/miop/ConsDetail/{org_no}/{cons_no}'
        try:
            _, r = await async_get(path, urljoin(self.base_url, path))
            r = self._get_data(r)
            data = {}
            if 'yhjbxxdto' in r and r['yhjbxxdto']:
                data['main'] = r['yhjbxxdto']
                if 'zdhzhxxdto' in r and r['zdhzhxxdto'] and len(r['zdhzhxxdto']) > 0:
                    data['bill'] = r['zdhzhxxdto'][0]
                if 'fwxxView' in r and r['fwxxView'] and 'srdto' in r['fwxxView']:
                    data['sr'] = r['fwxxView']['srdto']
                if 'fwxxView' in r and r['fwxxView'] and 'tsdto' in r['fwxxView']:
                    data['ts'] = r['fwxxView']['tsdto']
                if 'hispdto' in r:
                    data['hisp'] = r['hispdto']
                if 'hiscdto' in r:
                    data['hisc'] = r['hiscdto']
            return data
        except Exception as e:
            logger.error(f"Service query_cust_360_by_no error: {repr(e)}")
            # logger.error(f"Query query_cust_360_by_no exception trace: {traceback.format_exc()}")
            return None

    async def query_cust_360_by_name(self, cons_name):
        """
        ！此方法并未使用，只是示例
        """
        return {
            "main": {
                "cn": cons_name,
                "cid": "0000000000000",
            }
        }

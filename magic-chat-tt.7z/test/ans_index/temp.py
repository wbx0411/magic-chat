import os


def read_menu():
    menus = {}
    with open(f'{os.path.dirname(__file__)}/menu.txt', 'r', encoding='utf-8') as f:
        for line in f:
            name, uri = line.strip().split(',')
            menus[uri.split("?")[0].split("/")[0]] = name
    return menus


menus = read_menu()
for k, v in menus.items():
    print(k, v)

# -*- coding: UTF-8 -*-

import unittest


class UserTestCase(unittest.TestCase):

    def setUp(self):
        print("setUp 开始")

    def tearDown(self):
        print("tearDown 结束")

    def testCase01(self):
        self.assertEqual(1, 2)

    def testCase02(self):
        print("testCase02 执行")
        self.assertNotEqual(1, 2)

    def testCase03(self):
        self.assertTrue(False)


if __name__ == '__main__':
    unittest.main()

import httpx

from utils.config_utils import SysConfig
from utils.logger_utils import LoggerFactory

logger = LoggerFactory.get_logger(__name__)


class M3EClient:
    def __init__(self, base_url, token, timeout=5):
        self.base_url = base_url
        self.headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
        self.timeout = timeout
        self.client = httpx.Client(headers=self.headers, timeout=self.timeout)
        logger.info(f"M3EClient initialized with base URL: {base_url}")

    def get_embeddings(self, texts, model_name="m3e-small"):
        url = f"{self.base_url}"
        data = {"input": texts, "model": model_name}
        logger.debug(f"Requesting embeddings for model: {model_name} with texts: {texts}")
        try:
            response = self.client.post(url, headers=self.headers, json=data, timeout=self.timeout)
            if response.status_code == 200:
                logger.debug("Successfully retrieved embeddings.")
                return response.json()
            else:
                logger.error(
                    f"Error retrieving embeddings: {response.status_code} - {response.text}"
                )
                return None
        except Exception as e:
            logger.exception(f"Exception occurred while retrieving embeddings: {e}")
            return None


configs = SysConfig.get_config()
m3e_client = M3EClient(configs['m3e_base_url'], configs['m3e_token'], configs['http_timeout'])

# 使用示例
if __name__ == "__main__":
    # base_url = "http://10.4.57.222:16006/v1/embeddings"  # FastAPI服务的URL
    base_url = "http://10.4.59.150:6006/v1/embeddings"  # FastAPI服务的URL
    model_name = "m3e-small"
    token = "sk-c1082f8dab44439fa67ecc3a50a8809a"  # 你的令牌
    client = M3EClient(base_url, token)
    #
    # # 示例文本和模型名称
    texts = ["Hello world", "How are you?"]
    # texts = "Hello world"
    #
    # 调用方法并打印结果
    embeddings_response = client.get_embeddings(texts, model_name)
    if embeddings_response:
        print(embeddings_response)
    pass
